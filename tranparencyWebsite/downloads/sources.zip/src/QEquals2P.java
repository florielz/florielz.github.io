
public class QEquals2P extends TransparencyLaw {

    private QEquals2P associatedLaw;

    @Override
    public String getName() {
        return "f(x) = x^p / (1-x)^(2p)";
    }
    
    @Override
    public String getName(double val) {
        if (val == 0) {
            return "f(x) = ln(x / (1-x)²)";
        }
        return this.getName();
    }

    @Override
    public String getFunction() {
        return "f(x) = x<sup>p</sup> / (1-x)<sup>2p</sup>";
    }

    @Override
    public String getFunction(double val) {

        if (val == 0.5) {
            return "f(x) = x<sup>0.5</sup> / (1-x)";
        } else if (val == -0.5) {
            return "f(x) = (1-x) / x<sup>0.5</sup>";
        } else if (val == -1) {
            return "f(x) = (1-x)<sup>2</sup> / x";
        } else if (val == 0) {
            return "f(x) = ln(x / (1-x)&sup2;)";
        } else {
            return "f(x) = x / (1-x)<sup>2</sup>";
        }
    }

    @Override
    public TransparencyLaw associatedLaw() {
        if (associatedLaw == null) {
            associatedLaw = new QEquals2P();
        }
        return associatedLaw;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        if (this.inverse) {
            return fInverse((f(back, t) - (1.0 - c) * f(front, t)) / c, t);
        } else if (t == 0.0) {
            double x = Math.pow(back / Math.pow((1.0 - back), 2.0), c) * Math.pow(front / Math.pow((1.0 - front), 2.0), 1.0 - c);
            return ((1.0 / 2.0) * (1.0 / x) * (1 + 2 * x - Math.sqrt(1 + 4.0 * x)));
        } else if (t == Double.POSITIVE_INFINITY) {
            if (c == 0) {
                return front;
            } else if (c == 1) {
                return back;
            } else {
                return Math.max(back, front);
            }
        } else if (t == Double.NEGATIVE_INFINITY) {
            if (c == 0) {
                return front;
            } else if (c == 1) {
                return back;
            } else {
                return Math.min(back, front);
            }
        } else {
            return (fInverse(c * f(back, t) + (1.0 - c) * f(front, t), t));
        }
    }

    @Override
    public double f(double x, double t) {
        if (t == 0) {
            return (Math.log(x / Math.pow(1.0 - x, 2.0)));
        } else {
            return (Math.pow(x, t) / Math.pow(1.0 - x, 2.0 * t));
        }
    }

    @Override
    public double fInverse(double x, double t) {
        if (t == 0) {
            return (1.0 / 2.0) * Math.exp(-x) * (1.0 + 2.0 * Math.exp(x) - Math.sqrt(1.0 + 4.0 * Math.exp(x)));
        } else {
            return (1.0 / 2.0) * (Math.pow(x, -1.0 / t) * (1.0 + 2.0 * Math.pow(x, 1.0 / t) - Math.sqrt(1.0 + 4.0 * Math.pow(x, 1.0 / t))));
        }
    }
}
