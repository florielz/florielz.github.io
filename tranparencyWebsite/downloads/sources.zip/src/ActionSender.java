import java.awt.event.*;
import java.util.*;


public class ActionSender
{
	private LinkedList<ActionListener> actionListeners;

	public ActionSender()
	{
		this.actionListeners = new LinkedList<ActionListener>();
	}

	public void addListener(ActionListener listener)
	{
		this.actionListeners.add(listener);
	}

	public void sendEvent()
	{
		ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, null);
		for(ActionListener l : this.actionListeners)
			l.actionPerformed(event);
	}
}
