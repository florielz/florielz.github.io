public class DirectNonUniform extends DirectUniform
{
	@Override
	public boolean isUniform()
	{
		return false;
	}

	@Override
	public String getName()
	{
		return "Yule-Nielsen";
	}

	@Override
	public TransparencyLaw associatedLaw()
	{
		return TransparencyLaws.INVERSE_NON_UNIFORM;
	}
}
