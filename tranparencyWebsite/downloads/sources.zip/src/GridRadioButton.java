
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class GridRadioButton extends JRadioButton {

    private double value;
    private TransparencyLaw law;

    public GridRadioButton(SecondApplication app, SideFrame frame, int x, int y, TransparencyLaw associatedLaw, double val) {
        super();

        law = associatedLaw;
        value = val;

        if (value == 0) {
            this.setBounds(x, y, 13, 13);
        } else {
            this.setBounds(x, y, 20, 20);
        }
        this.setOpaque(false);
        frame.getButtonGroup().add(this);
        int max = 200;
        int min = -max;
        int addit = max / 2;
        int harmo = min / 2;

        addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (associatedLaw != app.getSelectedLaw()) {
                    app.setLaw(law, law.isInverse(), law.isUniform());
                }
                app.setType(value);
                frame.getButtonGroup().setSelected((GridRadioButton) e.getSource());
                ChangeListener cl = frame.getSlider().getChangeListeners()[0];
                frame.update(frame.getTextField(), frame.getSlider(), value);
            }
        }
        );

        frame.getPanel().add(this);
    }

    public double getValue() {
        return value;
    }

    public TransparencyLaw getLaw() {
        return law;
    }
}
