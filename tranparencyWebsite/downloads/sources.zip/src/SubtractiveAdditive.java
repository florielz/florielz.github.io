
public class SubtractiveAdditive extends TransparencyLaw {

    @Override
    public boolean isInverse() {
        return false;
    }

    @Override
    public boolean isUniform() {
        return true;
    }

    @Override
    public String getName() {
        return "Subtractive-additive";
    }

    @Override
    public String getFunction() {
        return "Subtractive-additive";
    }

    @Override
    public TransparencyLaw associatedLaw() {
        return null;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        return ((1.0 - c) * Math.pow(front, t) + c * Math.pow(back, t)) * Math.pow(front, (1.0 - c) * (1.0 - t)) * Math.pow(back, c * (1.0 - t));
    }

    @Override
    public double f(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double fInverse(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getFunction(double val) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
