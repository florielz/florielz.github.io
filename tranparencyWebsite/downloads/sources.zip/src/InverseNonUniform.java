
import java.awt.Color;

public class InverseNonUniform extends InverseUniform {

    @Override
    public boolean isUniform() {
        return false;
    }

    @Override
    public String getName() {
        return " ";
    }

    @Override
    public TransparencyLaw associatedLaw() {
        return TransparencyLaws.DIRECT_NON_UNIFORM;
    }

    /*private double compute(double back, double front, double t) {
        if (back == front) {
            return 0.0;
        } else if (back < front) {
            if (t == 0.0) {
                return (Math.log(back) - Math.log(front)) / (Math.log(1.0 / 256.0) - Math.log(front));
            } else {
                return (Math.pow(back, t) - Math.pow(front, t)) / (Math.pow(1.0 / 256.0, t) - Math.pow(front, t));
            }
        } else if (t == 0.0) {
            if (front == 1.0) {
                return 0.0;
            } else {
                return 1.0 - Math.log(back) / Math.log(front);
            }
        } else {
            return (Math.pow(back, t) - Math.pow(front, t)) / (1.0 - Math.pow(front, t));
        }
    }*/

    /*@Override
    public double getRemoval(Color back, Color front, double a, double t) {
        double br = (back.getRed() + 1) / 256.0;
        double bg = (back.getGreen() + 1) / 256.0;
        double bb = (back.getBlue() + 1) / 256.0;
        double fr = (front.getRed() + 1) / 256.0;
        double fg = (front.getGreen() + 1) / 256.0;
        double fb = (front.getBlue() + 1) / 256.0;

        double cr = this.compute(br, fr, t);
        double cg = this.compute(bg, fg, t);
        double cb = this.compute(bb, fb, t);

        double cmin = Math.max(cr, Math.max(cg, cb));
        return cmin;
    }*/

    /*@Override
    public Color apply(Color back, Color front, double a, double t, boolean nullify) {
        double cmin = this.getRemoval(back, front, a, t);
        double c = 1.0 - a * (1.0 - cmin);
        return super.apply(back, front, c, t, nullify);
    }*/

    @Override
    public double f(double x, double t) {
        if (t == 0) {
            return (Math.log(x));
        } else {
            return (Math.pow(x, t));
        }
    }

    @Override
    public double fInverse(double x, double t) {
        if (t == 0) {
            return (Math.exp(x));
        } else {
            return (Math.pow(x, 1.0 / t));
        }
    }
}
