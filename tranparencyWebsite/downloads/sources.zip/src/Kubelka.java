
import java.awt.Color;

public class Kubelka extends TransparencyLaw {

    private Kubelka associatedLaw;
    private boolean expected = false;

    @Override
    public String getName() {
        return "Kubelka Munk";
    }

    @Override
    public String getFunction() {
        return "";
    }

    @Override
    public String getFunction(double val) {
        return "";
    }

    @Override
    public double apply(double back, double front, double n, double a, double b) {
        double rN = rN(a, b, front, n);
        double tN = tN(a, b, front, n);
        if (Double.isNaN(tN)) {
            return 2.0;
        }
        if (expected) {
            return ((1.0 + front * back) / (2.0 * back)) * (1.0 + Math.sqrt(1.0 - ((4.0 * back * (front - back + a * back)) / (a * Math.pow(1.0 + front * back, 2)))));
        } else if (inverse) {
            return ((back - rN) / (Math.pow(tN, 2.0) + rN * (back - rN)));
        } else {
            return (rN + (back * Math.pow(tN, 2.0)) / (1.0 - rN * back));
        }
    }

    @Override
    public Color apply(Color back, Color front, double n, double a, double b, boolean nullify) {
        if (n == Double.POSITIVE_INFINITY) {
            if (!Double.isNaN(tN(a, b, (253.0 * front.getRed() + 255.0) / (255.0 * 255.0), 100))
                    && !Double.isNaN(tN(a, b, (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0), 100))
                    && !Double.isNaN(tN(a, b, (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0), 100))) {
                if (isInverse()) {
                    return null;
                } else {
                    return front;
                }
            } else {
                return LimitedSlider.invalidColor;
            }
        } else if (a == 0 && b == 0) {
            return back;
        } else if (isExpected()) {
            if (a == 0) {
                a = 0.01;
            }
            double r0 = ((255.0 * (255.0 * this.apply((253.0 * back.getRed() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getRed() + 255.0) / (255.0 * 255.0), 1.0, a, 0.0) - 1.0)) / 253.0);
            double g0 = ((255.0 * (255.0 * this.apply((253.0 * back.getGreen() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0), 1.0, a, 0.0) - 1.0)) / 253.0);
            double b0 = ((255.0 * (255.0 * this.apply((253.0 * back.getBlue() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0), 1.0, a, 0.0) - 1.0)) / 253.0);

            int r1;
            if (Double.isNaN(r0)) {
                r1 = -300;
            } else {
                r1 = (int) Math.round(r0);
            }

            int g1;
            if (Double.isNaN(g0)) {
                g1 = -300;
            } else {
                g1 = (int) Math.round(g0);
            }

            int b1;
            if (Double.isNaN(b0)) {
                b1 = -300;
            } else {
                b1 = (int) Math.round(b0);
            }

            if (r1 == -1) {
                r1 = 0;
            }
            if (g1 == -1) {
                g1 = 0;
            }
            if (b1 == -1) {
                b1 = 0;
            }
            if (r1 == 256) {
                r1 = 255;
            }
            if (g1 == 256) {
                g1 = 255;
            }
            if (b1 == 256) {
                b1 = 255;
            }

            int r2 = Math.max(0, Math.min(255, r1));
            int g2 = Math.max(0, Math.min(255, g1));
            int b2 = Math.max(0, Math.min(255, b1));
            if (nullify && (r2 != r1 || g2 != g1 || b2 != b1)) {
                return null;
            } else {
                return new Color(r2, g2, b2);
            }
        } else {
            if (inverse && !uniform) {
                nMax = getRemoval(back, front, n, a, b);
                n = n * nMax;
            }
            double r9 = this.apply((253.0 * back.getRed() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getRed() + 255.0) / (255.0 * 255.0), n, a, b);
            double g9 = this.apply((253.0 * back.getGreen() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0), n, a, b);
            double b9 = this.apply((253.0 * back.getBlue() + 255.0) / (255.0 * 255.0),
                    (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0), n, a, b);

            if (r9 == 2.0 || g9 == 2.0 || b9 == 2.0) {
                return LimitedSlider.invalidColor;
            }

            double r0 = ((255.0 * (255.0 * r9 - 1.0)) / 253.0);
            double g0 = ((255.0 * (255.0 * g9 - 1.0)) / 253.0);
            double b0 = ((255.0 * (255.0 * b9 - 1.0)) / 253.0);

            int r1;
            if (Double.isNaN(r0)) {
                r1 = -300;
            } else {
                r1 = (int) Math.round(r0);
            }

            int g1;
            if (Double.isNaN(g0)) {
                g1 = -300;
            } else {
                g1 = (int) Math.round(g0);
            }

            int b1;
            if (Double.isNaN(b0)) {
                b1 = -300;
            } else {
                b1 = (int) Math.round(b0);
            }

            if (r1 == -1) {
                r1 = 0;
            }
            if (g1 == -1) {
                g1 = 0;
            }
            if (b1 == -1) {
                b1 = 0;
            }
            if (r1 == 256) {
                r1 = 255;
            }
            if (g1 == 256) {
                g1 = 255;
            }
            if (b1 == 256) {
                b1 = 255;
            }

            int r2 = Math.max(0, Math.min(255, r1));
            int g2 = Math.max(0, Math.min(255, g1));
            int b2 = Math.max(0, Math.min(255, b1));
            if (nullify && (r2 != r1 || g2 != g1 || b2 != b1)) {
                return null;
            } else {
                return new Color(r2, g2, b2);
            }
        }
    }

    public double rN(double alpha, double beta, double front, double n) {
        double a = a(front);
        double b = b(front);
        double rl = rl(alpha, beta, front);
        return Math.pow(a - b * (1.0 - 2.0 / (1.0 - Math.pow((1.0 - (a + b) * rl) / (1.0 - (a - b) * rl), n))), -1.0);
    }

    public double tN(double alpha, double beta, double front, double n) {
        double a = a(front);
        double b = b(front);
        double rl = rl(alpha, beta, front);
        double tl = tl(alpha, beta, front);
        if (Double.isNaN(tl)) {
            return Double.NaN;
        }
        return (2.0 * b * Math.pow(tl, n))
                / ((a + b) * Math.pow(1.0 - (a - b) * rl, n) - (a - b) * Math.pow(1.0 - (a + b) * rl, n));
    }

    public double rl(double alpha, double beta, double front) {
        return (alpha * front + beta);
    }

    public double tl(double alpha, double beta, double front) {
        double rl = rl(alpha, beta, front);
        double x = 1.0 + Math.pow(rl, 2.0) - 2.0 * rl * a(front);
        if (x < 0) {
            return Double.NaN;
        }
        return Math.sqrt(x);
    }

    public double a(double front) {
        return (1.0 + Math.pow(front, 2.0)) / (2.0 * front);
    }

    public double b(double front) {
        return Math.sqrt(Math.pow(a(front), 2.0) - 1.0);
    }

    @Override
    public double f(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double fInverse(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TransparencyLaw associatedLaw() {
        if (associatedLaw == null) {
            associatedLaw = new Kubelka();
        }
        return associatedLaw;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isExpected() {
        return expected;
    }

    @Override
    public void setExpected(boolean b) {
        expected = b;
    }
}
