
public class DirectUniform extends TransparencyLaw {

    @Override
    public boolean isInverse() {
        return false;
    }

    @Override
    public boolean isUniform() {
        return true;
    }

    @Override
    public String getName() {
        return "Yule-Nielsen";
    }

    @Override
    public String getFunction() {
        return "Yule-Nielsen";
    }

    @Override
    public TransparencyLaw associatedLaw() {
        return TransparencyLaws.INVERSE_UNIFORM;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        if (t == 0.0) {
            return Math.pow(front, 1.0 - c) * Math.pow(back, c);
        } else {
            return Math.pow((1.0 - c) * Math.pow(front, t) + c * Math.pow(back, t), 1.0 / t);
        }
    }

    @Override
    public double f(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double fInverse(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getFunction(double val) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
