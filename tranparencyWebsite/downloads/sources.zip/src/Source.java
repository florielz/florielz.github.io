import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;


public abstract class Source extends Box
{
	public Source(int boxAxis)
	{
		super(boxAxis);
		this.setOpaque(false);
	}

	public abstract String toString();
	public abstract Dimension getSourceSize();
	public abstract Color getPixel(float x, float y);
}
