
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class SideFrame extends JFrame {

    private BackPanel panel;
    private GridButtonGroup bg;
    private JSlider slider;
    private JSlider zeroSlider;
    private JPanel zeroPanel;
    private JPanel buttonSliderPanel;
    private JTextField text;
    private JLabel variableLabel;

    public GridRadioButton p1, p2, p3, p4, p5, p6, p7, p8, p9, p10,
            q1, q2, q3, q4, q5, q6, q7, q8, q9, q10,
            pq1, pq2, pq3, pq4, pq5, pq6, pq7, pq8, pq9, pq10,
            zero, p12, p51, p21, p15, q12, q51, q15, q21;

    private JRadioButton z1, z2, z3, z4, z0;
    private ButtonGroup gz;
    private  ButtonSlider b0, b1, b2, b3, b4, b5, b6, b7, b8;

    private JLabel l0, l1, l2, l3, l4;

    public SideFrame(SecondApplication app) {
        super("Transparency laws");
        this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        this.setResizable(false);

        bg = new GridButtonGroup();
        app.informationLawLabel = new JLabel();
        app.informationMeanLabel = new JLabel();
        app.informationTransparencyLabel = new JLabel();
        app.informationTransparencyLabel.setFont(app.informationTransparencyLabel.getFont().deriveFont(Font.BOLD | Font.ITALIC));
        app.informationTransparencyLabel.setForeground(new Color(26,26,151));
        variableLabel = new JLabel("p  =");

        panel = new BackPanel(this);
        app.sideDisabledPanel = new DisabledPanel(panel);
        this.add(app.sideDisabledPanel);

        panel.setLayout(null);
        int panelSizeX = 406;
        int panelSizeY = 489;
        panel.setSize(panelSizeX, panelSizeY);

        variableLabel.setBounds(282, 230, 50, 50);
        panel.add(variableLabel);

        app.informationMeanLabel.setBounds(250, 290, 200, 50);
        panel.add(app.informationMeanLabel);

        app.informationTransparencyLabel.setBounds(30, 35, 200, 50);
        panel.add(app.informationTransparencyLabel);

        JPanel informationPanel = new JPanel();
        informationPanel.setLayout(new BorderLayout());
        informationPanel.setAlignmentX(JPanel.CENTER_ALIGNMENT);
        informationPanel.setOpaque(false);
        informationPanel.setBounds(0, 0, 200, 200);

        Box informationBox = Box.createVerticalBox();

        informationBox.add(Box.createVerticalGlue());

        Box c2 = Box.createHorizontalBox();
        c2.add(Box.createRigidArea(new Dimension(50, 0)));
        c2.add(app.informationLawLabel);
        informationBox.add(c2);
        informationBox.add(Box.createVerticalGlue());

        informationPanel.add(informationBox);
        panel.add(informationPanel);

        TransparencyLaw p = app.laws.get(1);
        TransparencyLaw q = app.laws.get(0);
        TransparencyLaw pq = app.laws.get(2);
        TransparencyLaw p2q = app.laws.get(3);
        TransparencyLaw q2p = app.laws.get(4);
        TransparencyLaw z = app.laws.get(5);

        zeroPanel = new JPanel();
        zeroPanel.setLayout(null);
        zeroPanel.setOpaque(false);
        zeroPanel.setBounds(29 - 20, 404, 349 - 29 + 60, 60);
        panel.add(zeroPanel);

        l0 = new JLabel("<html>" + ((Zero) z).getFunction(0).substring(7) + "</html>");
        l1 = new JLabel("<html>" + ((Zero) z).getFunction(1).substring(7) + "</html>");
        l2 = new JLabel("<html>" + ((Zero) z).getFunction(2).substring(7) + "</html>");
        l3 = new JLabel("<html>" + ((Zero) z).getFunction(3).substring(7) + "</html>");
        l4 = new JLabel("<html>" + ((Zero) z).getFunction(4).substring(7) + "</html>");

        l0.setBounds(18, 20, 80, 30);
        l1.setBounds(75, 20, 80, 30);
        l2.setBounds(160, 20, 80, 30);
        l3.setBounds(240, 20, 80, 30);
        l4.setBounds(320, 20, 80, 30);

        zeroPanel.add(l0);
        zeroPanel.add(l1);
        zeroPanel.add(l2);
        zeroPanel.add(l3);
        zeroPanel.add(l4);

        gz = new ButtonGroup();

        z0 = new JRadioButton();
        z0.setBounds(0 + 20, 0, 20, 20);
        z0.setOpaque(false);
        z0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Zero) z).setLaw(0);
                bg.setSelected(q5);
                app.setLaw(z, z.isInverse(), z.isUniform());
            }
        }
        );
        gz.add(z0);
        zeroPanel.add(z0);

        z1 = new JRadioButton();
        z1.setBounds(80 + 20, 0, 20, 20);
        z1.setOpaque(false);
        z1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Zero) z).setLaw(1);
                bg.clearSelection();
                app.setLaw(z, z.isInverse(), z.isUniform());
            }
        }
        );
        gz.add(z1);
        zeroPanel.add(z1);

        z2 = new JRadioButton();
        z2.setBounds(160 + 20, 0, 20, 20);
        z2.setOpaque(false);
        z2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Zero) z).setLaw(2);
                bg.setSelected(pq5);
                app.setLaw(z, z.isInverse(), z.isUniform());
            }
        }
        );
        gz.add(z2);
        zeroPanel.add(z2);

        z3 = new JRadioButton();
        z3.setBounds(240 + 20, 0, 20, 20);
        z3.setOpaque(false);
        z3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Zero) z).setLaw(3);
                bg.clearSelection();
                app.setLaw(z, z.isInverse(), z.isUniform());
            }
        }
        );
        gz.add(z3);
        zeroPanel.add(z3);

        z4 = new JRadioButton();
        z4.setBounds(320 + 20, 0, 20, 20);
        z4.setOpaque(false);
        z4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ((Zero) z).setLaw(4);
                bg.setSelected(p5);
                app.setLaw(z, z.isInverse(), z.isUniform());
            }
        }
        );
        gz.add(z4);
        zeroPanel.add(z4);

        buttonSliderPanel = new JPanel();
        buttonSliderPanel.setLayout(null);
        buttonSliderPanel.setOpaque(false);
        buttonSliderPanel.setBounds(39 - 14, 434, 359 - 39 + 30, 60);
        panel.add(buttonSliderPanel);

        b0 = new ButtonSlider(app, this, 0, 0, Double.NEGATIVE_INFINITY, "-∞");
        b1 = new ButtonSlider(app, this, 40, 0, -2, "-2");
        b2 = new ButtonSlider(app, this, 80, 0, -1, "-1");
        b3 = new ButtonSlider(app, this, 120, 0, -0.5, "-0.5");
        b4 = new ButtonSlider(app, this, 160, 0, 0, "0");
        b5 = new ButtonSlider(app, this, 200, 0, 0.5, "0.5");
        b6 = new ButtonSlider(app, this, 240, 0, 1, "1");
        b7 = new ButtonSlider(app, this, 280, 0, 2, "2");
        b8 = new ButtonSlider(app, this, 320, 0, Double.POSITIVE_INFINITY, "∞");

        int max = 200;
        int min = -max;
        int addit = max / 2;
        int harmo = min / 2;
        int t = 3 * (max / 4);
        int n_t = -t;
        slider = new JSlider(JSlider.HORIZONTAL, min, max, app.DEFAULT_TYPE);
        text = new JTextField();

        p1 = new GridRadioButton(app, this, 189, 349, p, Double.NEGATIVE_INFINITY);
        p2 = new GridRadioButton(app, this, 189, 309, p, -2);
        p3 = new GridRadioButton(app, this, 189, 269, p, -1);
        p4 = new GridRadioButton(app, this, 189, 229, p, -0.5);
        p5 = new GridRadioButton(app, this, 191, 208, p, 0);
        p6 = new GridRadioButton(app, this, 191, 178, p, 0);
        p7 = new GridRadioButton(app, this, 189, 149, p, 0.5);
        p8 = new GridRadioButton(app, this, 189, 109, p, 1);
        p9 = new GridRadioButton(app, this, 189, 69, p, 2);
        p10 = new GridRadioButton(app, this, 189, 29, p, Double.POSITIVE_INFINITY);

        q1 = new GridRadioButton(app, this, 29, 189, q, Double.NEGATIVE_INFINITY);
        q2 = new GridRadioButton(app, this, 69, 189, q, -2);
        q3 = new GridRadioButton(app, this, 109, 189, q, -1);
        q4 = new GridRadioButton(app, this, 149, 189, q, -0.5);
        q5 = new GridRadioButton(app, this, 176, 194, q, 0);
        q6 = new GridRadioButton(app, this, 206, 194, q, 0);
        q7 = new GridRadioButton(app, this, 229, 189, q, 0.5);
        q8 = new GridRadioButton(app, this, 269, 189, q, 1);
        q9 = new GridRadioButton(app, this, 309, 189, q, 2);
        q10 = new GridRadioButton(app, this, 349, 189, q, Double.POSITIVE_INFINITY);

        bg.setSelected(q5);

        pq1 = new GridRadioButton(app, this, 29, 349, pq, Double.NEGATIVE_INFINITY);
        pq2 = new GridRadioButton(app, this, 69, 309, pq, -2);
        pq3 = new GridRadioButton(app, this, 109, 269, pq, -1);
        pq4 = new GridRadioButton(app, this, 149, 229, pq, -0.5);
        pq5 = new GridRadioButton(app, this, 179, 205, pq, 0);
        pq6 = new GridRadioButton(app, this, 202, 182, pq, 0);
        pq7 = new GridRadioButton(app, this, 229, 149, pq, 0.5);
        pq8 = new GridRadioButton(app, this, 269, 109, pq, 1);
        pq9 = new GridRadioButton(app, this, 309, 69, pq, 2);
        pq10 = new GridRadioButton(app, this, 349, 29, pq, Double.POSITIVE_INFINITY);

        this.scaleRadioButtonIcon(p5, 10, 10);
        this.scaleRadioButtonIcon(p6, 10, 10);
        this.scaleRadioButtonIcon(q5, 10, 10);
        this.scaleRadioButtonIcon(q6, 10, 10);
        this.scaleRadioButtonIcon(pq5, 10, 10);
        this.scaleRadioButtonIcon(pq6, 10, 10);

        //zero = new GridRadioButton(app, this, 189, 189, z, 0);
        q12 = new GridRadioButton(app, this, 69, 269, p2q, -1);
        q51 = new GridRadioButton(app, this, 109, 229, p2q, -0.5);
        q15 = new GridRadioButton(app, this, 269, 149, p2q, 0.5);
        q21 = new GridRadioButton(app, this, 309, 109, p2q, 1);

        p21 = new GridRadioButton(app, this, 109, 309, q2p, -1);
        p15 = new GridRadioButton(app, this, 149, 269, q2p, -0.5);
        p51 = new GridRadioButton(app, this, 229, 109, q2p, 0.5);
        p12 = new GridRadioButton(app, this, 269, 69, q2p, 1);

        slider.setBounds(29, 389, 349 - 29 + 20, 60);

        Hashtable typeLabels = new Hashtable();

        typeLabels.put(min, new JLabel("-∞"));
        typeLabels.put(n_t, new JLabel("-2"));
        typeLabels.put(harmo, new JLabel("-1"));
        typeLabels.put(harmo / 2, new JLabel("-0.5"));
        typeLabels.put(0, new JLabel("0"));
        typeLabels.put(addit / 2, new JLabel("0.5"));
        typeLabels.put(addit, new JLabel("1"));
        typeLabels.put(t, new JLabel("2"));
        typeLabels.put(max, new JLabel("∞"));

        //slider.setLabelTable(typeLabels);
        //slider.setPaintLabels(true);
        slider.setMinorTickSpacing(25);
        slider.setMajorTickSpacing(50);
        slider.setPaintTicks(true);

        ChangeListener cl = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = (double) slider.getValue();
                //between 1 and -1 :
                if (val <= addit && val >= harmo) {
                    val = val / (addit);
                    val = Math.round(val * 100) / 100.0;
                } //between 1 and 2 :
                else if (val > addit && val <= t) {
                    val = (val - addit) / (max / 4) + 1;
                    val = Math.round(val * 100) / 100.0;
                } //between -1 and -2 :
                else if (val < harmo && val >= n_t) {
                    val = (val - harmo) / (max / 4) - 1;
                    val = Math.round(val * 100) / 100.0;
                } //between 2 and +∞ :
                else if (val > t && val < max) {
                    val = 100 / ((max - t) - (val - t));
                    val = Math.round(val * 100) / 100.0;
                } //between -2 and -∞ :
                else if (val < n_t && val > min) {
                    val = 100 / ((min - n_t) - (val - n_t));
                    val = Math.round(val * 100) / 100.0;
                } //+∞ :
                else if (val == max) {
                    val = Double.POSITIVE_INFINITY;
                } //-∞ :
                else {
                    val = Double.NEGATIVE_INFINITY;
                }
                app.setType(val);
                if (val == Double.NEGATIVE_INFINITY) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p1);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q1);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq1);
                    }
                } else if (val == -2.0) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p2);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q2);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq2);
                    }
                } else if (val == -1.0) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p3);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q3);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq3);
                    }
                } else if (val == -0.5) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p4);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q4);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq4);
                    }
                } else if (val == 0) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p5);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q5);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq5);
                    }
                } else if (val == 0.5) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p7);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q7);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq7);
                    }
                } else if (val == 1.0) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p8);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q8);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq8);
                    }
                } else if (val == 2.0) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p9);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q9);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq9);
                    }
                } else if (val == Double.POSITIVE_INFINITY) {
                    if (app.selectedLaw == p) {
                        bg.setSelected(p10);
                    } else if (app.selectedLaw == q) {
                        bg.setSelected(q10);
                    } else if (app.selectedLaw == pq) {
                        bg.setSelected(pq10);
                    }
                } else {
                    bg.clearSelection();
                }
                text.setText(String.valueOf(val));
            }
        };
        slider.addChangeListener(cl);
        slider.setOpaque(false);
        panel.add(slider);

        text.setBounds(265, 270, 60, 25);
        text.setHorizontalAlignment(JTextField.CENTER);
        text.setText("" + app.DEFAULT_TYPE);
        text.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double val = (double) Double.parseDouble(text.getText());
                    slider.removeChangeListener(cl);
                    if (val <= 1.0 && val >= -1.0) {
                        slider.setValue((int) (val * addit));
                    } else if (val > 1.0 && val <= 2.0) {
                        slider.setValue((int) ((val - 1) * (max / 4) + addit));
                    } else if (val < -1.0 && val >= -2.0) {
                        slider.setValue((int) ((val + 1) * (max / 4) + harmo));
                    } else if (val > 2.0 && val <= 100) {
                        slider.setValue((int) Math.round(max - 100 / val));
                    } else if (val < -2.0 && val >= -100) {
                        slider.setValue((int) Math.round(min - 100 / val));
                    } else if (val > 100 && val <= 200) {
                        val = 100;
                        slider.setValue((int) Math.round(max - 100 / val));
                        text.setText("" + val);
                    } else if (val < -100 && val >= -200) {
                        val = -100;
                        slider.setValue((int) Math.round(min - 100 / val));
                        text.setText("" + val);
                    } else if (val > 200) {
                        val = Double.POSITIVE_INFINITY;
                        slider.setValue(max);
                        text.setText("" + val);
                    } else {
                        val = Double.NEGATIVE_INFINITY;
                        slider.setValue(min);
                        text.setText("" + val);
                    }
                    slider.addChangeListener(cl);
                    app.setType(val);
                    if (val == Double.NEGATIVE_INFINITY) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p1);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q1);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq1);
                        }
                    } else if (val == -2.0) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p2);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q2);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq2);
                        }
                    } else if (val == -1.0) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p3);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q3);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq3);
                        }
                    } else if (val == -0.5) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p4);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q4);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq4);
                        }
                    } else if (val == 0) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p5);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q5);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq5);
                        }
                    } else if (val == 0.5) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p7);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q7);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq7);
                        }
                    } else if (val == 1.0) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p8);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q8);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq8);
                        }
                    } else if (val == 2.0) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p9);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q9);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq9);
                        }
                    } else if (val == Double.POSITIVE_INFINITY) {
                        if (app.selectedLaw == p) {
                            bg.setSelected(p10);
                        } else if (app.selectedLaw == q) {
                            bg.setSelected(q10);
                        } else if (app.selectedLaw == pq) {
                            bg.setSelected(pq10);
                        }
                    } else {
                        bg.clearSelection();
                    }
                } catch (Exception ex) {
                }
            }
        }
        );

        panel.add(text);

        panel.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();

                boolean found = false;
                // Zero
                if (x > 179 && x < 219 && y > 179 && y < 219) {
                    found = true;
                    if (app.selectedLaw != z) {
                        if (app.selectedLaw instanceof QEqualsZero) {
                            ((Zero) z).setLaw(0);
                            app.setLaw(z, z.isInverse(), z.isUniform());
                            app.setType(0);
                            bg.setSelected(q5);
                            z0.setSelected(true);
                        }
                        else if (app.selectedLaw instanceof PEquals2Q) {
                            ((Zero) z).setLaw(1);
                            app.setLaw(z, z.isInverse(), z.isUniform());
                            app.setType(1);
                            bg.clearSelection();
                            z1.setSelected(true);
                        }
                        else if (app.selectedLaw instanceof PEqualsQ) {
                            ((Zero) z).setLaw(2);
                            app.setLaw(z, z.isInverse(), z.isUniform());
                            app.setType(2);
                            bg.setSelected(pq5);
                            z2.setSelected(true);
                        }
                        else if (app.selectedLaw instanceof QEquals2P) {
                            ((Zero) z).setLaw(3);
                            app.setLaw(z, z.isInverse(), z.isUniform());
                            app.setType(3);
                            bg.clearSelection();
                            z3.setSelected(true);
                        }
                        else if (app.selectedLaw instanceof PEqualsZero) {
                            ((Zero) z).setLaw(4);
                            app.setLaw(z, z.isInverse(), z.isUniform());
                            app.setType(4);
                            bg.setSelected(p5);
                            z4.setSelected(true);
                        }
                    }
                }

                if (!found) {
                    // Diagonal listener
                    for (int i = 0; i < 11; i++) {
                        for (int j = 0; j < 2; j++) {
                            if ((y - 204 + i + j) == -(x - 204 + i) && 29 < x && x < 349 && 29 < y && y < 349) {
                                found = true;
                                if (app.selectedLaw != pq) {
                                    app.setLaw(pq, pq.isInverse(), pq.isUniform());
                                }
                                if (x >= 339 && y <= 59) {
                                    bg.setSelected(pq10);
                                    app.setType(Double.POSITIVE_INFINITY);
                                    update(text, slider, Double.POSITIVE_INFINITY);
                                } else if (x >= 299 && y <= 99) {
                                    bg.setSelected(pq9);
                                    app.setType(2.0);
                                    update(text, slider, 2.0);
                                } else if (x >= 259 && y <= 139) {
                                    bg.setSelected(pq8);
                                    app.setType(1.0);
                                    update(text, slider, 1.0);
                                } else if (x >= 219 && y <= 179) {
                                    bg.setSelected(pq7);
                                    app.setType(0.5);
                                    update(text, slider, 0.5);
                                } else if (x <= 179 && x >= 139 && y >= 219 && y <= 259) {
                                    bg.setSelected(pq4);
                                    app.setType(-0.5);
                                    update(text, slider, -0.5);
                                } else if (x < 139 && x >= 99 && y > 259 && y <= 299) {
                                    bg.setSelected(pq3);
                                    app.setType(-1.0);
                                    update(text, slider, -1.0);
                                } else if (x < 99 && x >= 59 && y > 299 && y <= 339) {
                                    bg.setSelected(pq2);
                                    app.setType(-2.0);
                                    update(text, slider, -2.0);
                                } else if (x < 59 && y > 339) {
                                    bg.setSelected(pq1);
                                    app.setType(Double.NEGATIVE_INFINITY);
                                    update(text, slider, Double.NEGATIVE_INFINITY);
                                }
                            }
                        }
                    }
                }
                // X listener
                if (!found && 39 < x && x < 359 && 194 <= y && y <= 204) {
                    if (app.selectedLaw != q) {
                        app.setLaw(q, q.isInverse(), q.isUniform());
                    }
                    if (x <= 59) {
                        bg.setSelected(q1);
                        app.setType(Double.NEGATIVE_INFINITY);
                        update(text, slider, Double.NEGATIVE_INFINITY);
                    } else if (x <= 99) {
                        bg.setSelected(q2);
                        app.setType(-2.0);
                        update(text, slider, -2.0);
                    } else if (x <= 139) {
                        bg.setSelected(q3);
                        app.setType(-1.0);
                        update(text, slider, -1.0);
                    } else if (x <= 179) {
                        bg.setSelected(q4);
                        app.setType(-0.5);
                        update(text, slider, -0.5);
                    } else if (x >= 219 && x <= 259) {
                        bg.setSelected(q7);
                        app.setType(0.5);
                        update(text, slider, 0.5);
                    } else if (x > 259 && x <= 299) {
                        bg.setSelected(q8);
                        app.setType(1.0);
                        update(text, slider, 1.0);
                    } else if (x > 299 && x <= 339) {
                        bg.setSelected(q9);
                        app.setType(2.0);
                        update(text, slider, 2.0);
                    } else if (x > 339) {
                        bg.setSelected(q10);
                        app.setType(Double.POSITIVE_INFINITY);
                        update(text, slider, Double.POSITIVE_INFINITY);
                    }
                } // Y listener
                else if (!found && 39 < y && y < 359 && 194 <= x && x <= 204) {
                    if (app.selectedLaw != p) {
                        app.setLaw(p, p.isInverse(), p.isUniform());
                    }
                    if (y <= 59) {
                        bg.setSelected(p10);
                        app.setType(Double.POSITIVE_INFINITY);
                        update(text, slider, Double.POSITIVE_INFINITY);
                    } else if (y <= 99) {
                        bg.setSelected(p9);
                        app.setType(2.0);
                        update(text, slider, 2.0);
                    } else if (y <= 139) {
                        bg.setSelected(p8);
                        app.setType(1.0);
                        update(text, slider, 1.0);
                    } else if (y <= 179) {
                        bg.setSelected(p7);
                        app.setType(0.5);
                        update(text, slider, 0.5);
                    } else if (y >= 219 && y <= 259) {
                        bg.setSelected(p4);
                        app.setType(-0.5);
                        update(text, slider, -0.5);
                    } else if (y > 259 && y <= 299) {
                        bg.setSelected(p3);
                        app.setType(-1.0);
                        update(text, slider, -1.0);
                    } else if (y > 299 && y <= 339) {
                        bg.setSelected(p2);
                        app.setType(-2.0);
                        update(text, slider, -2.0);
                    } else if (y > 339) {
                        bg.setSelected(p1);
                        app.setType(Double.NEGATIVE_INFINITY);
                        update(text, slider, Double.NEGATIVE_INFINITY);
                    }

                } //Max listener
                else if (!found && 119 < y && y <= 199 && 349 <= x && x <= 369) {
                    app.setLaw(q, q.isInverse(), q.isUniform());
                    app.setType(Double.POSITIVE_INFINITY);
                    bg.setSelected(q10);
                    update(text, slider, Double.POSITIVE_INFINITY);
                } else if ((49 <= y && y <= 119 && 349 <= x && x <= 369) || (29 <= y && y <= 49 && 279 <= x && x <= 349)) {
                    app.setLaw(pq, pq.isInverse(), pq.isUniform());
                    app.setType(Double.POSITIVE_INFINITY);
                    bg.setSelected(pq10);
                    update(text, slider, Double.POSITIVE_INFINITY);
                } else if (29 <= y && y <= 49 && 199 <= x && x < 279) {
                    app.setLaw(p, p.isInverse(), p.isUniform());
                    app.setType(Double.POSITIVE_INFINITY);
                    bg.setSelected(p10);
                    update(text, slider, Double.POSITIVE_INFINITY);
                } //Min listener
                else if (!found && 199 <= y && y < 279 && 29 <= x && x <= 49) {
                    app.setLaw(q, q.isInverse(), q.isUniform());
                    app.setType(Double.NEGATIVE_INFINITY);
                    bg.setSelected(q1);
                    update(text, slider, Double.NEGATIVE_INFINITY);
                } else if ((279 <= y && y <= 349 && 29 <= x && x <= 49) || (349 <= y && y <= 369 && 49 <= x && x <= 119)) {
                    app.setLaw(pq, pq.isInverse(), pq.isUniform());
                    app.setType(Double.NEGATIVE_INFINITY);
                    bg.setSelected(pq1);
                    update(text, slider, Double.NEGATIVE_INFINITY);
                } else if (349 <= y && y <= 369 && 119 < x && x <= 199) {
                    app.setLaw(p, p.isInverse(), p.isUniform());
                    app.setType(Double.NEGATIVE_INFINITY);
                    bg.setSelected(p1);
                    update(text, slider, Double.NEGATIVE_INFINITY);
                }
            }
        });

        //sideFrame.pack();
        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

        //sideFrame.setSize(panelSizeX, panelSizeY);
        this.setMinimumSize(new Dimension(panelSizeX, panelSizeY));
        this.setLocation((int) maximumWindowBounds.getWidth() - this.getWidth() - 10, (int) maximumWindowBounds.getHeight() / 2 - this.getHeight() / 2);
        this.setVisible(true);
    }

    public JSlider getSlider() {
        return slider;
    }

    public JSlider getZeroSlider() {
        return zeroSlider;
    }

    public JTextField getTextField() {
        return text;
    }

    public BackPanel getPanel() {
        return panel;
    }

    public JPanel getZeroPanel() {
        return zeroPanel;
    }

    public JPanel getButtonSliderPanel() {
        return buttonSliderPanel;
    }

    public GridButtonGroup getButtonGroup() {
        return bg;
    }

    public JLabel getVariableLabel() {
        return variableLabel;
    }

    public void update(JSlider s, double val) {

        int max = 200;
        int min = -max;
        int addit = max / 2;
        int harmo = min / 2;
        ChangeListener cl = s.getChangeListeners()[0];
        s.removeChangeListener(cl);
        if (val <= 1.0 && val >= -1.0) {
            s.setValue((int) (val * addit));
        } else if (val > 1.0 && val <= 2.0) {
            s.setValue((int) ((val - 1) * (max / 4) + addit));
        } else if (val < -1.0 && val >= -2.0) {
            s.setValue((int) ((val + 1) * (max / 4) + harmo));
        } else if (val > 2.0 && val <= 100) {
            s.setValue((int) Math.round(max - 100 / val));
        } else if (val < -2.0 && val >= -100) {
            s.setValue((int) Math.round(min - 100 / val));
        } else if (val > 100 && val <= 200) {
            val = 100;
            s.setValue((int) Math.round(max - 100 / val));
        } else if (val < -100 && val >= -200) {
            val = -100;
            s.setValue((int) Math.round(min - 100 / val));
        } else if (val > 200) {
            val = Double.POSITIVE_INFINITY;
            s.setValue(max);
        } else {
            val = Double.NEGATIVE_INFINITY;
            s.setValue(min);
        }
        s.addChangeListener(cl);
    }

    public void update(JTextField t, double val) {
        t.setText("" + val);
    }

    public void update(JTextField t, JSlider s, double val) {
        update(s, val);
        update(t, val);
    }

    public static void scaleRadioButtonIcon(JRadioButton rb, int width, int height) {
        boolean previousState = rb.isSelected();
        rb.setSelected(false);
        //FontMetrics boxFontMetrics =  rb.getFontMetrics(rb.getFont());
        Icon radioIcon = UIManager.getIcon("RadioButton.icon");
        BufferedImage radioImage = new BufferedImage(
                radioIcon.getIconWidth(), radioIcon.getIconHeight(), BufferedImage.TYPE_INT_ARGB
        );
        Graphics graphics = radioImage.createGraphics();
        try {
            radioIcon.paintIcon(rb, graphics, 0, 0);
        } finally {
            graphics.dispose();
        }
        ImageIcon newRadioImage = new ImageIcon(radioImage);
        Image finalRadioImage = newRadioImage.getImage().getScaledInstance(
                height, height, Image.SCALE_SMOOTH
        );

        rb.setSelected(true);
        Icon selectedRadioIcon = UIManager.getIcon("RadioButton.icon");
        BufferedImage selectedRadioImage = new BufferedImage(
                selectedRadioIcon.getIconWidth(), selectedRadioIcon.getIconHeight(), BufferedImage.TYPE_INT_ARGB
        );
        Graphics selectedGraphics = selectedRadioImage.createGraphics();
        try {
            selectedRadioIcon.paintIcon(rb, selectedGraphics, 0, 0);
        } finally {
            selectedGraphics.dispose();
        }
        ImageIcon newSelectedRadioImage = new ImageIcon(selectedRadioImage);
        Image selectedFinalRadioImage = newSelectedRadioImage.getImage().getScaledInstance(
                height, height, Image.SCALE_SMOOTH
        );
        rb.setSelected(previousState);
        rb.setIcon(new ImageIcon(finalRadioImage));
        rb.setSelectedIcon(new ImageIcon(selectedFinalRadioImage));
    }
}
