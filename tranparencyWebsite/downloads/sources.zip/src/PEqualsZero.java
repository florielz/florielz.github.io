
public class PEqualsZero extends TransparencyLaw {

    private PEqualsZero associatedLaw;

    @Override
    public String getName() {
        return "f(x) = 1 / (1-x)^p";
    }
    
    @Override
    public String getName(double val) {
        if (val == 0) {
            return "f(x) = ln(1 / (1-x))";
        }
        return this.getName();
    }

    @Override
    public String getFunction() {
        return "f(x) = 1 / (1-x)<sup>p</sup>";
    }

    @Override
    public String getFunction(double val) {
        if (val == 2) {
            return "f(x) = 1 / (1-x)<sup>2</sup>";
        } else if (val == 1) {
            return "f(x) = 1 / (1-x)";
        } else if (val == 0.5) {
            return "f(x) = 1 / (1-x)<sup>0.5</sup>";
        } else if (val == 0) {
            return "f(x) = ln(1 / (1-x))";
        } else if (val == -0.5) {
            return "f(x) = (1-x)<sup>0.5</sup>";
        } else if (val == -1) {
            return "f(x) = 1-x ";
        } else if (val == -2) {
            return "f(x) = (1-x)<sup>2</sup>";
        } else {
            return "f(x) = 1 / (1-x)<sup>p</sup>";
        }
    }

    @Override
    public TransparencyLaw associatedLaw() {
        if (associatedLaw == null) {
            associatedLaw = new PEqualsZero();
        }
        return associatedLaw;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        if (this.inverse) {
            return fInverse((f(back, t) - (1.0 - c) * f(front, t)) / c, t);
        } else if (t == 0.0) {
            return (1.0 - 1.0 / (Math.pow(1.0 / (1.0 - back), c) * Math.pow(1.0 / (1.0 - front), 1.0 - c)));
        } else if (t == Double.POSITIVE_INFINITY) {
            if (c == 0) {
                return front;
            } else if (c == 1) {
                return back;
            } else {
                return Math.max(back, front);
            }
        } else if (t == Double.NEGATIVE_INFINITY) {
            if (c == 0) {
                return front;
            } else if (c == 1) {
                return back;
            } else {
                return Math.min(back, front);
            }
        } else {
            return (fInverse(c * f(back, t) + (1.0 - c) * f(front, t), t));
        }
    }

    @Override
    public double f(double x, double t) {
        if (t == 0) {
            return (Math.log(1.0 / (1.0 - x)));
        } else {
            return (1.0 / (Math.pow(1.0 - x, t)));
        }
    }

    @Override
    public double fInverse(double x, double t) {
        if (t == 0) {
            return (Math.exp(-x) * (Math.exp(x) - 1.0));
        } else {
            return (1.0 - 1.0 / (Math.pow(x, 1.0 / t)));
        }
    }
}
