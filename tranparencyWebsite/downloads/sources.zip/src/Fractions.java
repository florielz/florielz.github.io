import java.awt.*;
import javax.swing.*;
        
public class Fractions extends Box{

    public Fractions (JLabel a, JLabel b, int t){
        super(BoxLayout.PAGE_AXIS);
        a.setHorizontalAlignment(JLabel.CENTER);
        b.setHorizontalAlignment(JLabel.CENTER);
        
        Box b1 = Box.createHorizontalBox();
        Box b2 = Box.createHorizontalBox();
        Box b3 = Box.createHorizontalBox();
        
        b1.add(Box.createHorizontalGlue());
        b1.add(a);
        b1.add(Box.createHorizontalGlue());
        
        b2.add(Box.createHorizontalGlue());
        Box line = Box.createHorizontalBox();
        line.add(Box.createRigidArea(new Dimension(t, 1)));
        line.setOpaque(true);
        line.setBackground(Color.black);
        //line.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        b2.add(line);
        b2.add(Box.createHorizontalGlue());
        
        b3.add(Box.createHorizontalGlue());
        b3.add(b);
        b3.add(Box.createHorizontalGlue());
        
        
        this.add(b1);
        this.add(b2);
        this.add(b3);
    }
}
