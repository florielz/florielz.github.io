
import java.util.*;
import javax.swing.*;

public class GridButtonGroup {

    protected ArrayList<GridRadioButton> v;

    public GridButtonGroup() {
        v = new ArrayList<>();
    }

    public void add(GridRadioButton b) {
        v.add(b);
    }

    public void clearSelection() {
        for (GridRadioButton grb : v) {
            grb.setSelected(false);
        }
    }

    public void setSelected(GridRadioButton b) {
        b.setSelected(true);
        if (b.getValue() == 0) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == b.getValue() && grb.getLaw() == b.getLaw()) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == 1 && b.getLaw() instanceof QEqualsZero) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == -1 && grb.getLaw() instanceof PEqualsZero) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == -1 && b.getLaw() instanceof PEqualsZero) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == 1 && grb.getLaw() instanceof QEqualsZero) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == 1 && b.getLaw() instanceof PEqualsZero) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == 1 && grb.getLaw() instanceof PEqualsQ) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == 1 && b.getLaw() instanceof PEqualsQ) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == 1 && grb.getLaw() instanceof PEqualsZero) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == -1 && b.getLaw() instanceof PEqualsQ) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == -1 && grb.getLaw() instanceof QEqualsZero) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == -1 && b.getLaw() instanceof QEqualsZero) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == -1 && grb.getLaw() instanceof PEqualsQ) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == Double.POSITIVE_INFINITY) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == Double.POSITIVE_INFINITY) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else if (b.getValue() == Double.NEGATIVE_INFINITY) {
            for (GridRadioButton grb : v) {
                if (grb.getValue() == Double.NEGATIVE_INFINITY) {
                    grb.setSelected(true);
                } else if (grb != b) {
                    grb.setSelected(false);
                }
            }
        } else {
            for (GridRadioButton grb : v) {
                if (grb != b) {
                    grb.setSelected(false);
                }
            }
        }
    }
}
