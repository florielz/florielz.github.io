
public class TransparencyLaws {

    public static final TransparencyLaw ADDITIVE_SUBTRACTIVE = new AdditiveSubtractive();
    public static final TransparencyLaw SUBTRACTIVE_ADDITIVE = new SubtractiveAdditive();

    public static final TransparencyLaw DIRECT_UNIFORM = new DirectUniform();
    public static final TransparencyLaw DIRECT_NON_UNIFORM = new DirectNonUniform();
    
    public static final TransparencyLaw Q_EQUALS_ZERO = new QEqualsZero();
    public static final TransparencyLaw P_EQUALS_ZERO = new PEqualsZero();
    public static final TransparencyLaw P_EQUALS_Q = new PEqualsQ();
    public static final TransparencyLaw P_EQUALS_2Q = new PEquals2Q();
    public static final TransparencyLaw Q_EQUALS_2P = new QEquals2P();
    public static final TransparencyLaw ZERO = new Zero();

    public static final TransparencyLaw INVERSE_UNIFORM = new InverseUniform();
    public static final TransparencyLaw INVERSE_NON_UNIFORM = new InverseNonUniform();
    
    public static final TransparencyLaw KUBELKA = new Kubelka();
    public static final TransparencyLaw NON_SCATTERING = new NonScattering();
}
