
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

public class LittleFrame extends JFrame {

    private LimitedSlider alphaSlider;
    private LimitedSlider betaSlider;
    private JLabel title;
    private JLabel alphaLabel;
    private JLabel betaLabel;
    private JTextField alphaText;
    private JTextField betaText;
    private LittleIcon icon;
    private JCheckBox scatteringBox;
    private ThirdApplication app;

    public LittleFrame(ThirdApplication app) {
        super("Unit Thickness Layer Reflection");
        this.app = app;
        this.title = new JLabel("Unit Thickness Layer Reflection");
        this.title.setFont(new Font(this.title.getFont().getFontName(), Font.BOLD, 14));
        this.scatteringBox = new JCheckBox("Non-scattering layer");
        this.alphaLabel = new JLabel("Proportion of opaque foreground");
        this.betaLabel = new JLabel("Part of achromatic reflection");
        this.alphaText = new JTextField();
        this.betaText = new JTextField();
        this.icon = new LittleIcon(100, 100);
        update(ThirdApplication.DEFAULT_ALPHA, ThirdApplication.DEFAULT_BETA, app.getFrontSource());

//ScatteringBox ================================================================
        this.scatteringBox.setFocusPainted(false);
        this.scatteringBox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                app.changeLaw();
                app.littleDisabledPanel.setEnabled(!scatteringBox.isSelected() && (app.isInverse() || app.isUniform()));
                if(scatteringBox.isSelected()){
                    nonScatteringUpdate(app.getFrontSource());
                }
                else{
                    update(app.getAlpha(),app.getBeta(), app.getFrontSource());
                }
            }
        });

//Alpha Slider ================================================================= 
        this.alphaSlider = new LimitedSlider(JSlider.VERTICAL, 0, 100, (int) (100.0 * ThirdApplication.DEFAULT_ALPHA - 1.0), app);
        Hashtable alphaLabels = new Hashtable();
        alphaLabels.put(0, new JLabel("0%"));
        alphaLabels.put(100, new JLabel("100%"));
        this.alphaSlider.setLabelTable(alphaLabels);
        this.alphaSlider.setPaintLabels(true);
        this.alphaSlider.setMinorTickSpacing(10);
        this.alphaSlider.setMajorTickSpacing(20);
        this.alphaSlider.setPaintTicks(true);
        this.alphaSlider.setOpaque(false);
        //this.alphaSlider.setValueIsAdjusting(true);

        ChangeListener aCL = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = alphaSlider.getValue() / 100.0;
                double beta = app.getBeta();
                double red = ((253.0 * app.getFrontSource().getPixel(0, 0).getRed() + 255.0) / (255.0 * 255.0));
                double green = ((253.0 * app.getFrontSource().getPixel(0, 0).getGreen() + 255.0) / (255.0 * 255.0));
                double blue = ((253.0 * app.getFrontSource().getPixel(0, 0).getBlue() + 255.0) / (255.0 * 255.0));

                double r = 1.0 - (beta / red);
                double g = 1.0 - (beta / green);
                double b = 1.0 - (beta / blue);

                if (app.getFrontSource() instanceof ColorSource && ((val >= r) || (val >= g) || (val >= b)) && ((r <= (1.0 - beta)) || (g <= (1.0 - beta)) || (b <= (1.0 - beta)))) {
                    if ((r <= g) && (r <= b)) {
                        alphaSlider.setValue((int) ((r - 0.01) * 100.0));
                        //val = r - 0.01;
                    } else if ((g <= r) && (g <= b)) {
                        alphaSlider.setValue((int) ((g - 0.01) * 100.0));
                        //val = g - 0.01;
                    } else if ((b <= g) && (b <= r)) {
                        alphaSlider.setValue((int) ((b - 0.01) * 100.0));
                        //val = b - 0.01;
                    }
                } else if (val >= (1.0 - app.getBeta())) {
                    alphaSlider.setValue((int) ((1.0 - app.getBeta() - 0.01) * 100.0));
                    //val = 1.0 - app.getBeta();
                } else {
                    app.setAlpha(val);
                    alphaText.setText("" + (int) (val * 100.0));
                    betaSlider.update(app.getAlpha(), -1, app.getFrontSource(), red, green, blue);
                }

            }
        };
        this.alphaSlider.addChangeListener(aCL);

//Beta Slider ==================================================================
        this.betaSlider = new LimitedSlider(JSlider.VERTICAL, 0, 100, (int) (100.0 * ThirdApplication.DEFAULT_BETA + 1.0), app);
        Hashtable betaLabels = new Hashtable();
        betaLabels.put(0, new JLabel("0%"));
        betaLabels.put(100, new JLabel("100%"));
        this.betaSlider.setLabelTable(betaLabels);
        this.betaSlider.setPaintLabels(true);
        this.betaSlider.setMinorTickSpacing(10);
        this.betaSlider.setMajorTickSpacing(20);
        this.betaSlider.setPaintTicks(true);
        this.betaSlider.setOpaque(false);
        //this.betaSlider.setValueIsAdjusting(true);

        ChangeListener bCL = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = betaSlider.getValue() / 100.0;
                double alpha = app.getAlpha();
                double red = ((253.0 * app.getFrontSource().getPixel(0, 0).getRed() + 255.0) / (255.0 * 255.0));
                double green = ((253.0 * app.getFrontSource().getPixel(0, 0).getGreen() + 255.0) / (255.0 * 255.0));
                double blue = ((253.0 * app.getFrontSource().getPixel(0, 0).getBlue() + 255.0) / (255.0 * 255.0));

                double r = (1.0 - alpha) * red;
                double g = (1.0 - alpha) * green;
                double b = (1.0 - alpha) * blue;

                if (app.getFrontSource() instanceof ColorSource && ((val >= r) || (val >= g) || (val >= b)) && ((r <= (1.0 - alpha)) || (g <= (1.0 - alpha)) || (b <= (1.0 - alpha)))) {
                    if ((r <= g) && (r <= b)) {
                        betaSlider.setValue((int) ((r - 0.01) * 100.0));
                        //val = r - 0.01;
                    } else if ((g <= r) && (g <= b)) {
                        betaSlider.setValue((int) ((g - 0.01) * 100.0));
                        //val = g - 0.01;
                    } else if ((b <= g) && (b <= r)) {
                        betaSlider.setValue((int) ((b - 0.01) * 100.0));
                        //val = b - 0.01;
                    }
                } else if (val >= (1.0 - alpha)) {
                    betaSlider.setValue((int) ((1.0 - alpha - 0.01) * 100.0));
                    //val = 1.0 - alpha;
                } else {
                    app.setBeta(val);
                    betaText.setText("" + (int) (val * 100.0));
                    alphaSlider.update(-1, app.getBeta(), app.getFrontSource(), red, green, blue);
                }

            }
        };
        this.betaSlider.addChangeListener(bCL);

//Alpha Text ===================================================================
        alphaText.setPreferredSize(new Dimension(30, 20));
        alphaText.setMaximumSize(new Dimension(30, 20));
        alphaText.setHorizontalAlignment(JTextField.CENTER);
        alphaText.setText("" + ThirdApplication.DEFAULT_ALPHA);
        alphaText.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double val = (double) Double.parseDouble(alphaText.getText());
                    alphaSlider.setValue((int) (val));
                } catch (Exception ex) {
                }
            }
        }
        );

//Beta Text ===================================================================
        betaText.setPreferredSize(new Dimension(30, 20));
        betaText.setMaximumSize(new Dimension(30, 20));
        betaText.setHorizontalAlignment(JTextField.CENTER);
        betaText.setText("" + ThirdApplication.DEFAULT_BETA);
        betaText.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double val = (double) Double.parseDouble(betaText.getText());
                    betaSlider.setValue((int) (val));
                } catch (Exception ex) {
                }
            }
        }
        );

//Display ====================================================================== 
        Box c1Box = Box.createHorizontalBox();
        c1Box.add(Box.createHorizontalGlue());
        c1Box.add(Box.createRigidArea(new Dimension(20, 0)));
        c1Box.add(title);
        c1Box.add(Box.createRigidArea(new Dimension(20, 0)));
        c1Box.add(Box.createHorizontalGlue());

        Box c9Box = Box.createHorizontalBox();
        c9Box.add(Box.createHorizontalGlue());
        c9Box.add(scatteringBox);
        c9Box.add(Box.createHorizontalGlue());

        Box border = Box.createHorizontalBox();
        border.add(Box.createHorizontalGlue());
        border.setBorder(BorderFactory.createRaisedBevelBorder());

        Box border2 = Box.createHorizontalBox();
        border2.add(Box.createHorizontalGlue());
        border2.setBorder(BorderFactory.createRaisedBevelBorder());

        //AlphaBox =============================================================
        Box alphaBox = Box.createVerticalBox();

        Box c3Box = Box.createHorizontalBox();
        c3Box.add(Box.createHorizontalGlue());
        c3Box.add(alphaLabel);
        c3Box.add(Box.createHorizontalGlue());

        Box c4Box = Box.createHorizontalBox();
        c4Box.add(Box.createHorizontalGlue());
        c4Box.add(alphaSlider);
        c4Box.add(Box.createHorizontalGlue());

        Box c5Box = Box.createHorizontalBox();
        c5Box.add(Box.createHorizontalGlue());
        c5Box.add(alphaText);
        c5Box.add(new JLabel("%"));
        c5Box.add(Box.createHorizontalGlue());

        alphaBox.add(c3Box);
        alphaBox.add(Box.createRigidArea(new Dimension(0, 10)));
        alphaBox.add(c4Box);
        alphaBox.add(Box.createRigidArea(new Dimension(0, 10)));
        alphaBox.add(c5Box);

        //BetaBox ==============================================================
        Box betaBox = Box.createVerticalBox();

        Box c6Box = Box.createHorizontalBox();
        c6Box.add(Box.createHorizontalGlue());
        c6Box.add(betaLabel);
        c6Box.add(Box.createHorizontalGlue());

        Box c7Box = Box.createHorizontalBox();
        c7Box.add(Box.createHorizontalGlue());
        c7Box.add(betaSlider);
        c7Box.add(Box.createHorizontalGlue());

        Box c8Box = Box.createHorizontalBox();
        c8Box.add(Box.createHorizontalGlue());
        c8Box.add(betaText);
        c8Box.add(new JLabel("%"));
        c8Box.add(Box.createHorizontalGlue());

        betaBox.add(c6Box);
        betaBox.add(Box.createRigidArea(new Dimension(0, 10)));
        //betaBox.add(new JLabel("1"));
        betaBox.add(c7Box);
        //betaBox.add(new JLabel("0"));
        betaBox.add(Box.createRigidArea(new Dimension(0, 10)));
        betaBox.add(c8Box);

        // =====================================================================
        Box c2Box = Box.createHorizontalBox();
        c2Box.add(Box.createRigidArea(new Dimension(20, 0)));
        c2Box.add(alphaBox);
        c2Box.add(Box.createRigidArea(new Dimension(10, 0)));
        Box border1 = Box.createVerticalBox();
        border1.add(Box.createVerticalGlue());
        border1.setBorder(BorderFactory.createRaisedBevelBorder());
        c2Box.add(border1);
        c2Box.add(Box.createRigidArea(new Dimension(10, 0)));
        c2Box.add(betaBox);
        c2Box.add(Box.createRigidArea(new Dimension(10, 0)));

        Box disabledBox = Box.createVerticalBox();
        disabledBox.add(Box.createRigidArea(new Dimension(0, 10)));
        disabledBox.add(c2Box);
        disabledBox.add(Box.createRigidArea(new Dimension(0, 10)));
        app.littleDisabledPanel = new DisabledPanel(disabledBox);

        Box mainBox = Box.createVerticalBox();
        mainBox.add(Box.createRigidArea(new Dimension(0, 6)));
        mainBox.add(c1Box);
        mainBox.add(Box.createRigidArea(new Dimension(0, 6)));
        mainBox.add(c9Box);
        mainBox.add(Box.createRigidArea(new Dimension(0, 6)));
        mainBox.add(border);
        mainBox.add(app.littleDisabledPanel);
        mainBox.add(border2);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));
        mainBox.add(icon);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));

        this.add(mainBox);

        this.alphaSlider.setValue((int) (app.getAlpha() * 100.0));
        this.betaSlider.setValue((int) (app.getBeta() * 100.0));
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        this.setResizable(false);
        this.setVisible(true);
        this.pack();
    }
    
    public void nonScatteringUpdate(Source frontSource){
        if (frontSource instanceof ImageSource) {
            Dimension d = frontSource.getSourceSize();
            Dimension max = new Dimension(100, 100);
            Utility.fitDimension(d, max);
            BufferedImage resultImage = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);
            for (int y = 0; y < d.height; y++) {
                for (int x = 0; x < d.width; x++) {
                    Color color = Color.BLACK;
                    resultImage.setRGB(x, y, color.getRGB());
                }
            }

            this.icon.setImage(resultImage);
        } else {
            this.icon.setColor(Color.BLACK);
        }
    }

    public void update(double alpha, double beta, Source frontSource) {
        if (frontSource instanceof ImageSource) {
            Dimension d = frontSource.getSourceSize();
            Dimension max = new Dimension(100, 100);
            Utility.fitDimension(d, max);
            BufferedImage resultImage = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);
            for (int y = 0; y < d.height; y++) {
                for (int x = 0; x < d.width; x++) {
                    float rx = x / (d.width - 1.0f);
                    float ry = y / (d.height - 1.0f);
                    Color front = frontSource.getPixel(rx, ry);
                    double r = alpha * ((253.0 * front.getRed() + 255.0) / (255.0 * 255.0)) + beta;
                    int red = (int) Math.round((255.0 * (255.0 * r - 1.0)) / 253.0);
                    double g = alpha * ((253.0 * front.getGreen() + 255.0) / (255.0 * 255.0)) + beta;
                    int green = (int) Math.round((255.0 * (255.0 * g - 1.0)) / 253.0);
                    double b = alpha * ((253.0 * front.getBlue() + 255.0) / (255.0 * 255.0)) + beta;
                    int blue = (int) Math.round((255.0 * (255.0 * b - 1.0)) / 253.0);

                    if (red == -1) {
                        red = 0;
                    }
                    if (green == -1) {
                        green = 0;
                    }
                    if (blue == -1) {
                        blue = 0;
                    }
                    if (red == 256) {
                        red = 255;
                    }
                    if (green == 256) {
                        green = 255;
                    }
                    if (blue == 256) {
                        blue = 255;
                    }
                    Color color = new Color(red, green, blue);
                    resultImage.setRGB(x, y, color.getRGB());
                }
            }

            this.icon.setImage(resultImage);
        } else {
            Color front = frontSource.getPixel(0, 0);
            double r = alpha * ((253.0 * front.getRed() + 255.0) / (255.0 * 255.0)) + beta;
            int red = (int) Math.round((255.0 * (255.0 * r - 1.0)) / 253.0);
            double g = alpha * ((253.0 * front.getGreen() + 255.0) / (255.0 * 255.0)) + beta;
            int green = (int) Math.round((255.0 * (255.0 * g - 1.0)) / 253.0);
            double b = alpha * ((253.0 * front.getBlue() + 255.0) / (255.0 * 255.0)) + beta;
            int blue = (int) Math.round((255.0 * (255.0 * b - 1.0)) / 253.0);

            if (red == -1) {
                red = 0;
            }
            if (green == -1) {
                green = 0;
            }
            if (blue == -1) {
                blue = 0;
            }
            if (red == 256) {
                red = 255;
            }
            if (green == 256) {
                green = 255;
            }
            if (blue == 256) {
                blue = 255;
            }
            this.icon.setColor(new Color(red, green, blue));
        }
    }

    public void updateSliders(double alpha, double beta) {
        betaSlider.setValue(0);
        alphaSlider.setValue(0);
        alphaSlider.setValue((int) (alpha * 100.0));
        betaSlider.setValue((int) (beta * 100.0));
    }

    public void expectedMode() {
        betaSlider.setValue(0);
        betaSlider.setEnabled(false);
        betaText.setEnabled(false);
    }

    public void expectedMode(int beta) {
        betaSlider.setValue(beta);
        betaSlider.setEnabled(true);
        betaText.setEnabled(true);
    }

    public void updateColor(Color color) {
        alphaSlider.setColor(color);
        betaSlider.setColor(color);
        alphaSlider.repaint();
        betaSlider.repaint();
    }
}
