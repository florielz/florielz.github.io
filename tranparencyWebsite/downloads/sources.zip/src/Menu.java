
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

enum SourcePos {
    BACK,
    FRONT;

    public String getName() {
        switch (this) {
            case BACK:
                return "Background";
            case FRONT:
                return "Foreground";
            default:
                return null;
        }
    }
};

public class Menu {

    public FirstApplication firstApp;
    public SecondApplication secondApp;
    public ThirdApplication thirdApp;

    private JRadioButton button360;
    private JRadioButton button480;
    private JRadioButton button640;
    private JCheckBox bordersCheckbox;
    private JCheckBox highlightCheckbox;
    private JCheckBox infoFileCheckbox;
    private String saveDirectory;

    private boolean bordersEnabled;
    private boolean enableInfoFile;
    private boolean highlightInvalidPixels;
    private Color invalidColor;
    private int width;

    private static final String WEBSITE_URL = "http://rgbtransparency.edel.univ-poitiers.fr";
    private static final String MANUAL_FILENAME = "resources/manual.html";
    private JDialog manualDialog;
    private JDialog settingsDialog;
    private JFrame frame;

    public Menu() throws IOException {
        this.frame = new JFrame("Interactive RGB Transparency");

        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader("transparency_settings.properties"));
            br.readLine();
            this.bordersEnabled = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.enableInfoFile = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.highlightInvalidPixels = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.saveDirectory = br.readLine();
            br.readLine();
            this.width = Integer.parseInt(br.readLine());
            br.close();
        } catch (FileNotFoundException e) {
            this.bordersEnabled = true;
            this.enableInfoFile = true;
            this.highlightInvalidPixels = true;
            this.saveDirectory = ".";
            this.width = 480;
        } catch (Exception e) {
        }
        this.invalidColor = Color.RED;
        this.frame.setJMenuBar(this.makeMenu());
        this.loadSettings();
        this.loadManual();

        //set all components in english
        java.util.Locale.setDefault(java.util.Locale.ENGLISH);
        javax.swing.UIManager.getDefaults().setDefaultLocale(java.util.Locale.ENGLISH);
        javax.swing.JComponent.setDefaultLocale(java.util.Locale.ENGLISH);

        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

        JLabel first = new JLabel("<html><center>From subtractive<br/>to<br/>additive transparency</center></html>");
        JLabel second = new JLabel("<html><center>Transparency as<br/>generalized f-mean</center></html>");
        JLabel third = new JLabel("<html><center>Translucency<br/>by<br/>a scattering layer</center></html>");

        first.setFont(new Font(first.getFont().getFontName(), first.getFont().getStyle(), 12));
        second.setFont(new Font(second.getFont().getFontName(), second.getFont().getStyle(), 12));
        third.setFont(new Font(third.getFont().getFontName(), third.getFont().getStyle(), 12));

        Menu a = this;

        Box right = Box.createVerticalBox();
        Box left = Box.createVerticalBox();
        Box topLeft = Box.createVerticalBox();
        Box botLeft = Box.createVerticalBox();

        Color f = new Color(144, 213, 152);
        Color s = new Color(154, 227, 224);
        Color t = new Color(165, 181, 231);

        first.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, f, f),
                BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
        second.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, s, s),
                BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
        third.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, t, t),
                BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));

        first.addMouseListener(new MouseListener() {
            public void mouseReleased(MouseEvent e) {
                first.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, f, f),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                firstApp = new FirstApplication(a);
                firstApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                frame.dispose();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                first.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.WHITE, Color.WHITE, f, f),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                first.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, f, f),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, f, f, f, f)));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                first.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, f, f),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }
        });

        second.addMouseListener(new MouseListener() {
            public void mouseReleased(MouseEvent e) {
                second.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, s, s),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    secondApp = new SecondApplication(a);
                    secondApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                    frame.dispose();
                } catch (IOException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
                second.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.WHITE, Color.WHITE, s, s),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                second.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, s, s),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, s, s, s, s)));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                second.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, s, s),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }
        });

        third.addMouseListener(new MouseListener() {
            public void mouseReleased(MouseEvent e) {
                third.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, t, t),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                thirdApp = new ThirdApplication(a);
                thirdApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                frame.dispose();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                third.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.WHITE, Color.WHITE, t, t),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                third.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, t, t),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, t, t, t, t)));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                third.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, t, t),
                        BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE)));
            }
        });

        Box c1Box = Box.createHorizontalBox();
        Box c2Box = Box.createHorizontalBox();
        Box c3Box = Box.createHorizontalBox();

        c1Box.add(Box.createRigidArea(new Dimension(40, 0)));
        c1Box.add(first);
        c1Box.add(Box.createHorizontalGlue());

        c2Box.add(Box.createHorizontalGlue());
        c2Box.add(second);
        c2Box.add(Box.createHorizontalGlue());

        c3Box.add(Box.createHorizontalGlue());
        c3Box.add(Box.createRigidArea(new Dimension(18, 0)));
        c3Box.add(third);
        c3Box.add(Box.createRigidArea(new Dimension(50, 0)));
        c3Box.add(Box.createHorizontalGlue());

        topLeft.add(c1Box);
        botLeft.add(c3Box);

        left.add(Box.createRigidArea(new Dimension(0, 25)));
        left.add(topLeft);
        left.add(Box.createRigidArea(new Dimension(0, 95)));
        left.add(botLeft);

        right.add(Box.createRigidArea(new Dimension(0, 120)));
        right.add(c2Box);

        Box bigBox = Box.createVerticalBox();

        Image backgroundImage = ImageIO.read(this.getClass().getResource("resources/menu.png"));
        Box midBox = new Box(BoxLayout.LINE_AXIS) {
            @Override
            public void paintComponent(Graphics g) {
                g.drawImage(backgroundImage, 0, 0, null);
            }
        };

        ImageIcon titleImage = new ImageIcon(this.getClass().getResource("resources/title.png"));
        JLabel title = new JLabel(titleImage);
        Box titleBox = Box.createVerticalBox();
        titleBox.add(title);
        Box border = Box.createHorizontalBox();
        border.add(Box.createHorizontalGlue());
        border.setBorder(BorderFactory.createRaisedBevelBorder());
        titleBox.add(border);

        midBox.add(Box.createHorizontalGlue());
        midBox.add(left);
        midBox.add(Box.createHorizontalGlue());
        midBox.add(right);
        midBox.add(Box.createHorizontalGlue());

        bigBox.setOpaque(true);
        bigBox.setBackground(Color.WHITE);

        bigBox.add(titleBox);
        bigBox.add(Box.createRigidArea(new Dimension(0, 5)));
        bigBox.add(midBox);

        frame.add(bigBox);

        frame.setPreferredSize(new Dimension(326, 409));
        frame.pack();
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation((int) maximumWindowBounds.getWidth() / 2 - frame.getWidth() / 2, (int) maximumWindowBounds.getHeight() / 2 - frame.getHeight() / 2);
        frame.setVisible(true);
    }

    private void loadSettings() {
        // window color dialog
        Color windowColor = frame.getContentPane().getBackground();
        final ColorDialog windowColorDialog = new ColorDialog(this.frame, "Select Window Color", windowColor);
        windowColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                frame.getContentPane().setBackground(color);
            }
        }
        );

        // "Select Window Color" label + button
        JLabel backgroundLabel = new JLabel("Select Window Color");
        JButton backgroundButton = new JButton("Select Color...");
        backgroundButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.show();
            }
        }
        );
        Box backgroundBox = Box.createHorizontalBox();
        backgroundBox.add(backgroundLabel);
        backgroundBox.add(Box.createHorizontalGlue());
        backgroundBox.add(backgroundButton);
        backgroundBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Maximum Display Size" stuff
        JLabel maximumDisplayLabel = new JLabel("Maximum Display Size: ");
        button360 = new JRadioButton("1:1 (360/360)", width == 360);
        button480 = new JRadioButton("4:3 (480/360)", width == 480);
        button640 = new JRadioButton("16:9 (640/360)", width == 640);
        button360.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                width = 360;
            }
        });
        button480.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                width = 480;
            }
        });
        button640.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                width = 640;
            }
        });
        ButtonGroup grp = new ButtonGroup();
        grp.add(button360);
        grp.add(button480);
        grp.add(button640);
        Box maximumDisplayBox = Box.createVerticalBox();
        maximumDisplayBox.add(maximumDisplayLabel);
        maximumDisplayBox.add(button360);
        maximumDisplayBox.add(button480);
        maximumDisplayBox.add(button640);

        // "Show Selections Borders" checkbox
        bordersCheckbox = new JCheckBox("Show Selections Borders", bordersEnabled);
        bordersCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                boolean enabled = bordersCheckbox.isSelected();
                bordersEnabled = enabled;
            }
        }
        );

        // "Highlight Invalid Pixels" checkbox
        highlightCheckbox = new JCheckBox("Highlight Invalid Pixels", this.highlightInvalidPixels);
        highlightCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                highlightInvalidPixels = highlightCheckbox.isSelected();
            }
        }
        );

        // invalid pixels color dialog
        final ColorDialog invalidColorDialog = new ColorDialog(this.frame, "Select Invalid Pixels Color", this.invalidColor);
        invalidColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                invalidColor = color;
            }
        }
        );

        // "Select color..." button
        JButton invalidColorButton = new JButton("Select Color...");
        invalidColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                invalidColorDialog.show();
            }
        }
        );
        Box highlightBox = Box.createHorizontalBox();
        highlightBox.add(highlightCheckbox);
        highlightBox.add(Box.createHorizontalGlue());
        highlightBox.add(invalidColorButton);
        highlightBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Highlight Invalid Pixels" extension label
        JLabel highlightLabel = new JLabel("(Uniform Inverse Transparency Only)");
        Box highlightLabelBox = Box.createHorizontalBox();
        highlightLabelBox.add(Box.createRigidArea(new Dimension(22, 0)));
        highlightLabelBox.add(highlightLabel);

        //Default Save Directory
        JLabel defaultSaveLabel = new JLabel("Default save directory ");
        JButton defaultSaveButton = new JButton("Select Directory...");
        defaultSaveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File(saveDirectory));
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnVal = chooser.showSaveDialog(SwingUtilities.getWindowAncestor((JButton) e.getSource()));
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    saveDirectory = chooser.getSelectedFile().getAbsolutePath();
                }
            }
        }
        );
        Box defaultSaveBox = Box.createHorizontalBox();
        defaultSaveBox.add(defaultSaveLabel);
        defaultSaveBox.add(Box.createHorizontalGlue());
        defaultSaveBox.add(defaultSaveButton);
        defaultSaveBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Save Information File (.txt)" checkbox
        infoFileCheckbox = new JCheckBox("Save Information File (.txt)", this.enableInfoFile);
        infoFileCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                enableInfoFile = infoFileCheckbox.isSelected();
            }
        }
        );

        // boxes
        Box windowBox = Box.createVerticalBox();
        windowBox.setBorder(BorderFactory.createTitledBorder("Window Settings"));
        windowBox.add(backgroundBox);
        windowBox.add(Box.createRigidArea(new Dimension(0, 10)));
        windowBox.add(Utility.padComponentLeft(maximumDisplayBox));

        Box imageBox = Box.createVerticalBox();
        imageBox.setBorder(BorderFactory.createTitledBorder("Image Settings"));
        imageBox.add(Utility.padComponentLeft(bordersCheckbox));
        imageBox.add(highlightBox);
        imageBox.add(Utility.padComponentLeft(highlightLabelBox));

        Box saveBox = Box.createVerticalBox();
        saveBox.setBorder(BorderFactory.createTitledBorder("Save Settings"));
        saveBox.add(Utility.padComponentLeft(defaultSaveBox));
        saveBox.add(Utility.padComponentLeft(infoFileCheckbox));

        Box mainBox = Box.createVerticalBox();
        mainBox.add(windowBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(imageBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(saveBox);

        // ok button
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
                settingsDialog.setVisible(false);
                //save settings here
                BufferedWriter bw;
                try {
                    bw = new BufferedWriter(new FileWriter("transparency_settings.properties"));
                    bw.write("borders enabled :\n");
                    bw.write(Boolean.toString(bordersEnabled));
                    bw.write("\n");
                    bw.write("Save info file enabled :\n");
                    bw.write(Boolean.toString(enableInfoFile));
                    bw.write("\n");
                    bw.write("Highlighting invalid pixels enabled :\n");
                    bw.write(Boolean.toString(highlightInvalidPixels));
                    bw.write("\n");
                    bw.write("Default save directory :\n");
                    bw.write(saveDirectory);
                    bw.write("\n");
                    bw.write("Window size :\n");
                    if (button360.isSelected()) {
                        bw.write(Integer.toString(360));
                    } else if (button480.isSelected()) {
                        bw.write(Integer.toString(480));
                    } else if (button640.isSelected()) {
                        bw.write(Integer.toString(640));
                    }
                    bw.close();
                } catch (Exception ex) {
                }
            }
        }
        );

        ComponentListener dialogListener = new ComponentAdapter() {
            public void componentHidden(ComponentEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
            }
        };

        Box okBox = Box.createVerticalBox();
        okBox.add(Box.createRigidArea(new Dimension(0, 5)));
        okBox.add(okButton);
        okBox.add(Box.createRigidArea(new Dimension(0, 10)));

        // create dialog
        this.settingsDialog = new JDialog(this.frame, "Settings", false);
        this.settingsDialog.addComponentListener(dialogListener);
        this.settingsDialog.add(mainBox, BorderLayout.CENTER);
        this.settingsDialog.add(Utility.padComponentH(okBox), BorderLayout.SOUTH);
        this.settingsDialog.setPreferredSize(new Dimension(300, 415));
        this.settingsDialog.pack();
        this.settingsDialog.setResizable(false);
        this.settingsDialog.setLocationRelativeTo(null);
    }

    private void loadManual() {
        JEditorPane editorPane = null;
        try {
            editorPane = new JEditorPane(this.getClass().getResource(MANUAL_FILENAME));
        } catch (IOException e) {
            System.out.println("Couldn't open manual file");
            return;
        }

        editorPane.addHyperlinkListener(new HyperlinkListener() {
            public void hyperlinkUpdate(HyperlinkEvent e) {
                if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                    Utility.launchUrl(e.getURL());
                }
            }
        }
        );

        editorPane.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(editorPane);

        this.manualDialog = new JDialog(this.frame, "User Manual", false);
        this.manualDialog.add(scrollPane);
        this.manualDialog.setPreferredSize(new Dimension(800, 600));
        this.manualDialog.pack();
        this.manualDialog.setLocationRelativeTo(null);
    }

    private JMenuBar makeMenu() {
        Menu a = this;

        // menu "Program selection"
        JMenu menuApp = new JMenu("Program Selection");
        JMenuItem first = menuApp.add("From subtractive to additive transparency");
        first.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                firstApp = new FirstApplication(a);
                firstApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                frame.dispose();
            }
        }
        );
        JMenuItem second = menuApp.add("Transparency as generalized f-mean");
        second.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                try {
                    secondApp = new SecondApplication(a);
                    secondApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                    frame.dispose();
                } catch (IOException ex) {
                    Logger.getLogger(Menu.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        );

        JMenuItem third = menuApp.add("Translucency by a scattering layer");
        third.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                thirdApp = new ThirdApplication(a);
                thirdApp.update(width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, settingsDialog);
                frame.dispose();
            }
        }
        );

        // item "Quit"
        JMenuItem itemQuit = menuApp.add("Quit");
        itemQuit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
        itemQuit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }
        );

        // menu "Help"
        JMenu menuHelp = new JMenu("Help");

        // item "Settings"
        JMenuItem itemSettings = menuHelp.add("Settings");
        itemSettings.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                settingsDialog.setVisible(true);
            }
        }
        );

        // item "User Manual"
        JMenuItem itemUserManual = menuHelp.add("User Manual");
        itemUserManual.setAccelerator(KeyStroke.getKeyStroke("F1"));
        itemUserManual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (manualDialog != null) {
                    manualDialog.setVisible(true);
                }
            }
        }
        );

        // item "About"
        JMenuItem itemAbout = menuHelp.add("About");
        itemAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String line1 = "Interactive RGB Transparency is a Java software developed by Lionel Simonot, Mathieu Hébert, Andy Poudret and Florian Nadaud (2016)";
                String line2 = "<a href='" + WEBSITE_URL + "'>" + WEBSITE_URL + "</a>";
                String line3 = "Photograph of Notre-Dame-La-Grande in Poitiers by Florent Carmelet-Rescan";
                String text = line1 + "<br/>" + line2 + "<br/>" + line3;
                JEditorPane pane = new JEditorPane("text/html", text);
                pane.setEditable(false);
                pane.setBackground(new JLabel().getBackground());
                pane.addHyperlinkListener(new HyperlinkListener() {
                    public void hyperlinkUpdate(HyperlinkEvent e) {
                        if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                            Utility.launchUrl(e.getURL());
                        }
                    }
                }
                );
                JOptionPane.showMessageDialog(frame, pane, "About", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        );

        // create menu
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(menuApp);
        menuBar.add(menuHelp);
        return menuBar;
    }
}
