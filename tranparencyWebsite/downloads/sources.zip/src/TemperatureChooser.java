import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.colorchooser.*;
import javax.swing.event.*;


public class TemperatureChooser extends AbstractColorChooserPanel
{
	class TemperaturePicker extends JComponent
	{
		public TemperaturePicker(Dimension size)
		{
			this.setPreferredSize(size);

			this.addMouseListener(new MouseAdapter()
				{
					public void mousePressed(MouseEvent event) { onMouseEvent(event.getX()); }
				}
			);
			this.addMouseMotionListener(new MouseMotionAdapter()
				{
					public void mouseDragged(MouseEvent event) { onMouseEvent(event.getX()); }
				}
			);
		}

		@Override
		protected void paintComponent(Graphics g)
		{
			super.paintComponent(g);

			int w = this.getWidth();
			int h = this.getHeight();
			for(int x = 0; x < w; x++)
			{
				g.setColor(getColor(x));
				g.drawLine(x, 0, x, h-1);
			}

			if(cursor != -1)
			{
				/*g.setColor(Color.BLACK);
				int y = 50;
				g.drawLine(cursor-5, y, cursor+5, y);
				g.drawLine(cursor, y-5, cursor, y+5);*/
				g.setColor(new Color(127, 127, 127));
				g.drawLine(cursor-1, 0, cursor-1, this.getHeight()-1);
				g.drawLine(cursor+1, 0, cursor+1, this.getHeight()-1);
			}
		}
	}

	private static final int PICKER_WIDTH = 463;

	private Color[] colors;
	private int cursor;
	private boolean simpleUpdate;

	private TemperaturePicker picker;
	private JLabel label;

	@Override
	protected void buildChooser()
	{
		this.colors = new Color[PICKER_WIDTH];
		this.cursor = -1;
		this.simpleUpdate = false;

		this.picker = new TemperaturePicker(new Dimension(PICKER_WIDTH, 100));
		this.label = new JLabel(" ");

		for(int x = 0; x < PICKER_WIDTH; x++)
		{
			int k = TemperatureChooser.computeTemperature(x);
			this.colors[x] = this.computeColor((double) k);
		}

		JPanel pickerContainer = new JPanel(new GridBagLayout());
		pickerContainer.setBorder(BorderFactory.createLineBorder(new Color(127, 127, 127)));
		pickerContainer.add(this.picker);

		Box mainBox = Box.createVerticalBox();
		mainBox.add(pickerContainer);
		mainBox.add(Box.createRigidArea(new Dimension(0, 25)));
		mainBox.add(Box.createVerticalGlue());
		mainBox.add(Utility.padComponentH(this.label));

		this.add(mainBox);
	}

	private void onMouseEvent(int x)
	{
		x = Utility.clamp(x, 0, this.picker.getWidth()-1);

		int k = TemperatureChooser.computeTemperature(x);
		this.cursor = x;
		this.label.setText(String.format("Color Temperature: %d K", k));
		this.picker.repaint();

		this.simpleUpdate = true;
		this.getColorSelectionModel().setSelectedColor(this.getColor(x));
	}

	@Override public String getDisplayName() { return "Color Temperature"; }
	@Override public Icon getLargeDisplayIcon() { return null; }
	@Override public Icon getSmallDisplayIcon() { return null; }

	@Override
	public void updateChooser()
	{
		if(this.simpleUpdate)
		{
			this.simpleUpdate = false;
			return;
		}

		Color color = this.getColorSelectionModel().getSelectedColor();

		int closestX = -1;
		double closestK = 0.0;
		double closestDistance = 0.0f;
		for(int x = 0; x < PICKER_WIDTH; x++)
		{
			Color kColor = this.colors[x];
			double distance = Math.sqrt(Utility.square(kColor.getRed()-color.getRed()) +
										Utility.square(kColor.getGreen()-color.getGreen()) +
										Utility.square(kColor.getBlue()-color.getBlue()));
			if(closestX == -1 || distance < closestDistance)
			{
				closestX = x;
				closestDistance = distance;
			}
		}

		this.cursor = closestX;
		this.picker.repaint();
		if(closestX != -1)
		{
			int k = TemperatureChooser.computeTemperature(closestX);
			this.label.setText(String.format("Color Temperature: %d K", k));
		}
	}

	private static int computeTemperature(int x)
	{
		x = Utility.clamp(x, 0, PICKER_WIDTH-1);
		int k = 1000 + 25*x;
		if(x > 224)
			k += 25*(x-224);
		if(x > 332)
			k += 50*(x-332);
		return k;
	}

	private Color computeColor(double k)
	{
		k /= 100.0;
		double r, g, b;
		if(k <= 66.0)
		{
			r = 255.0;
			g = 99.4708025861 * Math.log(k) - 161.1195681661;
		}
		else
		{
			r = 329.698727446 * Math.pow(k-60.0, -0.1332047592);
			g = 288.1221695283 * Math.pow(k-60.0, -0.0755148492);
		}
		if(k >= 66.0)
			b = 255.0;
		else if(k <= 19.0)
			b = 0.0;
		else
			b = 138.5177312231 * Math.log(k-10.0) - 305.0447927307;

		int red = Utility.clamp(Math.round(Math.round(r)), 0, 255);
		int green = Utility.clamp(Math.round(Math.round(g)), 0, 255);
		int blue = Utility.clamp(Math.round(Math.round(b)), 0, 255);
		return new Color(red, green, blue);
	}

	private Color getColor(int x)
	{
		x = Utility.clamp(x, 0, this.picker.getWidth()-1);
		x = x * (PICKER_WIDTH-1) / (this.picker.getWidth()-1);
		return this.colors[x];
	}
}
