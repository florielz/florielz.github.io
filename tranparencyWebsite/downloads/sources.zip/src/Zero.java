
public class Zero extends TransparencyLaw {

    private Zero associatedLaw;
    protected int law = 2;

    @Override
    public String getName() {
        switch (this.law) {
            case 0:
                return "f(x) = ln(x)";
            case 1:
                return "f(x) = ln(x² / (1-x))";
            case 2:
                return "f(x) = ln(x / (1-x))";
            case 3:
                return "f(x) = ln(x / (1-x)²)";
            case 4:
                return "f(x) = ln(1 / (1-x))";
            default:
                return "f(x) = ln(x)";
        }
    }
    
    @Override
    public String getName(double val) {
        return this.getName();
    }

    public String getFunction(int val) {
        switch (val) {
            case 0:
                return "f(x) = ln(x)";
            case 1:
                return "f(x) = ln(x&sup2; / (1-x))";
            case 2:
                return "f(x) = ln(x / (1-x))";
            case 3:
                return "f(x) = ln(x / (1-x)&sup2;)";
            case 4:
                return "f(x) = ln(1 / (1-x))";
            default:
                return "f(x) = ln(x)";
        }/*
        switch (val) {
            case 0:
                return "f(x) = e<sup>x</sup>";
            case 1:
                return "f(x) = e<sup>x&sup2; / (1-x)</sup>";
            case 2:
                return "f(x) = e<sup>x / (1-x)</sup>";
            case 3:
                return "f(x) = e<sup>x / (1-x)&sup2;</sup>";
            case 4:
                return "f(x) = e<sup>1 / (1-x)</sup>";
            default:
                return "f(x) = e<sup>x</sup>";
        }*/
    }

    @Override
    public String getFunction() {
        return getFunction(this.law);
    }

    @Override
    public String getFunction(double val) {
        return getFunction();
    }

    @Override
    public TransparencyLaw associatedLaw() {
        if (associatedLaw == null) {
            associatedLaw = new Zero();
        }
        return associatedLaw;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        if (this.inverse) {
            return fInverse((f(back, t) - (1.0 - c) * f(front, t)) / c, t);
        } else {
            return (fInverse(c * f(back, t) + (1.0 - c) * f(front, t), t));
        }
    }

    public void setLaw(int x) {
        this.law = x;
        if (associatedLaw == null) {
            associatedLaw = new Zero();
        }
        associatedLaw.law = x;
    }

    public int getLaw() {
        return law;
    }

    @Override
    public double f(double x, double t) {
        switch (this.law) {
            case 0:
                return (Math.log(x));
            case 1:
                return (Math.log(Math.pow(x, 2.0) / (1.0 - x)));
            case 2:
                return (Math.log(x / (1.0 - x)));
            case 3:
                return (Math.log(x / Math.pow(1.0 - x, 2.0)));
            case 4:
                return (Math.log(1.0 / (1.0 - x)));
            default:
                return (Math.log(x));
        }
    }

    @Override
    public double fInverse(double x, double t) {
        switch (this.law) {
            case 0:
                return (Math.exp(x));
            case 1:
                return (-Math.exp(x) + Math.sqrt(Math.exp(x)) * Math.sqrt(4.0 + Math.exp(x))) / 2.0;
            case 2:
                return (Math.exp(x) / (Math.exp(x) + 1.0));
            case 3:
                return (1.0 / 2.0) * Math.exp(-x) * (1.0 + 2.0 * Math.exp(x) - Math.sqrt(1.0 + 4.0 * Math.exp(x)));
            case 4:
                return (Math.exp(-x) * (Math.exp(x) - 1.0));
            default:
                return (Math.exp(x));
        }
    }
}
