import java.awt.datatransfer.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.*;

import javax.swing.*;


public class MultipleTransferHandler extends TransferHandler
{
	private List<TransferHandler> transferHandlers;

	public MultipleTransferHandler()
	{
		this.transferHandlers = new LinkedList<TransferHandler>();
	}

	public void addTransferHandler(TransferHandler handler)
	{
		if(!this.transferHandlers.contains(handler))
			this.transferHandlers.add(handler);
	}

	@Override
	public boolean canImport(TransferSupport support)
	{
		for(TransferHandler handler : this.transferHandlers)
		{
			if(handler.canImport(support))
				return true;
		}
		return false;
	}

	@Override
	public boolean importData(TransferSupport support)
	{
		for(TransferHandler handler : this.transferHandlers)
		{
			if(handler.canImport(support) && handler.importData(support))
				return true;
		}
		return false;
	}
}
