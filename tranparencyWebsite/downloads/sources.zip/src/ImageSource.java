import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.event.*;


public class ImageSource extends Source
{
	private String filename;
	private BufferedImage image;

	public static ImageSource load(URL url, String name)
	{
		BufferedImage image = null;
		try { image = ImageIO.read(url); }
		catch(IOException e) { }

		if(image == null)
		{
			System.out.println("Couldn't load image");
			JOptionPane.showMessageDialog(null, "Could not load image.", "Invalid image", JOptionPane.ERROR_MESSAGE);
			return null;
		}
		else
			return new ImageSource(name, name, image);
	}

	public static ImageSource load(String filename)
	{
		BufferedImage image = null;
		try { image = ImageIO.read(new File(filename)); }
		catch(IOException e) { }

		if(image == null)
		{
			System.out.println("Couldn't load image");
			JOptionPane.showMessageDialog(null, "Could not load image.", "Invalid image", JOptionPane.ERROR_MESSAGE);
			return null;
		}
		else
		{
			String shortName = new File(filename).getName();
			return new ImageSource(shortName, filename, image);
		}
	}

	public ImageSource(String shortName, String longName, BufferedImage image)
	{
		super(BoxLayout.PAGE_AXIS);

		this.filename = longName;
		this.image = image;

		final int length = 25;
		String cutName = shortName;
		if(shortName.length() > length)
			cutName = shortName.substring(0, length/2-3) + "..." + shortName.substring(shortName.length()-length/2, shortName.length());
		if(cutName.length() == 0)
			cutName = " ";
		JLabel filenameLabel = new JLabel(cutName);
		filenameLabel.setToolTipText(longName);

		this.add(Utility.padComponentH(filenameLabel));
		this.add(Box.createRigidArea(new Dimension(0, 10)));

		if(this.image != null)
		{
			IconPanel panel = new IconPanel(new Dimension(100, 100), this.image);
			this.add(Utility.padComponentH(panel));
		}
	}

	@Override
	public String toString()
	{
		return String.format("image '%s'", this.filename);
	}

	@Override
	public Dimension getSourceSize()
	{
		return new Dimension(this.image.getWidth(null), this.image.getHeight(null));
	}

	@Override
	public Color getPixel(float x, float y)
	{
		int px = Math.round(x * (this.image.getWidth(null)-1));
		int py = Math.round(y * (this.image.getHeight(null)-1));
		return new Color(this.image.getRGB(px, py));
	}
}
