
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;

class Polygons {

    public static Polygon makeRect(int x, int y, int w, int h) {
        Polygon poly = new Polygon();
        Polygons.doRect(poly, x, y, w, h);
        return poly;
    }

    public static void doRect(Polygon poly, int x, int y, int w, int h) {
        // make sure width and height are >= 0
        if (w < 0) {
            x += w;
            w = -w;
        }
        if (h < 0) {
            y += h;
            h = -h;
        }

        poly.reset();
        poly.addPoint(x, y);
        poly.addPoint(x + w, y);
        poly.addPoint(x + w, y + h);
        poly.addPoint(x, y + h);
    }

    public static Polygon copy(Polygon src) {
        Polygon dest = new Polygon();
        dest.reset();
        for (int i = 0; i < src.npoints; i++) {
            dest.addPoint(src.xpoints[i], src.ypoints[i]);
        }
        return dest;
    }
}

public class ImagePanel extends JComponent implements MouseListener, MouseMotionListener {

    private static final double PROXIMITY_RADIUS = 12.0;

    private Dimension dimension;
    private JLabel pixelInfoLabel;
    private LinkedList<Polygon> selections;
    private LinkedList<Polygon> expSelections;
    private boolean expectedMode;
    private Point selectionStart;
    private Polygon currentSelection;
    private boolean moving;
    private boolean resizing;
    private int resizeBoundPoint;
    private Polygon resizeInitialSelection;
    private int selectedPoint;
    private boolean showPoints;
    private BufferedImage image;
    private ActionSender actionSender;
    private boolean selectionsLocked;
    private boolean selectionsHidden;
    private boolean expectedEnabled;
    private boolean changingMaxSize;
    private ActionListener expectedBackListener;
    private long popupMenuClosedTime;
    private HashMap<Integer, ArrayList> invalidMap;

    public ImagePanel(Dimension dimension, JLabel pixelInfoLabel, ActionListener expectedBackListener) {
        this.dimension = dimension;
        this.pixelInfoLabel = pixelInfoLabel;
        this.selections = new LinkedList<Polygon>();
        this.expSelections = new LinkedList<Polygon>();
        this.currentSelection = null;
        this.selectedPoint = -1;
        this.showPoints = false;
        this.actionSender = new ActionSender();
        this.selectionsLocked = false;
        this.selectionsHidden = false;
        this.expectedEnabled = false;
        this.changingMaxSize = false;
        this.expectedBackListener = expectedBackListener;
        this.popupMenuClosedTime = 0;
        this.expectedMode = false;

        this.invalidMap = new HashMap<>();

        this.setPreferredSize(dimension);
        this.setMaximumSize(dimension);
        this.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }

    public void setSelectionsLocked(boolean locked) {
        this.selectionsLocked = locked;
    }

    public void setExpectedEnabled(boolean enabled) {
        this.expectedEnabled = enabled;
    }

    public void setExpectedMode(boolean enabled) {
        this.expectedMode = enabled;
    }

    public void setMaxSize(Dimension dimension) {
        this.changingMaxSize = true;
        this.dimension = dimension;
        this.setMaximumSize(dimension);
    }

    public void resetInvalidMap() {
        this.invalidMap.clear();
    }

    public void addInvalidPixel(int x, int y) {
        if (this.invalidMap.get(x) == null) {
            this.invalidMap.put(x, new ArrayList<Integer>());
        }
        this.invalidMap.get(x).add(y);
    }

    private void updatePixelInfo(int x, int y) {
        boolean invalid = false;
        if (x < 0 || y < 0 || x >= this.image.getWidth(null) || y >= this.image.getHeight(null)) {
            this.pixelInfoLabel.setText(" ");
        } else {
            if (invalidMap.get(x) != null) {
                for (int i = 0; i < invalidMap.get(x).size(); i++) {
                    if ((int) invalidMap.get(x).get(i) == y) {
                        String text = String.format("X=%03d Y=%03d Invalid Pixel                ", x, y);
                        this.pixelInfoLabel.setText(text);
                        invalid = true;
                        break;
                    }
                }
            }
            if (!invalid) {
                Color c = new Color(this.image.getRGB(x, y));
                String text = String.format("X=%03d Y=%03d R=%03d G=%03d B=%03d", x, y, c.getRed(), c.getGreen(), c.getBlue());
                this.pixelInfoLabel.setText(text);
            }
        }
    }

    public void selectSelection(Point point, boolean marginCurrent) {
        if (marginCurrent && this.currentSelection != null) {
            Polygon s = this.currentSelection;
            for (int i = 0, j = s.npoints - 1; i < s.npoints; j = i++) {
                Point nearestPoint = Utility.nearestPointOnLine(s.xpoints[i], s.ypoints[i], s.xpoints[j], s.ypoints[j], point.x, point.y);
                double distance = point.distance(nearestPoint);
                if (distance < PROXIMITY_RADIUS) {
                    return;
                }
            }
        }

        this.currentSelection = null;
        this.showPoints = false;
        if (!expectedMode) {
            for (Polygon s : this.selections) {
                if (s.contains(point.x, point.y)) {
                    this.currentSelection = s;
                    break;
                }
            }
        } else {
            for (Polygon s : this.expSelections) {
                if (s.contains(point.x, point.y)) {
                    this.currentSelection = s;
                    break;
                }
            }
        }
        this.repaint();
    }

    public void selectPoint(Point point) {
        this.selectionStart = null;
        this.selectedPoint = -1;
        Polygon s = this.currentSelection;
        if (s != null) {
            for (int i = 0; i < s.npoints; i++) {
                if (point.distance(s.xpoints[i], s.ypoints[i]) < PROXIMITY_RADIUS) {
                    this.selectionStart = point;
                    this.selectedPoint = i;
                    break;
                }
            }
        }
    }

    private void addPoint(Point point, boolean fastAdd) {
        Polygon s = this.currentSelection;
        if (s == null) {
            return;
        }

        int closestPoint = -1;
        double closestDistance = 0.0;

        for (int i = 0, j = s.npoints - 1; i < s.npoints; j = i++) {
            Point nearestPoint = Utility.nearestPointOnLine(s.xpoints[i], s.ypoints[i], s.xpoints[j], s.ypoints[j], point.x, point.y);
            double distance = point.distance(nearestPoint);
            if (closestPoint == -1 || distance < closestDistance) {
                if (fastAdd && distance > PROXIMITY_RADIUS) {
                    continue;
                }
                closestPoint = i;
                closestDistance = distance;
            }
        }

        if (closestPoint != -1) {
            int npoints = s.npoints;
            int[] xpoints = Arrays.copyOf(s.xpoints, npoints);
            int[] ypoints = Arrays.copyOf(s.ypoints, npoints);
            s.reset();
            for (int k = 0; k < closestPoint; k++) {
                s.addPoint(xpoints[k], ypoints[k]);
            }
            s.addPoint(point.x, point.y);
            for (int k = closestPoint; k < npoints; k++) {
                s.addPoint(xpoints[k], ypoints[k]);
            }
            this.actionSender.sendEvent();

            if (fastAdd) {
                this.selectionStart = point;
                this.selectedPoint = closestPoint;
            }
        }
    }

    private void removePoint() {
        Polygon s = this.currentSelection;
        if (s != null && this.selectedPoint != -1 && s.npoints > 3) {
            int npoints = s.npoints;
            int[] xpoints = Arrays.copyOf(s.xpoints, npoints);
            int[] ypoints = Arrays.copyOf(s.ypoints, npoints);
            s.reset();
            for (int k = 0; k < this.selectedPoint; k++) {
                s.addPoint(xpoints[k], ypoints[k]);
            }
            for (int k = this.selectedPoint + 1; k < npoints; k++) {
                s.addPoint(xpoints[k], ypoints[k]);
            }
            this.selectedPoint = -1;
            this.actionSender.sendEvent();
        }
    }

    private Point[] getBoundsPoints(Polygon s) {
        Rectangle bounds = s.getBounds();
        Point[] points = {
            new Point(bounds.x, bounds.y),
            new Point(bounds.x + bounds.width / 2, bounds.y),
            new Point(bounds.x + bounds.width, bounds.y),
            new Point(bounds.x, bounds.y + bounds.height / 2),
            null,
            new Point(bounds.x + bounds.width, bounds.y + bounds.height / 2),
            new Point(bounds.x, bounds.y + bounds.height),
            new Point(bounds.x + bounds.width / 2, bounds.y + bounds.height),
            new Point(bounds.x + bounds.width, bounds.y + bounds.height)
        };
        return points;
    }

    public void mouseEntered(MouseEvent event) {
    }

    public void mouseExited(MouseEvent event) {
        this.updatePixelInfo(-1, -1);
    }

    public void mouseMoved(MouseEvent event) {
        this.updatePixelInfo(event.getX(), event.getY());
    }

    public void mousePressed(MouseEvent event) {
        /*if (this.selectionsLocked || this.selectionsHidden) {
            return;
        }*/

        if (System.currentTimeMillis() - popupMenuClosedTime < 300) {
            return;
        }

        if (event.getButton() != MouseEvent.BUTTON1) {
            return;
        }

        Point point = new Point(event.getX(), event.getY());

        if (this.showPoints && this.currentSelection != null) {
            // select a point
            this.selectPoint(point);

            // add a point
            if (this.selectedPoint == -1) {
                this.addPoint(point, true);
            }

            if (this.selectedPoint != -1) {
                return;
            }
        }

        // start resizing a selection
        if (this.currentSelection != null) {
            Point[] points = this.getBoundsPoints(this.currentSelection);
            for (int i = 0; i < 9; i++) {
                if (points[i] != null && point.distance(points[i]) < PROXIMITY_RADIUS) {
                    this.selectionStart = point;
                    this.resizing = true;
                    this.resizeBoundPoint = i;
                    this.resizeInitialSelection = new Polygon();
                    this.resizeInitialSelection = Polygons.copy(this.currentSelection);
                    return;
                }
            }
        }

        // start creating/moving a selection
        this.selectSelection(point, false);
        this.selectionStart = point;
        this.resizing = false;
        if (this.currentSelection == null) {
            this.moving = false;
            this.currentSelection = Polygons.makeRect(point.x, point.y, 0, 0);
        } else {
            this.moving = true;
        }
    }

    public void mouseDragged(MouseEvent event) {
        if (this.selections.contains(this.currentSelection) && (this.selectionsLocked || this.selectionsHidden)) {
            return;
        }

        if (this.currentSelection == null || this.selectionStart == null) {
            return;
        }

        if ((event.getModifiersEx() & InputEvent.BUTTON1_DOWN_MASK) == 0) {
            return;
        }

        Point point = new Point(event.getX(), event.getY());

        // drag selected point
        if (this.selectedPoint != -1) {
            this.currentSelection.xpoints[this.selectedPoint] += point.x - this.selectionStart.x;
            this.currentSelection.ypoints[this.selectedPoint] += point.y - this.selectionStart.y;
            this.currentSelection.invalidate();
            this.selectionStart = point;
            this.actionSender.sendEvent();
        } else if (this.resizing) {
            // resize current selection
            Polygon sel = this.currentSelection;
            Rectangle bounds = sel.getBounds();
            int selX = bounds.x;
            int selY = bounds.y;
            int selW = bounds.width;
            int selH = bounds.height;

            int i = this.resizeBoundPoint;
            int dx = point.x - this.selectionStart.x;
            int dy = point.y - this.selectionStart.y;
            if (i == 0 || i == 3 || i == 6) // expand left
            {
                selX += dx;
                selW -= dx;
            }
            if (i == 0 || i == 1 || i == 2) // expand top
            {
                selY += dy;
                selH -= dy;
            }
            if (i == 2 || i == 5 || i == 8) // expand right
            {
                selW += dx;
            }
            if (i == 6 || i == 7 || i == 8) // expand down
            {
                selH += dy;
            }

            if (selW < 0) {
                i += (i % 3 == 0 ? 2 : -2);
            }
            if (selH < 0) {
                i += (i < 3 ? 6 : -6);
            }
            this.resizeBoundPoint = i;

            Polygon t = this.resizeInitialSelection;
            Rectangle tBounds = t.getBounds();
            for (int p = 0; p < t.npoints; p++) {
                sel.xpoints[p] = Math.round(1.0f * (t.xpoints[p] - tBounds.x) / tBounds.width * selW + selX);
                sel.ypoints[p] = Math.round(1.0f * (t.ypoints[p] - tBounds.y) / tBounds.height * selH + selY);
            }
            sel.invalidate();
            this.selectionStart = point;
            this.actionSender.sendEvent();
        } else {
            // create/move current selection
            Polygon sel = this.currentSelection;
            if (this.moving) {
                sel.translate(point.x - this.selectionStart.x, point.y - this.selectionStart.y);
                this.selectionStart = point;
            } else {
                int selX = this.selectionStart.x;
                int selY = this.selectionStart.y;
                int selW = point.x - this.selectionStart.x;
                int selH = point.y - this.selectionStart.y;
                Polygons.doRect(sel, selX, selY, selW, selH);
            }

            if (expectedMode) {
                if (!this.expSelections.contains(this.currentSelection)) {
                    this.expSelections.add(this.currentSelection);
                }
            } else if (!this.selections.contains(this.currentSelection)) {
                this.selections.add(this.currentSelection);
            }

            this.actionSender.sendEvent();
        }

        this.updatePixelInfo(event.getX(), event.getY());
    }

    public void mouseReleased(MouseEvent event) {
        // release left click -> stop resizing/moving/etc
        if (event.getButton() != MouseEvent.BUTTON1) {
            return;
        }

        if (this.selectionStart != null) {
            Rectangle bounds = this.currentSelection.getBounds();
            if (bounds.width == 0 || bounds.height == 0) {
                this.selections.remove(this.currentSelection);
                this.currentSelection = null;
                this.actionSender.sendEvent();
            }
        }

        this.selectionStart = null;
        this.selectedPoint = -1;
    }

    public void mouseClicked(MouseEvent event) {
        // double-click
        if (!this.selectionsLocked && !this.selectionsHidden) {
            // select all the panel
            if (event.getButton() == MouseEvent.BUTTON1 && event.getClickCount() == 2) {
                Polygon s = Polygons.makeRect(0, 0, this.getWidth() - 1, this.getHeight() - 1);
                this.selections.clear();
                this.selections.add(s);
                this.currentSelection = s;
                this.actionSender.sendEvent();
            }
        }

        // right-click -> context menu
        if (event.getButton() != MouseEvent.BUTTON3) {
            return;
        }

        final Point point = new Point(event.getX(), event.getY());

        JPopupMenu menu = new JPopupMenu();
        menu.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuCanceled(PopupMenuEvent e) {
            }

            public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
            }

            public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
                popupMenuClosedTime = System.currentTimeMillis();
            }
        }
        );

        if (expectedMode || (!this.selectionsLocked && !this.selectionsHidden)) {
            Polygon tempSel = this.currentSelection;
            this.selectSelection(point, true);
            if (expectedMode && this.selections.contains(this.currentSelection)) {
                this.currentSelection = null;
            }
            this.selectionStart = null;

            /*if(this.currentSelection == null && tempSel != null)
			{
				this.currentSelection = tempSel;
				this.selectPoint(point);
				if(this.selectedPoint == -1)
					this.currentSelection = null;
			}*/
            if (this.currentSelection != null) {
                this.showPoints = true;
                this.repaint();
            }

            if (this.currentSelection != null) {
                this.selectPoint(point);

                JMenuItem addPointItem = menu.add("Add Point");
                addPointItem.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent event) {
                        addPoint(point, false);
                    }
                }
                );

                if (this.selectedPoint != -1) {
                    JMenuItem removePointItem = menu.add("Remove Point");
                    removePointItem.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent event) {
                            removePoint();
                        }
                    }
                    );
                }

                menu.addSeparator();

                JMenuItem deleteItem = menu.add("Delete Selection");
                deleteItem.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent event) {
                        if (currentSelection == null) {
                            return;
                        } else if (expSelections.contains(currentSelection)) {
                            expSelections.remove(currentSelection);
                            currentSelection = null;
                            actionSender.sendEvent();
                        } else {
                            selections.remove(currentSelection);
                            currentSelection = null;
                            actionSender.sendEvent();
                        }
                    }
                }
                );
            }

            if (!expectedMode) {
                JMenuItem deleteAllItem = menu.add("Delete All Selections");
                deleteAllItem.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent event) {
                        selections.clear();
                        currentSelection = null;
                        actionSender.sendEvent();
                    }
                }
                );

                menu.addSeparator();

                /*if (this.expectedEnabled) {
                    JMenuItem expectedBackItem = menu.add("Expected Background");
                    expectedBackItem.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent event) {
                            showPoints = false;
                            expectedBackListener.actionPerformed(event);
                        }
                    }
                    );

                    menu.addSeparator();
                }*/
            }
        }

        JMenuItem showHideItem = menu.add(this.selectionsHidden ? "Show All Selections" : "Hide All Selections");
        showHideItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                showPoints = false;
                selectionsHidden = !selectionsHidden;
                actionSender.sendEvent();
            }
        }
        );

        menu.show(event.getComponent(), event.getX(), event.getY());
    }

    public Dimension getContainerSize() {
        return new Dimension(this.dimension.width, this.dimension.height);
    }

    public LinkedList<Polygon> getSelections() {
        if (this.selectionsHidden) {
            return new LinkedList<Polygon>();
        } else {
            return this.selections;
        }
    }

    public LinkedList<Polygon> getExpSelections() {
        if (this.selectionsHidden) {
            return new LinkedList<Polygon>();
        } else {
            return this.expSelections;
        }
    }

    public Polygon getCurrentSelection() {
        return this.currentSelection;
    }

    public void resetCurrentSelection() {
        this.currentSelection = null;
    }

    public void showPoints(boolean b) {
        this.showPoints = b;
    }

    public void mixSelections() {
        for (Polygon s : expSelections) {
            selections.add(s);
        }
        expSelections.clear();
        currentSelection = null;
    }

    public void resetSelections(Dimension frontSize) {
        if (this.selectionsLocked) {
            return;
        }

        float w = 0.5f;
        float h = 0.5f;
        if (frontSize != null) {
            float ratio = 1.0f * frontSize.width / frontSize.height / this.getWidth() * this.getHeight();
            if (ratio > 1.0f) {
                h /= ratio;
            } else if (ratio < 1.0f) {
                w *= ratio;
            }
        }
        float x = (1.0f - w) / 2.0f;
        float y = (1.0f - h) / 2.0f;

        this.selections.clear();
        this.selections.add(Polygons.makeRect(Math.round(x * this.getWidth()), Math.round(y * this.getHeight()),
                Math.round(w * this.getWidth()), Math.round(h * this.getHeight())));
    }

    public void addActionListener(ActionListener listener) {
        this.actionSender.addListener(listener);
    }

    public void setPanelSize(Dimension size, Dimension parentSize) {
        int w = size.width;
        int h = size.height;
        int x = (parentSize.width - w) / 2;
        int y = (parentSize.height - h) / 2;

        if (this.changingMaxSize) {
            float rx = 1.0f * w / this.getWidth();
            float ry = 1.0f * h / this.getHeight();
            for (Polygon s : this.selections) {
                for (int i = 0; i < s.npoints; i++) {
                    s.xpoints[i] = Math.round(s.xpoints[i] * rx);
                    s.ypoints[i] = Math.round(s.ypoints[i] * ry);
                }
                s.invalidate();
            }
            this.changingMaxSize = false;
        } else {
            for (Polygon s : this.selections) {
                s.translate((w - this.getWidth()) / 2, (h - this.getHeight()) / 2);
            }
        }

        this.setPreferredSize(new Dimension(w, h));
        this.setMinimumSize(new Dimension(w, h));
        this.setMaximumSize(new Dimension(w, h));
        this.setBounds(x, y, w, h);
    }

    public void setImage(BufferedImage image) {
        this.image = image;
        this.repaint();
    }

    private void drawPoint(Graphics g, int x, int y, Color outline, Color inline) {
        g.setColor(outline);
        g.drawRect(x - 2, y - 2, 4, 4);
        g.setColor(inline);
        g.fillRect(x - 1, y - 1, 3, 3);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (this.image == null) {
            return;
        }

        g.drawImage(this.image, 0, 0, this.getWidth(), this.getHeight(), null);

        if (expectedMode || (!this.selectionsHidden && !this.selectionsLocked)) {
            Polygon s = this.currentSelection;
            if (s != null && (this.selections.contains(s) || this.expSelections.contains(s))) {
                if (this.showPoints) {
                    for (int i = 0; i < s.npoints; i++) {
                        this.drawPoint(g, s.xpoints[i], s.ypoints[i], Color.BLACK, Color.WHITE);
                    }
                } else {
                    Point[] points = this.getBoundsPoints(s);
                    for (int i = 0; i < 9; i++) {
                        if (points[i] != null) {
                            this.drawPoint(g, points[i].x, points[i].y, Color.WHITE, Color.BLACK);
                        }
                    }
                }
            }
        }
    }
    
    public void clearSelections(){
        this.selections.clear();
    }
    
    public void clearExpSelections(){
        this.expSelections.clear();
    }
    
    public void addSelection(Polygon s){
        this.selections.add(s);
    }
    
    public void copy(ImagePanel newPanel){
        newPanel.resetCurrentSelection();
        newPanel.clearSelections();
        for (Polygon s : this.selections){
            newPanel.addSelection(s);
        }
        newPanel.repaint();
    }
}
