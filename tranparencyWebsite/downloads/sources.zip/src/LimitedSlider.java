
import java.awt.*;
import javax.swing.JSlider;

public class LimitedSlider extends JSlider {

    private int limit = 70;
    private ThirdApplication app;
    public static Color invalidColor;

    public LimitedSlider(int orientation, int min, int max, int value, ThirdApplication app) {
        super(orientation, min, max, value);
        this.app = app;
        float[] hsb = new float[3];
        Color.RGBtoHSB(255, 0, 0, hsb);
        float inc = 0.2F;
        if (hsb[2] <= inc) {
            invalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] + inc);
        } else {
            invalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] - inc);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(invalidColor);
        g.fillRect(20, 8, 4, (this.getHeight() - 16) * (100 - limit) / 100);
    }

    public void update(double alpha, double beta, Source front, double red, double green, double blue) {
        int l1;
        if (front instanceof ColorSource) {
            double r;
            double g;
            double b;
            if (beta < 0) { //Alpha is moving
                l1 = (int) ((1.0 - alpha) * 100.0);
                r = (1.0 - alpha) * red;
                g = (1.0 - alpha) * green;
                b = (1.0 - alpha) * blue;
            } else { //Beta is moving
                l1 = (int) ((1.0 - beta) * 100.0);
                r = 1.0 - (beta / red);
                g = 1.0 - (beta / green);
                b = 1.0 - (beta / blue);
            }
            int l2 = (int) (Math.min(r, Math.min(g, b)) * 100.0);
            this.limit = Math.min(l1, l2);
        } else {
            if (beta < 0) {
                l1 = (int) ((1.0 - alpha) * 100.0);
            } else {
                l1 = (int) ((1.0 - beta) * 100.0);
            }
            this.limit = l1;
        }
        this.repaint();
    }

    public void setColor(Color invalidColor) {
        this.invalidColor = invalidColor;
    }
}
