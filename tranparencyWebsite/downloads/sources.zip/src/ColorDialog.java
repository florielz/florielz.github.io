
import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.util.*;

import javax.swing.*;
import javax.swing.colorchooser.*;
import javax.swing.event.*;

interface ColorListener {

    public abstract void colorChanged(Color color);
}

public class ColorDialog {

    private LinkedList<ColorListener> listeners;
    private Color initialColor;
    private boolean skipEvent;

    private JColorChooser colorChooser;
    private JDialog dialog;
    private ColorSelectionModel model;
    private JLabel infoLabel;
    private double oldAlpha = 0.5, oldBeta = 0;

    public ColorDialog(Window parent, String title, Color initialColor) {
        this(parent, title, initialColor, null);
    }

    public ColorDialog(Window parent, String title, Color initialColor, final ActionListener cancelListener) {
        this.listeners = new LinkedList<ColorListener>();
        this.initialColor = initialColor;
        this.skipEvent = false;

        this.colorChooser = new JColorChooser(initialColor);
        this.colorChooser.addChooserPanel(new TemperatureChooser());
        this.colorChooser.setPreviewPanel(new JPanel());

        try {
            this.removeTransparencySlider();
        } catch (Exception e) {
        }

        this.model = this.colorChooser.getSelectionModel();
        this.model.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                sendColorEvent(model.getSelectedColor());
            }
        }
        );

        this.infoLabel = new JLabel(" ");

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.setVisible(false);
            }
        }
        );

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (cancelListener != null) {
                    cancelListener.actionPerformed(null);
                }
                dialog.setVisible(false);
            }
        }
        );

        Box buttonsBox = Box.createHorizontalBox();
        buttonsBox.add(Box.createHorizontalGlue());
        buttonsBox.add(okButton);
        buttonsBox.add(Box.createRigidArea(new Dimension(10, 0)));
        buttonsBox.add(cancelButton);
        buttonsBox.add(Box.createHorizontalGlue());

        Box mainBox = Box.createVerticalBox();
        mainBox.add(this.colorChooser);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));
        mainBox.add(Utility.padComponentH(this.infoLabel));
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));
        mainBox.add(buttonsBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));

        this.dialog = new JDialog(parent, title, Dialog.ModalityType.MODELESS);
        this.dialog.add(mainBox, BorderLayout.CENTER);
        this.dialog.pack();
        this.dialog.setResizable(false);
        this.dialog.setLocationRelativeTo(parent);
    }

    public ColorDialog(Window parent, String title, Color initialColor, final ActionListener cancelListener, SourcePos pos, ThirdApplication app) {
        this.listeners = new LinkedList<ColorListener>();
        this.initialColor = initialColor;
        this.skipEvent = false;

        this.colorChooser = new JColorChooser(initialColor);
        this.colorChooser.addChooserPanel(new TemperatureChooser());
        this.colorChooser.setPreviewPanel(new JPanel());

        try {
            this.removeTransparencySlider();
        } catch (Exception e) {
        }

        this.model = this.colorChooser.getSelectionModel();
        this.model.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                sendColorEvent(model.getSelectedColor());
            }
        }
        );

        this.infoLabel = new JLabel(" ");

        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dialog.setVisible(false);
                LittleFrame littleFrame = app.getLittleFrame();
                if (littleFrame != null) {
                    littleFrame.updateSliders(oldAlpha, oldBeta);
                }
            }
        }
        );

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (cancelListener != null) {
                    cancelListener.actionPerformed(null);
                }
                dialog.setVisible(false);
                LittleFrame littleFrame = app.getLittleFrame();
                if (littleFrame != null) {
                    littleFrame.updateSliders(oldAlpha, oldBeta);
                }
            }
        }
        );

        Box buttonsBox = Box.createHorizontalBox();
        buttonsBox.add(Box.createHorizontalGlue());
        buttonsBox.add(okButton);
        buttonsBox.add(Box.createRigidArea(new Dimension(10, 0)));
        buttonsBox.add(cancelButton);
        buttonsBox.add(Box.createHorizontalGlue());

        Box mainBox = Box.createVerticalBox();
        mainBox.add(this.colorChooser);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));
        mainBox.add(Utility.padComponentH(this.infoLabel));
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));
        mainBox.add(buttonsBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 10)));

        this.dialog = new JDialog(parent, title, Dialog.ModalityType.MODELESS);
        this.dialog.add(mainBox, BorderLayout.CENTER);
        this.dialog.pack();
        this.dialog.setResizable(false);
        this.dialog.setLocationRelativeTo(parent);
    }

    public void setOldAlpha(double alpha) {
        this.oldAlpha = alpha;
    }

    public void setOldBeta(double beta) {
        this.oldBeta = beta;
    }
    
    public double getOldAlpha() {
        return this.oldAlpha;
    }

    public double getOldBeta() {
        return this.oldBeta;
    }

    public void setInfoText(String infoText) {
        this.infoLabel.setText(infoText);
    }

    public void addColorListener(ColorListener listener) {
        this.listeners.add(listener);
    }

    private void sendColorEvent(Color color) {
        if (!this.skipEvent) {
            color = Utility.removeAlpha(color);
            for (ColorListener l : this.listeners) {
                l.colorChanged(color);
            }
        }
        this.skipEvent = false;
    }

    public int getWidth() {
        return this.dialog.getWidth();
    }

    public int getHeight() {
        return this.dialog.getHeight();
    }

    public void setColor(Color color) {
        if (!color.equals(this.model.getSelectedColor())) {
            this.skipEvent = true;
            this.model.setSelectedColor(color);
        }
    }

    public void show() {
        this.dialog.setVisible(true);
    }

    public void show(Point p) {
        this.dialog.setLocation(p.x, p.y);
        this.show();
    }

    public void hide() {
        this.dialog.setVisible(false);
    }

    private void removeTransparencySlider() throws Exception {
        AbstractColorChooserPanel[] colorPanels = this.colorChooser.getChooserPanels();
        for (int i = 1; i < colorPanels.length; i++) {
            AbstractColorChooserPanel cp = colorPanels[i];

            Field f = cp.getClass().getDeclaredField("panel");
            f.setAccessible(true);
            Object colorPanel = f.get(cp);

            Field f2 = colorPanel.getClass().getDeclaredField("spinners");
            f2.setAccessible(true);
            Object spinners = f2.get(colorPanel);

            int spinnerIndex = 3;
            if (i == colorPanels.length - 1) {
                spinnerIndex = 4;
            }
            Object transpSlispinner = Array.get(spinners, spinnerIndex);

            String fieldNames[] = {"slider", "spinner", "label"};
            for (String fn : fieldNames) {
                Field f3 = transpSlispinner.getClass().getDeclaredField(fn);
                f3.setAccessible(true);
                JComponent component = (JComponent) f3.get(transpSlispinner);
                component.setEnabled(false);
                component.setVisible(false);
            }
        }
    }

    public static Color createModalDialog(Window parent, String title, String infoText, Color initialColor) {
        return createModalDialog(parent, title, infoText, initialColor, null, null);
    }

    public static Color createModalDialog(Window parent, String title, String infoText, Color initialColor, Point location, ColorListener listener) {
        final boolean[] canceled = {false};
        ActionListener cancelListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                canceled[0] = true;
            }
        };

        ColorDialog colorDialog = new ColorDialog(parent, title, initialColor, cancelListener);
        if (infoText != null) {
            colorDialog.setInfoText(infoText);
        }
        if (listener != null) {
            colorDialog.addColorListener(listener);
        }
        colorDialog.dialog.setModal(true);
        if (location != null) {
            colorDialog.dialog.setLocation(location);
        }
        colorDialog.show();

        if (canceled[0]) {
            return null;
        } else {
            return colorDialog.model.getSelectedColor();
        }
    }
}
