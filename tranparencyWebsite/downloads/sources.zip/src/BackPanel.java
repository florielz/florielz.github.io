
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

public class BackPanel extends JPanel {

    private Image background;
    private Image backP;
    private Image backQ;
    private Image backPQ;
    private Image backT;
    private int back = 0;
    
    private SideFrame frame;

    public BackPanel(SideFrame frame) {
        try {
            this.background = ImageIO.read(this.getClass().getResource("resources/grid.png"));
            this.backP = ImageIO.read(this.getClass().getResource("resources/grid_p.png"));
            this.backQ = ImageIO.read(this.getClass().getResource("resources/grid_q.png"));
            this.backPQ = ImageIO.read(this.getClass().getResource("resources/grid_pq.png"));
            this.backT = ImageIO.read(this.getClass().getResource("resources/grid_t.png"));
        } catch (IOException ex) {
            Logger.getLogger(BackPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.frame = frame;
    }

    @Override
    public void paintComponent(Graphics g) {
        switch (back) {
            case 0:
                g.drawImage(backQ, 0, 0, null);
                break;
            case 1:
                g.drawImage(backP, 0, 0, null);
                break;
            case 2:
                g.drawImage(backPQ, 0, 0, null);
                break;
            case 3:
                g.drawImage(backT, 0, 0, null);
                break;
            default:
                g.drawImage(background, 0, 0, null);
                break;
        }

    }

    public void setBack(TransparencyLaw l) {
        if (l instanceof QEqualsZero) {
            back = 0;
            this.frame.getZeroPanel().setVisible(false);
            this.frame.getSlider().setVisible(true);
            this.frame.getTextField().setVisible(true);
            this.frame.getVariableLabel().setVisible(true);
            this.frame.getButtonSliderPanel().setVisible(true);
        } else if (l instanceof PEqualsZero) {
            back = 1;
            this.frame.getZeroPanel().setVisible(false);
            this.frame.getSlider().setVisible(true);
            this.frame.getTextField().setVisible(true);
            this.frame.getVariableLabel().setVisible(true);
            this.frame.getButtonSliderPanel().setVisible(true);
        } else if (l instanceof PEqualsQ) {
            back = 2;
            this.frame.getZeroPanel().setVisible(false);
            this.frame.getSlider().setVisible(true);
            this.frame.getTextField().setVisible(true);
            this.frame.getVariableLabel().setVisible(true);
            this.frame.getButtonSliderPanel().setVisible(true);
        } else if (l instanceof Zero) {
            back = 3;
            this.frame.getZeroPanel().setVisible(true);
            this.frame.getSlider().setVisible(false);
            this.frame.getTextField().setVisible(false);
            this.frame.getVariableLabel().setVisible(false);
            this.frame.getButtonSliderPanel().setVisible(false);
        }
        else{
            back = 4;
            this.frame.getZeroPanel().setVisible(false);
            this.frame.getSlider().setVisible(false);
            this.frame.getTextField().setVisible(false);
            this.frame.getVariableLabel().setVisible(false);
            this.frame.getButtonSliderPanel().setVisible(false);
        }
        this.repaint();
    }
}
