import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;


public class ColorSource extends Source
{
	private Color color;
	private Dimension sourceSize;
	private JPanel previewPanel;

	public ColorSource(Color initialColor)
	{
		this(initialColor, null);
	}

	public ColorSource(Color initialColor, Dimension sourceSize)
	{
		super(BoxLayout.PAGE_AXIS);

		this.color = initialColor;
		this.sourceSize = sourceSize;

		Dimension previewSize = new Dimension(100, 60);
		if(sourceSize != null)
		{
			previewSize = new Dimension(sourceSize.width, sourceSize.height);
			Dimension maxPreviewSize = new Dimension(100, 100);
			Utility.fitDimension(previewSize, maxPreviewSize);
		}

		this.previewPanel = new JPanel();
		this.previewPanel.setPreferredSize(previewSize);
		this.previewPanel.setMaximumSize(previewSize);
		this.previewPanel.setBackground(initialColor);
		this.previewPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		this.add(Box.createVerticalGlue());
		this.add(Utility.padComponentH(this.previewPanel));
		this.add(Box.createVerticalGlue());
	}
        
        public void updateSource(Color newColor){
            this.color = newColor;
            this.previewPanel.setBackground(newColor);
        }

	@Override
	public String toString()
	{
		return String.format("color R:%d G:%d B:%d", this.color.getRed(), this.color.getGreen(), this.color.getBlue());
	}

	@Override
	public Dimension getSourceSize()
	{
		if(this.sourceSize != null)
			return new Dimension(this.sourceSize.width, this.sourceSize.height);
		else
			return null;
	}

	@Override
	public Color getPixel(float x, float y)
	{
		return this.color;
	}
}
