
import java.awt.Color;

public class NonScattering extends TransparencyLaw {

    private NonScattering associatedLaw;
    private boolean expected = false;

    @Override
    public String getName() {
        return "Kubelka Munk";
    }

    @Override
    public String getFunction() {
        return "";
    }

    @Override
    public String getFunction(double val) {
        return "";
    }

    @Override
    public double apply(double back, double front, double n, double a, double b) {
        if (expected) {
            return Math.pow(back / front, 1 / n);
        } else if (inverse) {
            return (back * Math.pow(front, -n));
        } else {
            return (back * Math.pow(front, n));
        }
    }

    public Color apply(Color back, Color front, double n, double a, double b, boolean nullify) {
        if (inverse && !uniform) {
            nMax = getRemoval(back, front, n, a, b);
            n = n * nMax;
        }
        double r9 = this.apply((253.0 * back.getRed() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getRed() + 255.0) / (255.0 * 255.0), n, a, b);
        double g9 = this.apply((253.0 * back.getGreen() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0), n, a, b);
        double b9 = this.apply((253.0 * back.getBlue() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0), n, a, b);

        double r0 = ((255.0 * (255.0 * r9 - 1.0)) / 253.0);
        double g0 = ((255.0 * (255.0 * g9 - 1.0)) / 253.0);
        double b0 = ((255.0 * (255.0 * b9 - 1.0)) / 253.0);

        int r1;
        if (Double.isNaN(r0)) {
            r1 = -300;
        } else {
            r1 = (int) Math.round(r0);
        }

        int g1;
        if (Double.isNaN(g0)) {
            g1 = -300;
        } else {
            g1 = (int) Math.round(g0);
        }

        int b1;
        if (Double.isNaN(b0)) {
            b1 = -300;
        } else {
            b1 = (int) Math.round(b0);
        }

        if (r1 == -1) {
            r1 = 0;
        }
        if (g1 == -1) {
            g1 = 0;
        }
        if (b1 == -1) {
            b1 = 0;
        }
        if (r1 == 256) {
            r1 = 255;
        }
        if (g1 == 256) {
            g1 = 255;
        }
        if (b1 == 256) {
            b1 = 255;
        }

        int r2 = Math.max(0, Math.min(255, r1));
        int g2 = Math.max(0, Math.min(255, g1));
        int b2 = Math.max(0, Math.min(255, b1));
        if (nullify && (r2 != r1 || g2 != g1 || b2 != b1)) {
            return null;
        } else {
            return new Color(r2, g2, b2);
        }
    }

    @Override
    public double f(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double fInverse(double x, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TransparencyLaw associatedLaw() {
        if (associatedLaw == null) {
            associatedLaw = new NonScattering();
        }
        return associatedLaw;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isExpected() {
        return expected;
    }

    @Override
    public void setExpected(boolean b) {
        expected = b;
    }

    @Override
    protected double compute(double back, double front, double n, double alpha, double beta) {
        return (Math.log(back) / Math.log(front));
    }
}
