
public class InverseUniform extends TransparencyLaw {

    @Override
    public boolean isInverse() {
        return true;
    }

    @Override
    public boolean isUniform() {
        return true;
    }

    @Override
    public String getName() {
        return " ";
    }

    @Override
    public String getFunction() {
        return " ";
    }

    @Override
    public TransparencyLaw associatedLaw() {
        return TransparencyLaws.DIRECT_UNIFORM;
    }

    @Override
    public double apply(double back, double front, double c, double t) {
        if (t == 0.0) {
            return Math.pow(back / Math.pow(front, 1.0 - c), 1.0 / c);
        } else {
            return Math.pow((Math.pow(back, t) - (1.0 - c) * Math.pow(front, t)) / c, 1.0 / t);
        }
    }

    @Override
    public double f(double x, double t) {
        if (t == 0) {
            return (Math.log(x));
        } else {
            return (Math.pow(x, t));
        }
    }

    @Override
    public double fInverse(double x, double t) {
        if (t == 0) {
            return (Math.exp(x));
        } else {
            return (Math.pow(x, 1.0 / t));
        }
    }

    @Override
    public String getFunction(double val) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
