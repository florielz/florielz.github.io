import java.awt.*;
import java.awt.event.*;
import java.lang.reflect.*;
import java.net.*;
import java.util.*;

import javax.swing.*;
import javax.swing.colorchooser.*;
import javax.swing.event.*;


public class Utility
{
	// creates a horizontal box containing a given component surrounded by glue
	public static Box padComponentH(JComponent component)
	{
		Box box = Box.createHorizontalBox();
		box.add(Box.createHorizontalGlue());
		box.add(component);
		box.add(Box.createHorizontalGlue());
		return box;
	}

	// creates a horizontal box containing a given component and glue on the right side
	public static Box padComponentLeft(JComponent component)
	{
		Box box = Box.createHorizontalBox();
		box.add(component);
		box.add(Box.createHorizontalGlue());
		return box;
	}

	// creates a vertical box containing a given component and glue on the bottom side
	public static Box padComponentTop(JComponent component)
	{
		Box box = Box.createVerticalBox();
		box.add(component);
		box.add(Box.createVerticalGlue());
		return box;
	}

	// repaints a component immediately
	public static void repaintNow(JComponent component)
	{
		component.paintImmediately(0, 0, component.getWidth(), component.getHeight());
	}

	// returns the square of the value
	public static int square(int val)
	{
		return val*val;
	}

	// returns the value clamped to min and max
	public static int clamp(int val, int min, int max)
	{
		if(val <= min)
			return min;
		if(val >= max)
			return max;
		return val;
	}

	// returns a color without the alpha channel
	public static Color removeAlpha(Color color)
	{
		return new Color(color.getRed(), color.getGreen(), color.getBlue());
	}

	// fins the nearest point on a line
	public static Point nearestPointOnLine(int ax, int ay, int bx, int by, int px, int py)
	{
		int apx = px - ax;
		int apy = py - ay;
		int abx = bx - ax;
		int aby = by - ay;

		int ab2 = abx * abx + aby * aby;
		int ap_ab = apx * abx + apy * aby;
		float t = 1.0f * ap_ab / ab2;
		t = Math.max(0.0f, Math.min(1.0f, t));
		return new Point(Math.round(ax+abx*t), Math.round(ay+aby*t));
	}

	// fit a dimension into an other keeping its width/height ratio
	public static void fitDimension(Dimension d, Dimension max)
	{
		float wr = 1.0f * d.width / max.width;
		float hr = 1.0f * d.height / max.height;
		float r = Math.max(1.0f, Math.max(wr, hr));
		d.width /= r;
		d.height /= r;
	}

	// opens a web page in the user's default browser
	public static void launchUrl(URL url)
	{
		Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
		if(desktop != null && desktop.isSupported(Desktop.Action.BROWSE))
		{
			try { desktop.browse(url.toURI()); }
			catch(Exception e) { }
		}
	}
}
