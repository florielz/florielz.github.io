import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.swing.event.*;


public class IconPanel extends JComponent
{
	private Image image;

	public IconPanel(Dimension dimension, Image image)
	{
		Dimension d = new Dimension(image.getWidth(null), image.getHeight(null));
		Utility.fitDimension(d, dimension);

		this.image = image.getScaledInstance(d.width, d.height, BufferedImage.SCALE_AREA_AVERAGING);

		this.setPreferredSize(d);
		this.setMinimumSize(d);
		this.setMaximumSize(d);
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		if(this.image == null)
			return;

		int w = this.getWidth();
		int h = this.getHeight();
		g.drawImage(this.image, 0, 0, w, h, null);
	}
}
