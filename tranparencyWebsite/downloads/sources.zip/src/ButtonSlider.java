
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class ButtonSlider extends JLabel {

    public ButtonSlider(SecondApplication app, SideFrame frame, int x, int y, double val, String s) {
        super(s,JLabel.CENTER);
        this.setBounds(x, y, 28, 20);
        this.setOpaque(false);
        frame.getButtonSliderPanel().add(this);
        this.setBorder(BorderFactory.createRaisedBevelBorder());
        addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                ((JLabel)e.getSource()).setBorder(BorderFactory.createRaisedBevelBorder());
                app.setType(val);
                frame.update(frame.getTextField(), frame.getSlider(), val);
                if (val == Double.NEGATIVE_INFINITY) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p1);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q1);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq1);
                    }
                } else if (val == -2.0) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p2);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q2);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq2);
                    }
                } else if (val == -1.0) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p3);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q3);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq3);
                    }
                } else if (val == -0.5) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p4);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q4);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq4);
                    }
                } else if (val == 0) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p5);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q5);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq5);
                    }
                } else if (val == 0.5) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p7);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q7);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq7);
                    }
                } else if (val == 1.0) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p8);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q8);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq8);
                    }
                } else if (val == 2.0) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p9);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q9);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq9);
                    }
                } else if (val == Double.POSITIVE_INFINITY) {
                    if (app.selectedLaw instanceof PEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.p10);
                    } else if (app.selectedLaw instanceof QEqualsZero) {
                        frame.getButtonGroup().setSelected(frame.q10);
                    } else if (app.selectedLaw instanceof PEqualsQ) {
                        frame.getButtonGroup().setSelected(frame.pq10);
                    }
                } else {
                    frame.getButtonGroup().clearSelection();
                }
            }

            public void mousePressed(MouseEvent e) {
                ((JLabel)e.getSource()).setBorder(BorderFactory.createLoweredBevelBorder());
            }

            public void mouseClicked(MouseEvent e) {
                
            }
        }
        );
    }
    
    public ButtonSlider(ThirdApplication app, double val, String s) {
        super(s,JLabel.CENTER);
        Dimension d = new Dimension(28,20);
        this.setPreferredSize(d);
        this.setMaximumSize(d);
        this.setMinimumSize(d);
        this.setOpaque(false);
        this.setBorder(BorderFactory.createRaisedBevelBorder());
        addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                ((JLabel)e.getSource()).setBorder(BorderFactory.createRaisedBevelBorder());
                if (val == 0) {
                    app.updateThicknessSlider(200);
                } else if (val == 0.5) {
                    app.updateThicknessSlider(150);
                } else if (val == 1.0) {
                    app.updateThicknessSlider(100);
                } else if (val == 2.0) {
                    app.updateThicknessSlider(50);
                } else if (val == Double.POSITIVE_INFINITY) {
                    app.updateThicknessSlider(0);
                }
            }

            public void mousePressed(MouseEvent e) {
                ((JLabel)e.getSource()).setBorder(BorderFactory.createLoweredBevelBorder());
            }
        }
        );
    }
}
