
import java.awt.Color;

public abstract class TransparencyLaw {

    protected boolean inverse = false;

    protected boolean uniform = true;

    protected double cmin;

    protected double nMax;

    public void setInverse(boolean b) {
        this.inverse = b;
    }

    public void setUniform(boolean b) {
        this.uniform = b;
    }

    public boolean isInverse() {
        return this.inverse;
    }

    public boolean isUniform() {
        return this.uniform;
    }

    public abstract String getName();
    
    public String getName(double val){
        throw new UnsupportedOperationException("You shouldn't use this function");
    }

    public abstract String getFunction();

    public abstract String getFunction(double val);

    public abstract double f(double x, double t);

    public abstract double fInverse(double x, double t);

    public abstract TransparencyLaw associatedLaw();

    public abstract double apply(double back, double front, double c, double t);

    public Color apply(Color back, Color front, double c, double t, boolean nullify) {

        if (isInverse() && isUniform() && c == 0) {
            if (!nullify) {
                c = 0.0001;
            } else {
                return null;
            }
        } else if (isInverse() && isUniform() && c == 1) {
            return back;
        }
        if (isInverse() && isUniform() && (t == Double.POSITIVE_INFINITY || t == Double.NEGATIVE_INFINITY)) {
            if (!nullify) {
                return back;
            } else if (t == Double.POSITIVE_INFINITY) {
                if (back.getRed() > front.getRed() && back.getGreen() > front.getGreen() && back.getBlue() > front.getBlue()) {
                    return back;
                } else {
                    return null;
                }
            } else if (back.getRed() < front.getRed() && back.getGreen() < front.getGreen() && back.getBlue() < front.getBlue()) {
                return back;
            } else {
                return null;
            }
        }
        if (isInverse() && !isUniform()) {
            if (t == Double.POSITIVE_INFINITY || t == Double.NEGATIVE_INFINITY) {
                return back;
            }
            double a = c;
            cmin = getRemoval(back, front, a, t);
            c = 1.0 - a * (1.0 - cmin);
        }
        double r = ((255.0 * (255.0 * this.apply((253.0 * back.getRed() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getRed() + 255.0) / (255.0 * 255.0), c, t) - 1.0)) / 253.0);
        double g = ((255.0 * (255.0 * this.apply((253.0 * back.getGreen() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0), c, t) - 1.0)) / 253.0);
        double b = ((255.0 * (255.0 * this.apply((253.0 * back.getBlue() + 255.0) / (255.0 * 255.0),
                (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0), c, t) - 1.0)) / 253.0);

        if (isInverse() && isUniform()) {
            cmin = getRemoval(back, front, c, t);
            if (nullify && (c < cmin)) {
                return null;
            }
        }

        int r1;
        if (Double.isNaN(r)) {
            r1 = -300;
        } else {
            r1 = (int) Math.round(r);
        }

        int g1;
        if (Double.isNaN(g)) {
            g1 = -300;
        } else {
            g1 = (int) Math.round(g);
        }

        int b1;
        if (Double.isNaN(b)) {
            b1 = -300;
        } else {
            b1 = (int) Math.round(b);
        }

        int r2 = Math.max(0, Math.min(255, r1));
        int g2 = Math.max(0, Math.min(255, g1));
        int b2 = Math.max(0, Math.min(255, b1));
        if (nullify && (r2 != r1 || g2 != g1 || b2 != b1)) {
            return null;
        } else {
            return new Color(r2, g2, b2);
        }

    }

    public Color apply(Color back, Color front, double c, double t) {
        return this.apply(back, front, c, t, false);
    }

    private double compute(double back, double front, double t) {
        if (back < front) {
            return ((f(back, t) - f(front, t)) / (f(1.0 / 255.0, t) - f(front, t)));
        } else if (back > front) {
            return ((f(back, t) - f(front, t)) / (f(254.0 / 255.0, t) - f(front, t)));
        } else {
            return 0.1;
        }
    }

    public double getRemoval(Color back, Color front, double a, double t) {
        double br = (253.0 * back.getRed() + 255.0) / (255.0 * 255.0);
        double bg = (253.0 * back.getGreen() + 255.0) / (255.0 * 255.0);
        double bb = (253.0 * back.getBlue() + 255.0) / (255.0 * 255.0);
        double fr = (253.0 * front.getRed() + 255.0) / (255.0 * 255.0);
        double fg = (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0);
        double fb = (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0);

        double cr = this.compute(br, fr, t);
        double cg = this.compute(bg, fg, t);
        double cb = this.compute(bb, fb, t);

        double cmin = Math.max(cr, Math.max(cg, cb));
        return cmin;
    }

    public double getRemoval(Color back, Color front, double n, double a, double b) {
        double br = (253.0 * back.getRed() + 255.0) / (255.0 * 255.0);
        double bg = (253.0 * back.getGreen() + 255.0) / (255.0 * 255.0);
        double bb = (253.0 * back.getBlue() + 255.0) / (255.0 * 255.0);
        double fr = (253.0 * front.getRed() + 255.0) / (255.0 * 255.0);
        double fg = (253.0 * front.getGreen() + 255.0) / (255.0 * 255.0);
        double fb = (253.0 * front.getBlue() + 255.0) / (255.0 * 255.0);

        double nr = this.compute(br, fr, n, a, b);
        double ng = this.compute(bg, fg, n, a, b);
        double nb = this.compute(bb, fb, n, a, b);

        double nMax = Math.min(nr, Math.min(ng, nb));
        return nMax;
    }

    protected double compute(double back, double front, double n, double alpha, double beta) {
        double rl = alpha * front + beta;
        double a = (1.0 + Math.pow(front, 2.0)) / (2.0 * front);
        double b = Math.sqrt(Math.pow(a, 2.0) - 1.0);

        if (back < front) {
            return Math.log(1.0 - (2.0 * b * back) / ((b - a) * back + 1.0)) / Math.log((1.0 - (a + b) * rl) / (1.0 - (a - b) * rl));
        } else if (back > front) {
            return Math.log((1.0 - a + b + (1.0 - a - b) * back) / (1.0 - a - b + (1.0 - a + b) * back)) / Math.log((1.0 - (a + b) * rl) / (1.0 - (a - b) * rl));
        } else {
            return n;
        }
    }

    public double apply(double back, double front, double n, double a, double b) {
        throw new UnsupportedOperationException("You shouldn't use this function");
    }

    public Color apply(Color back, Color front, double n, double a, double b) {
        return apply(back, front, n, a, b, false);
    }

    public Color apply(Color back, Color front, double n, double a, double b, boolean nullify) {
        throw new UnsupportedOperationException("You shouldn't use this function");
    }

    public boolean isExpected() {
        return false;
    }

    public void setExpected(boolean b) {

    }
}
