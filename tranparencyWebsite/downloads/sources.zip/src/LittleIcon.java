
import java.awt.*;
import javax.swing.*;

public class LittleIcon extends JComponent {

    private Image image;
    private Color color;

    public LittleIcon(int x, int y) {
        this.image = null;
        this.color = null;

        //this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        this.setPreferredSize(new Dimension(x + 2, y + 2));
        this.setMaximumSize(new Dimension(x + 2, y + 2));
    }

    public void setImage(Image image) {
        this.image = image;
        this.color = null;
        this.repaint();
    }

    public void setColor(Color color) {
        this.image = null;
        this.color = color;
        this.repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int w;
        int h;
        if (this.image == null) {
            w = getWidth() - 2;
            h = (getHeight() - 2) * 56 / 100;
            g.setColor(this.color);
            g.fillRect(1, 1 + ((getHeight() - 2) * 22 / 100), w, h);
            g.setColor(Color.BLACK);
            g.drawRect(0, ((getHeight() - 2) * 22 / 100), w + 1, h + 1);
        } else {
            w = this.image.getWidth(null);
            h = this.image.getHeight(null);
            g.drawImage(this.image, 1, 1, w, h, null);
            g.setColor(Color.BLACK);
            g.drawRect(0, 0, w + 1, h + 1);
        }
    }
}
