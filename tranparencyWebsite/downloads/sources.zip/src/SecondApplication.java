
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.beans.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;

public class SecondApplication implements ActionListener {

    private static final Color DEFAULT_BACK_COLOR = new Color(246, 246, 246);
    private static final Color DEFAULT_FRONT_COLOR = new Color(246, 0, 0);
    private static final int DEFAULT_TRANSPARENCY = 50;
    private static final int DEFAULT_REMOVAL = 50;
    public static final int DEFAULT_TYPE = 0;
    private static final Color DEFAULT_INVALID_COLOR = new Color(255, 0, 0);
    private static final String MANUAL_FILENAME = "resources/manual.html";
    private static final String BACKGROUND_FILENAME = "church.jpg";
    private static final String FOREGROUND_FILENAME = "logo.jpg";
    private static final String BACKGROUND_LOCATION = "resources/church.jpg";
    private static final String FOREGROUND_LOCATION = "resources/logo.jpg";
    private static final String WEBSITE_URL = "http://rgbtransparency.edel.univ-poitiers.fr";

    private Menu application;

    private JRadioButton button360;
    private JRadioButton button480;
    private JRadioButton button640;
    private JCheckBox bordersCheckbox;
    private JCheckBox highlightCheckbox;
    private JCheckBox infoFileCheckbox;
    private String saveDirectory;
    public ArrayList<TransparencyLaw> laws;
    public TransparencyLaw selectedLaw;
    private Source backSource;
    private Source frontSource;
    private double transparency;
    private double type;
    private double removal;
    private Color edgeColor;
    private double removalTable[][];
    private Color opaqueSelectionColor;

    private boolean updatesEnabled;
    private String previousInfoString;
    private Source tempBackSource;
    private Source oldBackSource;
    private Source oldFrontSource;

    private boolean bordersEnabled;
    private boolean enableInfoFile;
    private boolean highlightInvalidPixels;
    private Color invalidColor;
    private int defaultWidth;
    private int width;

    private DisabledPanel topDisabledPanel;
    private DisabledPanel botDisabledPanel;
    public DisabledPanel sideDisabledPanel;

    private JFrame frame;
    private JMenu menuSteps;
    private JMenu menuHelp;
    private JMenu menuApp;
    private JDialog settingsDialog;
    private JDialog manualDialog;
    private Box backBox;
    private Box frontBox;
    private ColorDialog backColorDialog;
    private ColorDialog frontColorDialog;
    private ImagePanel resultPanel;
    private JPanel resultContainer;
    private DualBoard dualBoard;
    private JButton switchButton;
    private JButton expectedButton;
    private JButton selectedLawButton;
    private JPopupMenu transparencyLawMenu;
    private JSlider transparencySlider;
    private JSlider removalSlider;
    private JLabel impossibleRemoval;
    private JSlider typeSliderInv; //Slider for Inverse Law
    private Box sliderBox;
    private JSlider typeSlider;    //Slider for nonInverse Law
    private JSpinner typeSpinner;
    private JLabel spinnerLabel;
    private Box spinnerBox;
    public JLabel informationLawLabel;
    public JLabel informationMeanLabel;
    public JLabel informationTransparencyLabel;

    private java.util.List<JSlider> sliderList;
    private java.util.List<JTextField> textList;
    private SideFrame sideFrame;
    private JLabel maxRemovalLabel;
    private JLabel noRemovalLabel;
    private JProgressBar progressBar;

    // creates the result image of the given dimension
    private BufferedImage computeResult(int width, int height, boolean showProgress) {
        BufferedImage resultImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        boolean isFrontImage = this.frontSource instanceof ImageSource;
        boolean nullify = this.highlightInvalidPixels;
        boolean directNonUniform = !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform();
        double c = this.selectedLaw.isUniform() ? this.transparency : this.removal;

        if (showProgress) {
            this.progressBar.setVisible(true);
        }

        LinkedList<Polygon> selections = this.resultPanel.getSelections();
        LinkedList<Polygon> expSelections = this.resultPanel.getExpSelections();

        Polygon currentSel = this.resultPanel.getCurrentSelection();
        resultPanel.resetInvalidMap();
        for (int y = 0; y < height; y++) {
            if (showProgress && y % (height / 50) == 0) {
                this.progressBar.setValue(100 * y / (height - 1));
                Utility.repaintNow(this.progressBar);
            }
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                Color color = backColor;
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                for (Polygon s : selections) {
                    if (s.contains(x1, y1)) {
                        if (opaqueSelectionColor != null && s == currentSel) {
                            color = opaqueSelectionColor;
                        } else {
                            if (directNonUniform) {
                                int x2 = Math.round(rx * (this.removalTable.length - 1));
                                int y2 = Math.round(ry * (this.removalTable[0].length - 1));
                                double cmin = this.removalTable[x2][y2];
                                c = 1.0 - this.removal * (1.0 - cmin);
                            }
                            if (isFrontImage) {
                                Rectangle bounds = s.getBounds();
                                rx = 1.0f * (x1 - bounds.x) / bounds.width;
                                ry = 1.0f * (y1 - bounds.y) / bounds.height;
                            }
                            Color frontColor = this.frontSource.getPixel(rx, ry);
                            color = this.selectedLaw.apply(backColor, frontColor, c, this.type, nullify);
                            if (color == null) {
                                color = this.invalidColor;
                                resultPanel.addInvalidPixel(x, y);
                            }
                        }
                        break;
                    }
                }
                for (Polygon s : expSelections) {
                    if (s.contains(x1, y1)) {
                        if (opaqueSelectionColor != null) {
                            color = opaqueSelectionColor;
                        }
                        /*else {
                            if (directNonUniform) {
                                int x2 = Math.round(rx * (this.removalTable.length - 1));
                                int y2 = Math.round(ry * (this.removalTable[0].length - 1));
                                double cmin = this.removalTable[x2][y2];
                                c = 1.0 - this.removal * (1.0 - cmin);
                            }
                            if (isFrontImage) {
                                Rectangle bounds = s.getBounds();
                                rx = 1.0f * (x1 - bounds.x) / bounds.width;
                                ry = 1.0f * (y1 - bounds.y) / bounds.height;
                            }
                            Color frontColor = this.frontSource.getPixel(rx, ry);
                            color = this.selectedLaw.apply(backColor, frontColor, 0, this.type, nullify);
                            if (color == null) {
                                color = this.invalidColor;
                                resultPanel.addInvalidPixel(x, y);
                            }
                        }
                        break;*/
                    }
                }
                resultImage.setRGB(x, y, color.getRGB());
            }
        }

        Graphics2D g = resultImage.createGraphics();
        double scale = 1.0 * width / this.resultPanel.getWidth();
        g.scale(scale, scale);
        g.setStroke(new BasicStroke(Math.round(1.0 / scale)));

        for (Polygon s : expSelections) {
            g.drawPolygon(s.xpoints, s.ypoints, s.npoints);
        }
        if (this.bordersEnabled) {
            g.setColor(this.edgeColor);
            for (Polygon s : selections) {
                g.drawPolygon(s.xpoints, s.ypoints, s.npoints);
            }
        }

        if (showProgress) {
            this.progressBar.setValue(100);
            Utility.repaintNow(this.progressBar);
            this.progressBar.setVisible(false);
        }
        return resultImage;
    }

    // computes the removal for each pixel
    public void computeRemoval() {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }
        int width = resultSize.width;
        int height = resultSize.height;

        boolean isFrontImage = this.frontSource instanceof ImageSource;
        TransparencyLaw law = this.selectedLaw;

        this.removalTable = new double[width][height];
        LinkedList<Polygon> selections = this.resultPanel.getSelections();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                double removalValue = 1.0;
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                for (Polygon s : selections) {
                    if (s.contains(x1, y1)) {
                        if (isFrontImage) {
                            Rectangle bounds = s.getBounds();
                            rx = 1.0f * (x1 - bounds.x) / bounds.width;
                            ry = 1.0f * (y1 - bounds.y) / bounds.height;
                        }
                        Color frontColor = this.frontSource.getPixel(rx, ry);
                        removalValue = law.getRemoval(backColor, frontColor, this.removal, this.type);
                        break;
                    }
                }
                this.removalTable[x][y] = removalValue;
            }
        }
    }

    // computes the suggested foreground color
    public Color computeSuggestedForeground(Color expectedBackColor) {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null || this.backSource instanceof ColorSource) {
            resultSize = new Dimension(1, 1);
        }
        int width = resultSize.width;
        int height = resultSize.height;

        long sumRed = 0;
        long sumGreen = 0;
        long sumBlue = 0;
        long numPixels = 0;
        LinkedList<Polygon> selections = this.resultPanel.getExpSelections();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                for (Polygon s : selections) {
                    if (s.contains(x1, y1)) {
                        sumRed += backColor.getRed();
                        sumGreen += backColor.getGreen();
                        sumBlue += backColor.getBlue();
                        numPixels++;
                        //break;
                    }
                }
            }
        }

        Color backColor = new Color((int) (sumRed / numPixels), (int) (sumGreen / numPixels), (int) (sumBlue / numPixels));

        TransparencyLaw law = TransparencyLaws.INVERSE_NON_UNIFORM;
        return law.apply(backColor, expectedBackColor, 1.0, this.type);
    }

    // updates the dual board using the current settings
    private void updateDualBoard() {
        TransparencyLaw dualBoardLaw = this.selectedLaw;
        if (this.selectedLaw.isInverse()) {
            dualBoardLaw = this.selectedLaw.associatedLaw();
        }

        if (this.frontSource instanceof ImageSource) {
            Dimension d = this.frontSource.getSourceSize();
            Dimension max = new Dimension(this.dualBoard.getWidth() / 2, this.dualBoard.getHeight() / 2);
            Utility.fitDimension(d, max);
            BufferedImage resultImage = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);

            for (int y = 0; y < d.height; y++) {
                for (int x = 0; x < d.width; x++) {
                    float rx = x / (d.width - 1.0f);
                    float ry = y / (d.height - 1.0f);
                    Color backColor = (rx > 0.50f ? Color.WHITE : Color.BLACK);
                    Color frontColor = this.frontSource.getPixel(rx, ry);
                    Color color = dualBoardLaw.apply(backColor, frontColor, this.transparency, this.type);
                    resultImage.setRGB(x, y, color.getRGB());
                }
            }

            this.dualBoard.setImage(resultImage, this.edgeColor);
        } else {
            Color frontColor = this.frontSource.getPixel(0, 0);
            Color blackColor = dualBoardLaw.apply(new Color(0, 0, 0), frontColor, this.transparency, this.type);
            Color whiteColor = dualBoardLaw.apply(new Color(255, 255, 255), frontColor, this.transparency, this.type);
            this.dualBoard.setColors(blackColor, whiteColor, this.edgeColor);
        }
    }

    // enable/disable result panel updates (used when we want to set the initial settings)
    private void enableUpdates(boolean enabled) {
        this.updatesEnabled = enabled;
    }

    // updates the result panel using the current settings
    public void updateResult() {
        if (!this.updatesEnabled) {
            return;
        }

        if (this.backSource == null || this.frontSource == null) {
            this.resultPanel.setImage(null);
            this.frame.pack();
            return;
        }

        // compute size
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        Dimension maxSize = this.resultPanel.getContainerSize();
        Utility.fitDimension(resultSize, maxSize);

        this.resultPanel.setPanelSize(resultSize, this.resultContainer.getSize());

        // compute result image
        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, false);

        // update dual board
        if (selectedLaw.isUniform()) {
            this.updateDualBoard();
        }

        // update result panel
        this.resultPanel.setImage(resultImage);
    }

    // saves the result image to a file
    private void saveResult(String filename) {
        if (this.backSource == null || this.frontSource == null) {
            return;
        }

        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, true);

        boolean success = false;
        try {
            success = ImageIO.write(resultImage, "JPEG", new File(filename));
        } catch (IOException e) {
            success = false;
        }

        if (!success) {
            System.out.println("Couldn't save image");
        }

        if (this.enableInfoFile) {
            saveInfoFile(filename.substring(0, filename.length() - 4) + ".txt");
        }
    }

    // gets the result image as a source
    private Source getResultAsSource() {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, true);

        return new ImageSource("", "", resultImage);
    }

    // sets the result image in the background source
    private void loadResultAsBack() {
        this.setBack(this.getResultAsSource());
    }

    // saves the info file
    private void saveInfoFile(String filename) {
        PrintWriter writer;
        try {
            writer = new PrintWriter(filename, "UTF-8");
        } catch (IOException e) {
            System.out.println("Couldn't save info file");
            return;
        }

        if (this.previousInfoString != null && !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform()) {
            writer.print(this.previousInfoString);
            writer.println();
        }
        writer.print(this.getInfoString());
        writer.close();
    }

    // gets info data
    private String getInfoString() {
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);

        writer.printf("Transparency as generalized f-mean\r\n");
        writer.printf("Selected function: %s\r\n", selectedLaw.getName(this.type));
        if (!(selectedLaw instanceof Zero)) {
            writer.printf("p = %.2f\r\n\r\n", this.type);
        }
        else{
            writer.printf("\r\n\r\n");
        }
        
        writer.printf("Background: %s\r\n", this.backSource.toString());
        writer.printf("Foreground: %s\r\n\r\n", this.frontSource.toString());
        
        writer.printf("%s\r\n", this.selectedLawButton.getText());
        if (this.selectedLaw.isUniform()) {
            writer.printf("Transparency rate: %d%% (0%%: opaque, 100%%: transparent)\r\n", (int) (this.transparency * 100));
        } else if (this.selectedLaw.isInverse()) {
            writer.printf("Transparency removal: %d%% (0%%: no removal, 100%%: max. removal)\r\n", (int) (this.removal * 100));
        } else {
            writer.printf("Transparency density: %d%% (0%%: no density, 100%%: max. density)\r\n", (int) (this.removal * 100));
        }

        String data = stringWriter.toString();
        writer.close();
        return data;
    }

    // changes the maximum dimension of the result panel
    private void setMaxDisplayWidth(int w) {
        this.width = w;
        this.resultPanel.setMaxSize(new Dimension(w, 360));
        this.resultContainer.setPreferredSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setMinimumSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setMaximumSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setSize(new Dimension(w + 20, 360 + 20));
        this.updateResult();
        this.frame.pack();
    }

    // checks that we load a background of the same size
    private boolean checkBackSize(Source source) {
        if (this.backSource == null || source.getSourceSize() == null || this.backSource.getSourceSize() == null) {
            return true;
        }
        if (!source.getSourceSize().equals(this.backSource.getSourceSize())) {
            JOptionPane.showMessageDialog(frame, "The dimensions of the image should be equal to the dimensions of the current background.",
                    "Invalid image dimensions", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    // changes one of the source
    private void setSource(SourcePos pos, Source source) {
        if (source == null) {
            return;
        }

        // in direct non-uniform mode, check that we load a background of the same size
        if (pos == SourcePos.BACK && !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform()) {
            if (!checkBackSize(source)) {
                return;
            }
        }

        // hide color dialog if needed
        ColorDialog dialog = (pos == SourcePos.BACK ? this.backColorDialog : this.frontColorDialog);
        if (source instanceof ColorSource) {
            dialog.setColor(source.getPixel(0, 0));
        } else {
            dialog.hide();
            dialog.setColor(pos == SourcePos.BACK ? DEFAULT_BACK_COLOR : DEFAULT_FRONT_COLOR);
        }

        // reset result panel selections and update edge color if front source
        if (pos == SourcePos.FRONT) {
            if ((frontSource == null || !(frontSource instanceof ColorSource && source instanceof ColorSource)) && this.resultPanel.getSelections().size() == 0) {
                this.resultPanel.resetSelections(source.getSourceSize());
            }

            this.edgeColor = new Color(153, 153, 153);
            if (source instanceof ColorSource) {
                this.edgeColor = source.getPixel(0, 0);
            }
        }

        // update source
        if (pos == SourcePos.BACK) {
            this.backSource = source;
        } else {
            this.frontSource = source;
        }

        // update source container
        Box box = (pos == SourcePos.BACK ? this.backBox : this.frontBox);
        box.removeAll();
        box.add(source);
        box.repaint();

        // update result image
        this.updateResult();
        this.frame.pack();
    }

    // changes the background source
    public void setBack(Source source) {
        this.setSource(SourcePos.BACK, source);
    }

    // changes the foreground source
    public void setFront(Source source) {
        this.setSource(SourcePos.FRONT, source);
    }

    public TransparencyLaw getSelectedLaw() {
        return selectedLaw;
    }

    // changes the transparency law
    public void setLaw(TransparencyLaw law, boolean isInverse, boolean isUniform) {
        if (this.selectedLaw != null) {
            this.previousInfoString = getInfoString();
        }
        this.selectedLaw = law;

        if (isUniform || isInverse) {
            sideDisabledPanel.setEnabled(true);
            switchButton.setText("<html><center>Visualize Removal Part</center></html>");
        } else {
            switchButton.setText("<html><center>Back To Inverse Transparency</center></html>");
        }

        String text = String.format("%s %s Transparency", isInverse ? "Inverse" : "Direct",
                isUniform ? "Uniform" : "Non Uniform");
        this.selectedLawButton.setText(text);

        sideFrame.getPanel().setBack(law);

        if (!isUniform) {
            this.maxRemovalLabel.setText(isInverse ? "Max. Removal" : "Max. Density");
            this.noRemovalLabel.setText(isInverse ? "No Removal" : "No Density");
            this.removalSlider.repaint();
        }

        this.transparencySlider.setVisible(isUniform);
        this.removalSlider.setVisible(!isUniform && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);
        this.impossibleRemoval.setVisible(!isUniform && (type == Double.POSITIVE_INFINITY || type == Double.NEGATIVE_INFINITY));
        this.dualBoard.setVisible(isUniform);
        if (selectedLaw != null) {
            if (!selectedLaw.isUniform() && isUniform) {
                frame.pack();
            }
        }
        this.switchButton.setVisible(!isUniform && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);
        this.expectedButton.setVisible(!isUniform && isInverse && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);

        this.informationLawLabel.setText("<html><center>Selected function<br/>" + this.selectedLaw.getFunction(this.type) + "</center></html>");
        if (this.selectedLaw instanceof Zero && ((Zero) this.selectedLaw).getLaw() == 0) {
            this.informationMeanLabel.setText("Geometric mean");
            this.informationTransparencyLabel.setText("Subtractive transparency");
            this.informationTransparencyLabel.setLocation(28, 35);
        } else if (this.selectedLaw instanceof Zero) {
            this.informationMeanLabel.setText("");
            this.informationTransparencyLabel.setText("");
        }

        boolean directNonUniform = !isInverse && !isUniform;
        this.resultPanel.setSelectionsLocked(directNonUniform);

        this.resultPanel.setExpectedEnabled(isInverse);

        this.selectedLaw = law;
        this.selectedLaw.setInverse(isInverse);
        this.selectedLaw.setUniform(isUniform);

        this.updateResult();
    }

    public void setUniform(boolean b) {
        this.selectedLaw.setUniform(b);
    }

    public void setInverse(boolean b) {
        this.selectedLaw.setInverse(b);
    }

    // changes the transparency rate
    private void setTransparency(double value) {
        this.transparency = value;
        this.updateResult();
    }

    // changes the transparency type
    public void setType(double value) {
        this.type = value;

        this.removalSlider.setVisible(!selectedLaw.isUniform() && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);
        this.impossibleRemoval.setVisible(!selectedLaw.isUniform() && (type == Double.POSITIVE_INFINITY || type == Double.NEGATIVE_INFINITY));
        this.switchButton.setVisible(!selectedLaw.isUniform() && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);
        this.expectedButton.setVisible(!selectedLaw.isUniform() && type != Double.POSITIVE_INFINITY && type != Double.NEGATIVE_INFINITY);

        this.informationLawLabel.setText("<html><center>Selected function<br/>" + this.selectedLaw.getFunction(this.type) + "</center></html>");
        if (this.type == Double.POSITIVE_INFINITY) {
            this.informationMeanLabel.setText("Maximum value");
            this.informationTransparencyLabel.setText("");
        } else if (this.type == 2) {
            if (this.selectedLaw instanceof QEqualsZero) {
                this.informationMeanLabel.setText("Quadratic mean");
            } else {
                this.informationMeanLabel.setText("");
            }
            this.informationTransparencyLabel.setText("");
        } else if (this.type == 1) {
            if (this.selectedLaw instanceof QEqualsZero) {
                this.informationMeanLabel.setText("Arithmetic mean");
                this.informationTransparencyLabel.setText("Additive transparency");
                this.informationTransparencyLabel.setLocation(38, 35);
            } else {
                this.informationMeanLabel.setText("");
                this.informationTransparencyLabel.setText("");
            }
        } else if (this.type == 0) {
            if (this.selectedLaw instanceof QEqualsZero || (this.selectedLaw instanceof Zero && ((Zero) this.selectedLaw).getLaw() == 0)) {
                this.informationMeanLabel.setText("Geometric mean");
                this.informationTransparencyLabel.setText("Subtractive transparency");
                this.informationTransparencyLabel.setLocation(28, 35);
            } else {
                this.informationMeanLabel.setText("");
                this.informationTransparencyLabel.setText("");
            }
        } else if (this.type == -1) {
            if (this.selectedLaw instanceof QEqualsZero) {
                this.informationMeanLabel.setText("Harmonic mean");
                this.informationTransparencyLabel.setText("");
            } else if (this.selectedLaw instanceof PEqualsQ) {
                this.informationMeanLabel.setText("<html><center>Equivalent to<br/>harmonic mean</center></html>");
                this.informationTransparencyLabel.setText("");
            } else if (this.selectedLaw instanceof PEqualsZero) {
                this.informationMeanLabel.setText("<html><center>Equivalent to<br/>arithmetic mean</center></html>");
                this.informationTransparencyLabel.setText("");
            } else if (this.selectedLaw instanceof QEquals2P) {
                this.informationTransparencyLabel.setText("Kubelka-Munk function");
                this.informationTransparencyLabel.setLocation(34, 35);
                this.informationMeanLabel.setText("");
            } else {
                this.informationMeanLabel.setText("");
                this.informationTransparencyLabel.setText("");
            }
        } else if (this.type == Double.NEGATIVE_INFINITY) {
            this.informationMeanLabel.setText("Minimum value");
            this.informationTransparencyLabel.setText("");
        } else {
            this.informationMeanLabel.setText("");
            this.informationTransparencyLabel.setText("");
        }
        this.updateResult();
    }

    // changes the removal
    private void setRemoval(double value) {
        this.removal = value;
        this.updateResult();
    }

    // shows the color dialog of one of the sources
    private void showColorSourceDialog(SourcePos pos) {
        ColorDialog dialog;
        Source source;
        if (pos == SourcePos.BACK) {
            dialog = this.backColorDialog;
            source = this.backSource;
        } else {
            dialog = this.frontColorDialog;
            source = this.frontSource;
        }

        if (pos == SourcePos.BACK) {
            this.oldBackSource = source;
        } else {
            this.oldFrontSource = source;
        }

        Point p = this.frame.getLocation();
        p.x += 205 - dialog.getWidth();
        p.y += 455;
        if (pos == SourcePos.BACK) {
            p.y -= dialog.getHeight();
        }

        dialog.show(p);
    }

    // opens the dialog to load an image as a source
    private String openLoadDialog() {
        JFileChooser chooser = new JFileChooser(".");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images JPEG", "jpg");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(this.frame);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile().getAbsolutePath();
        } else {
            return null;
        }
    }

    // opens the dialog to save an image
    private void openSaveDialog() {
        JFileChooser chooser = new JFileChooser() {
            public void approveSelection() {
                String filename = getSelectedFile().getAbsolutePath();
                if (filename.lastIndexOf(".jpg") == -1) {
                    filename += ".jpg";
                }
                File file = new File(filename);
                if (file.exists()) {
                    int result = JOptionPane.showConfirmDialog(this, "This file already exists. Overwrite?",
                            "Overwrite file", JOptionPane.YES_NO_OPTION);
                    if (result == JOptionPane.YES_OPTION) {
                        super.approveSelection();
                    }
                } else {
                    super.approveSelection();
                }
            }
        };

        chooser.setCurrentDirectory(new File(saveDirectory));

        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images JPEG", "jpg");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showSaveDialog(this.frame);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            String filename = chooser.getSelectedFile().getAbsolutePath();
            if (filename.lastIndexOf(".jpg") == -1) {
                filename += ".jpg";
            }
            saveResult(filename);
        }
    }

    // loads the Settings dialog
    private void loadSettings() {
        // window color dialog
        Color windowColor = frame.getContentPane().getBackground();
        final ColorDialog windowColorDialog = new ColorDialog(this.frame, "Select Window Color", windowColor);
        windowColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                frame.getContentPane().setBackground(color);
                sideFrame.getContentPane().setBackground(color);
            }
        }
        );

        // "Select Window Color" label + button
        JLabel backgroundLabel = new JLabel("Select Window Color");
        JButton backgroundButton = new JButton("Select Color...");
        backgroundButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.show();
            }
        }
        );
        Box backgroundBox = Box.createHorizontalBox();
        backgroundBox.add(backgroundLabel);
        backgroundBox.add(Box.createHorizontalGlue());
        backgroundBox.add(backgroundButton);
        backgroundBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Maximum Display Size" stuff
        JLabel maximumDisplayLabel = new JLabel("Maximum Display Size: ");
        button360 = new JRadioButton("1:1 (360/360)", defaultWidth == 360);
        button480 = new JRadioButton("4:3 (480/360)", defaultWidth == 480);
        button640 = new JRadioButton("16:9 (640/360)", defaultWidth == 640);
        button360.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(360);
            }
        });
        button480.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(480);
            }
        });
        button640.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(640);
            }
        });
        ButtonGroup grp = new ButtonGroup();
        grp.add(button360);
        grp.add(button480);
        grp.add(button640);
        Box maximumDisplayBox = Box.createVerticalBox();
        maximumDisplayBox.add(maximumDisplayLabel);
        maximumDisplayBox.add(button360);
        maximumDisplayBox.add(button480);
        maximumDisplayBox.add(button640);

        // "Show Selections Borders" checkbox
        bordersCheckbox = new JCheckBox("Show Selections Borders", bordersEnabled);
        bordersCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                boolean enabled = bordersCheckbox.isSelected();
                bordersEnabled = enabled;
                dualBoard.enableBorder(enabled);
                updateResult();
            }
        }
        );

        // "Highlight Invalid Pixels" checkbox
        highlightCheckbox = new JCheckBox("Highlight Invalid Pixels", this.highlightInvalidPixels);
        highlightCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                highlightInvalidPixels = highlightCheckbox.isSelected();
                updateResult();
            }
        }
        );

        // invalid pixels color dialog
        final ColorDialog invalidColorDialog = new ColorDialog(this.frame, "Select Invalid Pixels Color", this.invalidColor);
        invalidColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                invalidColor = color;
                updateResult();
            }
        }
        );

        // "Select color..." button
        JButton invalidColorButton = new JButton("Select Color...");
        invalidColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                invalidColorDialog.show();
            }
        }
        );
        Box highlightBox = Box.createHorizontalBox();
        highlightBox.add(highlightCheckbox);
        highlightBox.add(Box.createHorizontalGlue());
        highlightBox.add(invalidColorButton);
        highlightBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Highlight Invalid Pixels" extension label
        JLabel highlightLabel = new JLabel("(Uniform Inverse Transparency Only)");
        Box highlightLabelBox = Box.createHorizontalBox();
        highlightLabelBox.add(Box.createRigidArea(new Dimension(22, 0)));
        highlightLabelBox.add(highlightLabel);

        //Default Save Directory
        JLabel defaultSaveLabel = new JLabel("Default save directory ");
        JButton defaultSaveButton = new JButton("Select Directory...");
        defaultSaveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File(saveDirectory));
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnVal = chooser.showSaveDialog(SwingUtilities.getWindowAncestor((JButton) e.getSource()));
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    saveDirectory = chooser.getSelectedFile().getAbsolutePath();
                }
            }
        }
        );
        Box defaultSaveBox = Box.createHorizontalBox();
        defaultSaveBox.add(defaultSaveLabel);
        defaultSaveBox.add(Box.createHorizontalGlue());
        defaultSaveBox.add(defaultSaveButton);
        defaultSaveBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Save Information File (.txt)" checkbox
        infoFileCheckbox = new JCheckBox("Save Information File (.txt)", this.enableInfoFile);
        infoFileCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                enableInfoFile = infoFileCheckbox.isSelected();
            }
        }
        );

        // boxes
        Box windowBox = Box.createVerticalBox();
        windowBox.setBorder(BorderFactory.createTitledBorder("Window Settings"));
        windowBox.add(backgroundBox);
        windowBox.add(Box.createRigidArea(new Dimension(0, 10)));
        windowBox.add(Utility.padComponentLeft(maximumDisplayBox));

        Box imageBox = Box.createVerticalBox();
        imageBox.setBorder(BorderFactory.createTitledBorder("Image Settings"));
        imageBox.add(Utility.padComponentLeft(bordersCheckbox));
        imageBox.add(highlightBox);
        imageBox.add(Utility.padComponentLeft(highlightLabelBox));

        Box saveBox = Box.createVerticalBox();
        saveBox.setBorder(BorderFactory.createTitledBorder("Save Settings"));
        saveBox.add(Utility.padComponentLeft(defaultSaveBox));
        saveBox.add(Utility.padComponentLeft(infoFileCheckbox));

        Box mainBox = Box.createVerticalBox();
        mainBox.add(windowBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(imageBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(saveBox);

        // ok button
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
                settingsDialog.setVisible(false);
                //save settings here
                BufferedWriter bw;
                try {
                    bw = new BufferedWriter(new FileWriter("transparency_settings.properties"));
                    bw.write("borders enabled :\n");
                    bw.write(Boolean.toString(bordersEnabled));
                    bw.write("\n");
                    bw.write("Save info file enabled :\n");
                    bw.write(Boolean.toString(enableInfoFile));
                    bw.write("\n");
                    bw.write("Highlighting invalid pixels enabled :\n");
                    bw.write(Boolean.toString(highlightInvalidPixels));
                    bw.write("\n");
                    bw.write("Default save directory :\n");
                    bw.write(saveDirectory);
                    bw.write("\n");
                    bw.write("Window size :\n");
                    if (button360.isSelected()) {
                        bw.write(Integer.toString(360));
                    } else if (button480.isSelected()) {
                        bw.write(Integer.toString(480));
                    } else if (button640.isSelected()) {
                        bw.write(Integer.toString(640));
                    }
                    bw.close();
                } catch (Exception ex) {
                }
            }
        }
        );

        ComponentListener dialogListener = new ComponentAdapter() {
            public void componentHidden(ComponentEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
            }
        };

        Box okBox = Box.createVerticalBox();
        okBox.add(Box.createRigidArea(new Dimension(0, 5)));
        okBox.add(okButton);
        okBox.add(Box.createRigidArea(new Dimension(0, 10)));

        // create dialog
        this.settingsDialog = new JDialog(this.frame, "Settings", false);
        this.settingsDialog.addComponentListener(dialogListener);
        this.settingsDialog.add(mainBox, BorderLayout.CENTER);
        this.settingsDialog.add(Utility.padComponentH(okBox), BorderLayout.SOUTH);
        this.settingsDialog.setPreferredSize(new Dimension(300, 415));
        this.settingsDialog.pack();
        this.settingsDialog.setResizable(false);
        this.settingsDialog.setLocationRelativeTo(null);
    }

    // loads the User Manual dialog
    private void loadManual() {
        JEditorPane editorPane = null;
        try {
            editorPane = new JEditorPane(this.getClass().getResource(MANUAL_FILENAME));
        } catch (IOException e) {
            System.out.println("Couldn't open manual file");
            return;
        }

        editorPane.addHyperlinkListener(new HyperlinkListener() {
            public void hyperlinkUpdate(HyperlinkEvent e) {
                if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                    Utility.launchUrl(e.getURL());
                }
            }
        }
        );

        editorPane.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(editorPane);

        this.manualDialog = new JDialog(this.frame, "User Manual", false);
        this.manualDialog.add(scrollPane);
        this.manualDialog.setPreferredSize(new Dimension(800, 600));
        this.manualDialog.pack();
        this.manualDialog.setLocationRelativeTo(null);
    }

    // loads the menus
    private JMenuBar makeMenu() {
        // create transparency law popup menu
        this.transparencyLawMenu = new JPopupMenu();
        JMenuItem popupDirectTransparency = new JMenuItem("Direct Transparency");
        popupDirectTransparency.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, false, true);
                for (TransparencyLaw l : laws) {
                    l.setInverse(false);
                    l.setUniform(true);
                }
            }
        });
        this.transparencyLawMenu.add(popupDirectTransparency);
        JMenu popupMenuInverseTransparency = new JMenu("Inverse Transparency");
        this.transparencyLawMenu.add(popupMenuInverseTransparency);

        // menu "Program selection"
        //JMenu menuApp = new JMenu("Program selection");
        menuApp = new JMenu("Transparency as generalized f-mean");
        JMenuItem firstApp = menuApp.add("From subtractive to additive transparency");
        firstApp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (application.firstApp == null) {
                    application.firstApp = new FirstApplication(application);
                } else {
                    application.firstApp.setVisible(true);
                }
                application.firstApp.update(frame.getX(), frame.getY(), width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, resultPanel);
                application.firstApp.updateSettings(settingsDialog);
                setVisible(false);
                application.firstApp.setBack(backSource);
                application.firstApp.setFront(frontSource);
            }
        }
        );

        JMenuItem secondApp = menuApp.add("Transparency as generalized f-mean");
        /*secondApp.setBackground(Color.GRAY);
        secondApp.setOpaque(true);*/
        secondApp.setEnabled(false);
        menuApp.add(secondApp);

        JMenuItem thirdApp = menuApp.add("Translucency by a scattering layer");
        thirdApp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (application.thirdApp == null) {
                    application.thirdApp = new ThirdApplication(application);
                } else {
                    application.thirdApp.setVisible(true);
                }
                application.thirdApp.update(frame.getX(), frame.getY(), width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, resultPanel);
                application.thirdApp.updateSettings(settingsDialog);
                setVisible(false);
                application.thirdApp.setBack(backSource);
                application.thirdApp.setFront(frontSource);
            }
        }
        );

        // menu "Operation Steps"
        menuSteps = new JMenu("Operation Steps");

        // menu "Select Background"
        JMenu menuBack = new JMenu("Select Background");
        menuSteps.add(menuBack);

        // menu "Select Foreground"
        JMenu menuFront = new JMenu("Select Foreground");
        menuSteps.add(menuFront);

        // item "Select Color"
        JMenuItem itemBackColor = menuBack.add("Select Color");
        itemBackColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                showColorSourceDialog(SourcePos.BACK);
            }
        }
        );

        // item "Select Image"
        JMenuItem itemBackImage = menuBack.add("Select Image");
        itemBackImage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String filename = openLoadDialog();
                if (filename != null) {
                    setSource(SourcePos.BACK, ImageSource.load(filename));
                }
            }
        }
        );

        // item "Select Color"
        JMenuItem itemFrontColor = menuFront.add("Select Color");
        itemFrontColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                showColorSourceDialog(SourcePos.FRONT);
            }
        }
        );

        // item "Select Image"
        JMenuItem itemFrontImage = menuFront.add("Select Image");
        itemFrontImage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String filename = openLoadDialog();
                if (filename != null) {
                    setSource(SourcePos.FRONT, ImageSource.load(filename));
                }
            }
        }
        );

        // menu "Transparency Mode"
        JMenu menuTransparencyLaw = new JMenu("Transparency Mode");
        menuSteps.add(menuTransparencyLaw);

        // menu "Direct Transparency"
        JMenuItem menuDirectTransparency = new JMenuItem("Direct Transparency");
        menuDirectTransparency.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, false, true);
                for (TransparencyLaw l : laws) {
                    l.setInverse(false);
                    l.setUniform(true);
                }
            }
        });
        menuTransparencyLaw.add(menuDirectTransparency);
        // menu "Inverse Transparency"
        JMenu menuInverseTransparency = new JMenu("Inverse Transparency");
        menuTransparencyLaw.add(menuInverseTransparency);

        JMenuItem menuInverseUniform = menuInverseTransparency.add("Uniform");
        menuInverseUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, true, true);
                for (TransparencyLaw l : laws) {
                    l.setInverse(true);
                    l.setUniform(true);
                }
            }
        });

        JMenuItem menuInverseNonUniform = menuInverseTransparency.add("Non Uniform");
        menuInverseNonUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, true, false);
                for (TransparencyLaw l : laws) {
                    l.setInverse(true);
                    l.setUniform(false);
                }
            }
        });

        JMenuItem popupInverseUniform = popupMenuInverseTransparency.add("Uniform");
        popupInverseUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, true, true);
                for (TransparencyLaw l : laws) {
                    l.setInverse(true);
                    l.setUniform(true);
                }
            }
        });

        JMenuItem popupInverseNonUniform = popupMenuInverseTransparency.add("Non Uniform");
        popupInverseNonUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                setLaw(selectedLaw, true, false);
                for (TransparencyLaw l : laws) {
                    l.setInverse(true);
                    l.setUniform(false);
                }
            }
        });

        // item "Save Modified Image"
        JMenuItem itemSave = menuSteps.add("Save Modified Image");
        itemSave.setAccelerator(KeyStroke.getKeyStroke("control S"));
        itemSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openSaveDialog();
            }
        }
        );

        // item "Quit"
        JMenuItem itemQuit = menuSteps.add("Quit");
        itemQuit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
        itemQuit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }
        );

        // menu "Help"
        menuHelp = new JMenu("Help");

        // item "Settings"
        JMenuItem itemSettings = menuHelp.add("Settings");
        itemSettings.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                settingsDialog.setVisible(true);
            }
        }
        );

        // item "User Manual"
        JMenuItem itemUserManual = menuHelp.add("User Manual");
        itemUserManual.setAccelerator(KeyStroke.getKeyStroke("F1"));
        itemUserManual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (manualDialog != null) {
                    manualDialog.setVisible(true);
                }
            }
        }
        );

        // item "About"
        JMenuItem itemAbout = menuHelp.add("About");
        itemAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String line1 = "Interactive RGB Transparency is a Java software developed by Lionel Simonot, Mathieu Hébert, Andy Poudret and Florian Nadaud (2016)";
                String line2 = "<a href='" + WEBSITE_URL + "'>" + WEBSITE_URL + "</a>";
                String line3 = "Photograph of Notre-Dame-La-Grande in Poitiers by Florent Carmelet-Rescan";
                String text = line1 + "<br/>" + line2 + "<br/>" + line3;
                JEditorPane pane = new JEditorPane("text/html", text);
                pane.setEditable(false);
                pane.setBackground(new JLabel().getBackground());
                pane.addHyperlinkListener(new HyperlinkListener() {
                    public void hyperlinkUpdate(HyperlinkEvent e) {
                        if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                            Utility.launchUrl(e.getURL());
                        }
                    }
                }
                );
                JOptionPane.showMessageDialog(frame, pane, "About", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        );

        // create menu
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(menuApp);
        menuBar.add(menuSteps);
        menuBar.add(menuHelp);
        return menuBar;
    }

    // creates the top left / bottom left box
    private Box makeSourceBox(final SourcePos pos) {
        JLabel label = new JLabel(pos.getName());
        label.setFont(new Font(label.getFont().getName(), label.getFont().getStyle(), 14));

        ActionListener colorCancelListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (pos == SourcePos.BACK) {
                    setSource(pos, oldBackSource);
                } else {
                    setSource(pos, oldFrontSource);
                }
            }
        };

        String dialogTitle = String.format("Select %s Color", pos.getName());
        Color initialColor = (pos == SourcePos.BACK ? DEFAULT_BACK_COLOR : DEFAULT_FRONT_COLOR);
        ColorDialog colorDialog = new ColorDialog(this.frame, dialogTitle, initialColor, colorCancelListener);
        colorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                Dimension sourceSize = null;
                if (pos == SourcePos.BACK && !selectedLaw.isInverse() && !selectedLaw.isUniform() && backSource != null) {
                    sourceSize = backSource.getSourceSize();
                }
                setSource(pos, new ColorSource(color, sourceSize));
            }
        }
        );

        JButton selectColorButton = new JButton("Select Color");
        selectColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showColorSourceDialog(pos);
            }
        }
        );

        JButton selectImageButton = new JButton("Select Image");
        selectImageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String filename = openLoadDialog();
                if (filename != null) {
                    setSource(pos, ImageSource.load(filename));
                }
            }
        }
        );

        Box sourceBox = Box.createVerticalBox();

        Box mainBox = Box.createVerticalBox();
        mainBox.setPreferredSize(new Dimension(200, 250));
        mainBox.setMinimumSize(new Dimension(200, 250));
        mainBox.setMaximumSize(new Dimension(200, 1000));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(label));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(selectColorButton));
        mainBox.add(Box.createRigidArea(new Dimension(0, 5)));
        mainBox.add(Utility.padComponentH(selectImageButton));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(sourceBox));
        mainBox.add(Box.createVerticalGlue());

        TransferHandler handler = new TransferHandler() {
            public boolean canImport(TransferSupport support) {
                return support.isDataFlavorSupported(DataFlavor.javaFileListFlavor);
            }

            public boolean importData(TransferSupport support) {
                if (!canImport(support)) {
                    return false;
                }

                Transferable t = support.getTransferable();

                File f = null;
                try {
                    java.util.List<File> l = (java.util.List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
                    f = l.get(l.size() - 1);
                } catch (UnsupportedFlavorException e) {
                    return false;
                } catch (IOException e) {
                    return false;
                }

                if (f != null) {
                    setSource(pos, ImageSource.load(f.getAbsolutePath()));
                }

                return true;
            }
        };
        MultipleTransferHandler multipleHandler = new MultipleTransferHandler();
        multipleHandler.addTransferHandler(handler);
        mainBox.setTransferHandler(multipleHandler);

        if (pos == SourcePos.BACK) {
            this.backBox = sourceBox;
            this.backColorDialog = colorDialog;
        } else {
            this.frontBox = sourceBox;
            this.frontColorDialog = colorDialog;
        }

        return mainBox;
    }

    public SecondApplication(Menu app) throws IOException {
        application = app;
        // initialization
        this.updatesEnabled = false;
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader("transparency_settings.properties"));
            br.readLine();
            this.bordersEnabled = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.enableInfoFile = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.highlightInvalidPixels = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.saveDirectory = br.readLine();
            br.readLine();
            this.defaultWidth = Integer.parseInt(br.readLine());
            br.close();
        } catch (FileNotFoundException e) {
            this.bordersEnabled = true;
            this.enableInfoFile = true;
            this.highlightInvalidPixels = true;
            this.saveDirectory = ".";
            this.defaultWidth = 480;
        } catch (Exception e) {
        }
        this.invalidColor = DEFAULT_INVALID_COLOR;

        this.laws = new ArrayList<TransparencyLaw>();
        this.laws.add(TransparencyLaws.Q_EQUALS_ZERO);
        this.laws.add(TransparencyLaws.P_EQUALS_ZERO);
        this.laws.add(TransparencyLaws.P_EQUALS_Q);
        this.laws.add(TransparencyLaws.P_EQUALS_2Q);
        this.laws.add(TransparencyLaws.Q_EQUALS_2P);
        this.laws.add(TransparencyLaws.ZERO);

        // frame
        this.frame = new JFrame("Interactive RGB Transparency");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setBackground(new Color(0, 0, 0));
        this.frame.setJMenuBar(this.makeMenu());

        // dialogs
        this.loadSettings();
        this.loadManual();

        // back panel (top left)
        Box topLeftBox = this.makeSourceBox(SourcePos.BACK);

        this.progressBar = new JProgressBar(SwingConstants.HORIZONTAL, 0, 100);
        this.progressBar.setValue(100);

        JPanel progressBarPanel = new JPanel();
        progressBarPanel.setPreferredSize(new Dimension(200, 20));
        progressBarPanel.setMaximumSize(new Dimension(200, 20));
        progressBarPanel.add(this.progressBar);

        topLeftBox.add(Utility.padComponentH(progressBarPanel));
        topLeftBox.add(Box.createRigidArea(new Dimension(0, 10)));

        // front panel (bottom left)
        Box botLeftBox = this.makeSourceBox(SourcePos.FRONT);

        // result panel and selected law label (top right)
        JLabel pixelInfoLabel = new JLabel(" ");
        ActionListener expectedBackListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = "Select Expected Background Color";
                String infoText = "Apply Inverse Transparency With The Suggested Background Color";
                ColorListener colorListener = new ColorListener() {
                    public void colorChanged(Color color) {
                        opaqueSelectionColor = color;
                        updateResult();
                    }
                };
                Point p = frame.getLocation();
                p.x += 205;
                p.y += 455;
                Color color = ColorDialog.createModalDialog(frame, title, infoText, DEFAULT_BACK_COLOR, p, colorListener);
                opaqueSelectionColor = null;
                if (color != null) {
                    Color frontColor = computeSuggestedForeground(color);
                    setFront(new ColorSource(frontColor));
                } else {
                    updateResult();
                }
            }
        };
        this.resultPanel = new ImagePanel(new Dimension(defaultWidth, 360), pixelInfoLabel, expectedBackListener);
        this.resultPanel.addActionListener(this);
        this.width = defaultWidth;
        this.resultContainer = new JPanel(new GridBagLayout());
        this.resultContainer.setPreferredSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.setMinimumSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.setMaximumSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.add(this.resultPanel);

        Box resultBox = Box.createVerticalBox();
        resultBox.add(Box.createVerticalGlue());
        resultBox.add(this.resultContainer);
        resultBox.add(Utility.padComponentH(pixelInfoLabel));
        resultBox.add(Box.createRigidArea(new Dimension(0, 10)));
        resultBox.add(Box.createVerticalGlue());

        // drag & drop: result -> back
        TransferHandler srcHandler = new TransferHandler() {
            @Override
            protected Transferable createTransferable(JComponent c) {
                return new StringSelection("result");
            }

            @Override
            public int getSourceActions(JComponent c) {
                return COPY;
            }
        };
        TransferHandler destHandler = new TransferHandler() {
            @Override
            public boolean canImport(TransferSupport support) {
                if (!support.isDrop()) {
                    return false;
                }
                Object data = null;
                try {
                    data = support.getTransferable().getTransferData(DataFlavor.stringFlavor);
                } catch (Exception e) {
                    return false;
                }
                if (!(data instanceof String)) {
                    return false;
                }
                String str = (String) data;
                return "result".equals(str);
            }

            @Override
            public boolean importData(TransferSupport support) {
                if (this.canImport(support)) {
                    loadResultAsBack();
                    return true;
                } else {
                    return false;
                }
            }
        };
        resultBox.setTransferHandler(srcHandler);
        MultipleTransferHandler multipleHandler = (MultipleTransferHandler) topLeftBox.getTransferHandler();
        multipleHandler.addTransferHandler(destHandler);
        resultBox.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                JComponent lab = (JComponent) e.getSource();
                TransferHandler handle = lab.getTransferHandler();
                handle.exportAsDrag(lab, e, TransferHandler.COPY);
            }
        }
        );

        this.impossibleRemoval = new JLabel("Impossible Removal");
        this.impossibleRemoval.setFont(new Font(this.impossibleRemoval.getFont().getFontName(), Font.BOLD, 18));

        // dual board and sliders (bottom right)
        this.selectedLawButton = new JButton();
        this.selectedLawButton.setFont(new Font(this.selectedLawButton.getFont().getName(), this.selectedLawButton.getFont().getStyle(), 13));
        this.selectedLawButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent event) {
                transparencyLawMenu.show(event.getComponent(), event.getX(), event.getY());
            }
        }
        );

        this.dualBoard = new DualBoard(new Dimension(200, 100));

        this.switchButton = new JButton();
        this.switchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final JDialog choiceDialog;

                JLabel infoLabel;
                JLabel helpLabel;
                sideDisabledPanel.setEnabled(false);
                
                if (selectedLaw.isInverse()) {
                    choiceDialog = new JDialog(frame, "Visualize Removal Part", true);
                    infoLabel = new JLabel("Select the new background on which the removal part will be visualized:");
                    helpLabel = new JLabel("Selections and transparency laws cannot be changed in this mode.");
                } else {
                    choiceDialog = new JDialog(frame, "Back To Inverse Transparency", true);
                    infoLabel = new JLabel("Select the new background:");
                    helpLabel = new JLabel("");
                }
                choiceDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

                String resultRadioText = selectedLaw.isInverse() ? "Result Image" : "Initial Background";
                final JRadioButton resultRadio = new JRadioButton(resultRadioText, true);
                final JRadioButton colorRadio = new JRadioButton("New Color", false);
                final JRadioButton imageRadio = new JRadioButton("New Image", false);
                ButtonGroup grp = new ButtonGroup();
                grp.add(resultRadio);
                grp.add(colorRadio);
                grp.add(imageRadio);

                JButton okButton = new JButton("OK");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        for (TransparencyLaw l : laws) {
                            l.setInverse(!l.isInverse());
                        }
                        if (!selectedLaw.isInverse()) {
                            computeRemoval();
                            tempBackSource = backSource;
                            sideDisabledPanel.setEnabled(false);
                        } else {
                            sideDisabledPanel.setEnabled(true);
                        }
                        selectedLaw.setInverse(!selectedLaw.isInverse());
                        Source newSource = null;
                        if (colorRadio.isSelected()) {
                            Color color = ColorDialog.createModalDialog(choiceDialog, "Select New Background Color", null, DEFAULT_BACK_COLOR);
                            if (color != null) {
                                Dimension sourceSize = null;
                                if (backSource != null) {
                                    sourceSize = backSource.getSourceSize();
                                }
                                newSource = new ColorSource(color, sourceSize);
                            }
                        } else if (imageRadio.isSelected()) {
                            String filename = openLoadDialog();
                            if (filename != null) {
                                newSource = ImageSource.load(filename);
                            }
                        } else if (selectedLaw.isInverse()) {
                            newSource = getResultAsSource();
                        } else {
                            newSource = tempBackSource;
                        }

                        selectedLaw.setInverse(!selectedLaw.isInverse());
                        if (newSource != null && checkBackSize(newSource)) {
                            choiceDialog.setVisible(false);
                            setLaw(selectedLaw, selectedLaw.isInverse(), selectedLaw.isUniform());
                            setSource(SourcePos.BACK, newSource);
                        }
                    }
                }
                );

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        choiceDialog.setVisible(false);
                        sideDisabledPanel.setEnabled(true);
                    }
                }
                );

                Box c1Box = Box.createHorizontalBox();
                c1Box.add(Box.createRigidArea(new Dimension(5, 0)));
                c1Box.add(Box.createHorizontalGlue());
                c1Box.add(infoLabel);
                c1Box.add(Box.createHorizontalGlue());
                c1Box.add(Box.createRigidArea(new Dimension(5, 0)));

                Box c3Box = Box.createHorizontalBox();
                c3Box.add(Box.createRigidArea(new Dimension(5, 0)));
                c3Box.add(Box.createHorizontalGlue());
                c3Box.add(helpLabel);
                c3Box.add(Box.createHorizontalGlue());
                c3Box.add(Box.createRigidArea(new Dimension(5, 0)));

                Box radioBox = Box.createVerticalBox();
                radioBox.add(resultRadio);
                radioBox.add(colorRadio);
                radioBox.add(imageRadio);

                Box c2Box = Box.createHorizontalBox();
                c2Box.add(Box.createHorizontalGlue());
                c2Box.add(radioBox);
                c2Box.add(Box.createHorizontalGlue());

                Box buttonsBox = Box.createHorizontalBox();
                buttonsBox.add(Box.createHorizontalGlue());
                buttonsBox.add(okButton);
                buttonsBox.add(Box.createRigidArea(new Dimension(10, 0)));
                buttonsBox.add(cancelButton);
                buttonsBox.add(Box.createHorizontalGlue());

                Box choiceBox = Box.createVerticalBox();
                choiceBox.add(c1Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));
                choiceBox.add(c2Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));
                choiceBox.add(c3Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 20)));
                choiceBox.add(buttonsBox);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));

                choiceDialog.add(choiceBox);

                Dimension dimDialog = new Dimension(430, 206);
                choiceDialog.setMaximumSize(dimDialog);
                choiceDialog.setMinimumSize(dimDialog);
                choiceDialog.setPreferredSize(dimDialog);
                choiceDialog.pack();
                choiceDialog.setResizable(false);
                choiceDialog.setLocationRelativeTo(null);
                choiceDialog.setVisible(true);
            }
        }
        );

        this.expectedButton = new JButton("<html><center>Select Expected Background</center></html>");
        this.expectedButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                topDisabledPanel.setEnabled(false);
                botDisabledPanel.setEnabled(false);
                menuSteps.setEnabled(false);
                menuHelp.setEnabled(false);
                menuApp.setEnabled(false);
                resultPanel.resetCurrentSelection();
                resultPanel.setSelectionsLocked(true);
                resultPanel.setExpectedMode(true);
                resultPanel.repaint();

                final JFrame choiceDialog = new JFrame("Expected Background");

                final JLabel infoLabel = new JLabel("<html><center>First create selection(s), then choose a target color.<br/>"
                        + "A new foreground color will be computed.</center></html>");

                JButton okButton = new JButton("OK");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        if (resultPanel.getExpSelections().size() != 0) {
                            choiceDialog.setVisible(false);
                            topDisabledPanel.setEnabled(true);
                            botDisabledPanel.setEnabled(true);
                            menuSteps.setEnabled(true);
                            menuHelp.setEnabled(true);
                            menuApp.setEnabled(true);
                            String title = "Select Expected Background Color";
                            String infoText = "Apply Inverse Transparency With The Suggested Background Color";
                            ColorListener colorListener = new ColorListener() {
                                public void colorChanged(Color color) {
                                    opaqueSelectionColor = color;
                                    updateResult();
                                }
                            };
                            Point p = frame.getLocation();
                            p.x += 205;
                            p.y += 455;
                            Color color = ColorDialog.createModalDialog(frame, title, infoText, DEFAULT_BACK_COLOR, p, colorListener);
                            opaqueSelectionColor = null;
                            if (color != null) {
                                Color frontColor = computeSuggestedForeground(color);
                                resultPanel.mixSelections();
                                resultPanel.setSelectionsLocked(false);
                                resultPanel.setExpectedMode(false);
                                setFront(new ColorSource(frontColor));
                            } else {
                                resultPanel.clearExpSelections();
                                resultPanel.setSelectionsLocked(false);
                                resultPanel.setExpectedMode(false);
                                updateResult();
                            }
                        } else {
                            choiceDialog.setVisible(false);
                            try {
                                Thread.sleep(250);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(SecondApplication.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            choiceDialog.setVisible(true);
                        }
                    }
                });

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        choiceDialog.setVisible(false);
                        topDisabledPanel.setEnabled(true);
                        botDisabledPanel.setEnabled(true);
                        menuSteps.setEnabled(true);
                        menuHelp.setEnabled(true);
                        menuApp.setEnabled(true);
                        resultPanel.setSelectionsLocked(false);
                        resultPanel.clearExpSelections();
                        resultPanel.setExpectedMode(false);
                        updateResult();
                    }
                }
                );

                Box labelBox = Box.createHorizontalBox();
                labelBox.add(Box.createHorizontalGlue());
                labelBox.add(Box.createRigidArea(new Dimension(5, 0)));
                labelBox.add(infoLabel);
                labelBox.add(Box.createRigidArea(new Dimension(5, 0)));
                labelBox.add(Box.createHorizontalGlue());

                Box buttonBox = Box.createHorizontalBox();
                buttonBox.add(Box.createHorizontalGlue());
                buttonBox.add(okButton);
                buttonBox.add(Box.createRigidArea(new Dimension(10, 0)));
                buttonBox.add(cancelButton);
                buttonBox.add(Box.createHorizontalGlue());

                Box choiceBox = Box.createVerticalBox();
                choiceBox.add(Box.createRigidArea(new Dimension(0, 5)));
                choiceBox.add(labelBox);
                choiceBox.add(Box.createVerticalGlue());
                choiceBox.add(buttonBox);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 5)));

                choiceDialog.add(choiceBox);
                choiceDialog.pack();
                choiceDialog.setResizable(false);
                //choiceDialog.setLocationRelativeTo(frame);
                choiceDialog.setLocation(frame.getX() + 210, frame.getY() + 470);
                choiceDialog.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                choiceDialog.setAlwaysOnTop(true);
                choiceDialog.setVisible(true);
            }
        }
        );

        JPanel dualBoardContainer = new JPanel();
        dualBoardContainer.setLayout(new BoxLayout(dualBoardContainer, BoxLayout.PAGE_AXIS));
        dualBoardContainer.setPreferredSize(new Dimension(320, 100));
        dualBoardContainer.setMinimumSize(new Dimension(320, 100));
        dualBoardContainer.setMaximumSize(new Dimension(320, 100));
        dualBoardContainer.add(dualBoard);

        Dimension sliderDimension = new Dimension(140, 60);

        switchButton.setPreferredSize(sliderDimension);
        switchButton.setMinimumSize(sliderDimension);
        switchButton.setMaximumSize(sliderDimension);

        expectedButton.setPreferredSize(sliderDimension);
        expectedButton.setMinimumSize(sliderDimension);
        expectedButton.setMaximumSize(sliderDimension);
        Box mBox = Box.createHorizontalBox();
        Box c1Box = Box.createVerticalBox();
        Box c2Box = Box.createVerticalBox();

        c1Box.add(Box.createVerticalGlue());
        c1Box.add(this.switchButton);
        c1Box.add(Box.createVerticalGlue());
        mBox.add(c1Box);
        mBox.add(Box.createRigidArea(new Dimension(20, 0)));
        c2Box.add(Box.createVerticalGlue());
        c2Box.add(this.expectedButton);
        c2Box.add(Box.createVerticalGlue());
        mBox.add(c2Box);
        dualBoardContainer.add(mBox);

        final JLabel transparencyValueLabel = new JLabel(String.format("%d%%", DEFAULT_TRANSPARENCY));
        transparencyValueLabel.setPreferredSize(new Dimension(50, transparencyValueLabel.getPreferredSize().height));
        transparencyValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.transparencySlider = new JSlider(JSlider.HORIZONTAL, 0, 100, DEFAULT_TRANSPARENCY);
        Hashtable transparencyLabels = new Hashtable();
        transparencyLabels.put(0, new JLabel("Opaque"));
        transparencyLabels.put(50, transparencyValueLabel);
        transparencyLabels.put(100, new JLabel("Transparent"));
        this.transparencySlider.setLabelTable(transparencyLabels);
        this.transparencySlider.setPaintLabels(true);
        this.transparencySlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int val = transparencySlider.getValue();
                transparencyValueLabel.setText(String.format("%d%%", val));
                transparencySlider.repaint();
                setTransparency(val / 100.0);
            }
        }
        );

        this.maxRemovalLabel = new JLabel(" ");
        this.maxRemovalLabel.setPreferredSize(new Dimension(100, this.maxRemovalLabel.getPreferredSize().height));
        this.maxRemovalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.noRemovalLabel = new JLabel(" ");
        this.noRemovalLabel.setPreferredSize(new Dimension(100, this.noRemovalLabel.getPreferredSize().height));
        this.noRemovalLabel.setHorizontalAlignment(SwingConstants.CENTER);

        final JLabel removalValueLabel = new JLabel(String.format("%d%%", DEFAULT_REMOVAL));
        removalValueLabel.setPreferredSize(new Dimension(50, removalValueLabel.getPreferredSize().height));
        removalValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.removalSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 100 - DEFAULT_REMOVAL);
        this.removalSlider.setVisible(false);
        Hashtable removalLabels = new Hashtable();
        removalLabels.put(0, this.maxRemovalLabel);
        removalLabels.put(50, removalValueLabel);
        removalLabels.put(100, this.noRemovalLabel);
        this.removalSlider.setLabelTable(removalLabels);
        this.removalSlider.setPaintLabels(true);
        this.removalSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int val = 100 - removalSlider.getValue();
                removalValueLabel.setText(String.format("%d%%", val));
                removalSlider.repaint();
                setRemoval(val / 100.0);
            }
        }
        );

        Box midBox = Box.createVerticalBox();
        midBox.add(dualBoardContainer);
        midBox.add(Box.createRigidArea(new Dimension(0, 20)));
        midBox.add(this.transparencySlider);
        midBox.add(this.removalSlider);
        Box cBox = Box.createHorizontalBox();
        cBox.add(Box.createHorizontalGlue());
        cBox.add(this.impossibleRemoval);
        cBox.add(Box.createHorizontalGlue());
        midBox.add(cBox);

        //Radio Button for parameters selection
        JRadioButton infinity = new JRadioButton("∞");
        JRadioButton two = new JRadioButton("2");
        JRadioButton one = new JRadioButton("1");
        JRadioButton half = new JRadioButton("0.5");
        JRadioButton zero = new JRadioButton("0");
        JRadioButton n_half = new JRadioButton("-0.5");
        JRadioButton n_one = new JRadioButton("-1");
        JRadioButton n_two = new JRadioButton("-2");
        JRadioButton n_infinity = new JRadioButton("-∞");

        infinity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(Double.POSITIVE_INFINITY);
            }
        });
        two.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(2);
            }
        });
        one.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(1);
            }
        });
        half.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(0.5);
            }
        });
        zero.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(0);
            }
        });
        n_half.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(-0.5);
            }
        });
        n_one.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(-1);
            }
        });
        n_two.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(-2);
            }
        });
        n_infinity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setType(Double.NEGATIVE_INFINITY);
            }
        });

        ButtonGroup p = new ButtonGroup();
        p.add(infinity);
        p.add(two);
        p.add(one);
        p.add(half);
        p.add(zero);
        p.add(n_half);
        p.add(n_one);
        p.add(n_two);
        p.add(n_infinity);

        JLabel parameterSelectionLabel = new JLabel("p  = ");

        Box parameterSelection = Box.createVerticalBox();
        parameterSelection.setBorder(BorderFactory.createLineBorder(Color.black));
        Box p_mid1 = Box.createHorizontalBox();
        p_mid1.add(Box.createHorizontalGlue());
        p_mid1.add(parameterSelectionLabel);
        p_mid1.add(Box.createHorizontalGlue());

        Box p_mid2 = Box.createHorizontalBox();
        Box p_left = Box.createVerticalBox();
        Box p_right = Box.createVerticalBox();
        p_mid2.add(p_left);
        p_mid2.add(Box.createRigidArea(new Dimension(5, 0)));
        p_mid2.add(p_right);

        Box p_mid3 = Box.createHorizontalBox();
        p_mid3.add(Box.createHorizontalGlue());
        p_mid3.add(zero);
        p_mid3.add(Box.createHorizontalGlue());

        parameterSelection.add(p_mid1);
        parameterSelection.add(Box.createRigidArea(new Dimension(0, 5)));
        parameterSelection.add(p_mid2);
        parameterSelection.add(p_mid3);

        p_left.add(infinity);
        p_left.add(two);
        p_left.add(one);
        p_left.add(half);
        p_right.add(n_infinity);
        p_right.add(n_two);
        p_right.add(n_one);
        p_right.add(n_half);

        int max = 200;
        int min = -max;
        int addit = max / 2;
        int harmo = -addit;
        int t = 3 * (max / 4);
        int n_t = -t;

        this.typeSlider = new JSlider(JSlider.VERTICAL, min, max, DEFAULT_TYPE);
        this.typeSlider.setMaximumSize(new Dimension(100, 175));
        Hashtable typeLabels = new Hashtable();
        typeLabels.put(addit, new JLabel("Additive"));
        typeLabels.put(harmo, new JLabel("Harmonic"));
        typeLabels.put(0, new JLabel("Subtractive"));
        typeLabels.put(max, new JLabel("Maximum"));
        typeLabels.put(min, new JLabel("Minimum"));
        this.typeSlider.setLabelTable(typeLabels);
        this.typeSlider.setPaintLabels(true);
        this.typeSlider.setMinorTickSpacing(25);
        this.typeSlider.setMajorTickSpacing(50);
        this.typeSlider.setPaintTicks(true);
        this.typeSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = (double) typeSlider.getValue();
                if (!selectedLaw.isInverse()) {
                    //between 1 and -1 :
                    if (val <= addit && val >= harmo) {
                        val = val / (addit);
                    } //between 1 and 2 :
                    else if (val > addit && val <= t) {
                        val = (val - addit) / (max / 4) + 1;
                    } //between -1 and -2 :
                    else if (val < harmo && val >= n_t) {
                        val = (val - harmo) / (max / 4) - 1;
                    } //between 2 and +∞ :
                    else if (val > t && val < max) {
                        val = (val - t) * 4;
                    } //between -2 and -∞ :
                    else if (val < n_t && val > min) {
                        val = (val - n_t) * 4;
                    } //+∞ :
                    else if (val == max) {
                        val = Double.POSITIVE_INFINITY;
                    } //-∞ :
                    else {
                        val = Double.NEGATIVE_INFINITY;
                    }
                    typeSpinner.setValue(val);
                } else {
                    val = val / 100;
                }
                setType(val);
            }
        }
        );

        SpinnerNumberModel model1 = new SpinnerNumberModel((double) 0, Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY, 0.01);
        typeSpinner = new JSpinner(model1);
        typeSpinner.setPreferredSize(new Dimension(70, 25));
        typeSpinner.setMaximumSize(new Dimension(70, 25));

        /*typeSpinner.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = (double) typeSpinner.getValue();
                if (val <= 1.0 && val >= -1.0) {
                    typeSlider.setValue((int) (val * addit));
                } else if (val > 1.0 && val <= 2.0) {
                    typeSlider.setValue((int) ((val - 1) * (max / 4) + addit));
                } else if (val < -1.0 && val >= -2.0) {
                    typeSlider.setValue((int) ((val + 1) * (max / 4) + harmo));
                } else if (val > 2.0 && val < Double.POSITIVE_INFINITY) {
                    typeSlider.setValue((int) (val / 4 + t));
                } else if (val < -2.0 && val > Double.NEGATIVE_INFINITY) {
                    typeSlider.setValue((int) (val / 4 + n_t));
                } else if (val == Double.POSITIVE_INFINITY) {
                    typeSlider.setValue(100);
                } else {
                    typeSlider.setValue(-100);
                }
                typeSlider.repaint();
                typeSpinner.repaint();
                setType(val);
            }
        }
        );*/
        this.spinnerBox = Box.createVerticalBox();
        this.spinnerLabel = new JLabel("1/n :");
        Box centringBox = Box.createHorizontalBox();
        centringBox.add(Box.createHorizontalGlue());
        centringBox.add(spinnerLabel);
        centringBox.add(Box.createHorizontalGlue());
        spinnerBox.add(centringBox);
        spinnerBox.add(Box.createRigidArea(new Dimension(0, 5)));
        spinnerBox.add(typeSpinner);

        this.sliderBox = Box.createHorizontalBox();
        this.sliderBox.add(typeSlider);
        this.sliderBox.add(Box.createRigidArea(new Dimension(20, 0)));
        this.sliderBox.add(spinnerBox);

        final JLabel typeValueLabel = new JLabel(String.format("%d%%", DEFAULT_TYPE));
        typeValueLabel.setPreferredSize(new Dimension(50, typeValueLabel.getPreferredSize().height));
        typeValueLabel.setHorizontalAlignment(SwingConstants.LEFT);
        this.typeSliderInv = new JSlider(JSlider.VERTICAL, 0, 100, DEFAULT_TYPE);
        this.typeSliderInv.setMaximumSize(new Dimension(100, 175));
        Hashtable typeLabel = new Hashtable();
        typeLabel.put(0, new JLabel("Subtractive"));
        typeLabel.put(50, typeValueLabel);
        typeLabel.put(100, new JLabel("Additive"));
        this.typeSliderInv.setLabelTable(typeLabel);
        this.typeSliderInv.setPaintLabels(true);
        this.typeSliderInv.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int val = typeSliderInv.getValue();
                typeValueLabel.setText(String.format("%d%%", val));
                typeSliderInv.repaint();
                setType(val / 100.0);
            }
        }
        );
        this.typeSliderInv.setVisible(false);

        Box slidersBox = Box.createHorizontalBox();
        slidersBox.add(Box.createHorizontalGlue());
        //slidersBox.add(Box.createRigidArea(new Dimension(20, 0)));
        slidersBox.add(midBox);
        //slidersBox.add(Box.createRigidArea(new Dimension(20, 0)));
        //slidersBox.add(parameterSelection);
        //slidersBox.add(this.sliderBox);
        slidersBox.add(this.typeSliderInv);
        //slidersBox.add(Box.createRigidArea(new Dimension(20, 0)));
        slidersBox.add(Box.createHorizontalGlue());

        Box botRightBox = Box.createVerticalBox();
        botRightBox.add(Box.createVerticalGlue());
        botRightBox.add(Utility.padComponentH(this.selectedLawButton));
        botRightBox.add(Box.createRigidArea(new Dimension(0, 10)));
        botRightBox.add(slidersBox);
        botRightBox.add(Box.createVerticalGlue());

        // put everything in a box
        Box topBox = Box.createHorizontalBox();
        topDisabledPanel = new DisabledPanel(topLeftBox);
        topBox.add(topDisabledPanel);
        topBox.add(resultBox);

        Box botBox = Box.createHorizontalBox();
        botBox.add(botLeftBox);
        botBox.add(botRightBox);

        Box mainBox = Box.createVerticalBox();
        mainBox.add(topBox);
        botDisabledPanel = new DisabledPanel(botBox);
        mainBox.add(botDisabledPanel);

        // draw the "grid"
        Color bordersColor = new Color(127, 127, 127);
        botBox.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, bordersColor));
        resultBox.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, bordersColor));
        botRightBox.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, bordersColor));

        // make components transparent
        this.backBox.setOpaque(false);
        this.frontBox.setOpaque(false);
        this.resultContainer.setOpaque(false);
        dualBoardContainer.setOpaque(false);
        this.transparencySlider.setOpaque(false);
        this.removalSlider.setOpaque(false);
        this.typeSlider.setOpaque(false);
        progressBarPanel.setOpaque(false);

        // set initial background color
        frame.getContentPane().setBackground(new Color(238, 238, 238));

        sideFrame = new SideFrame(this);
        this.initSideFrame();

        // frame pack
        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

        this.frame.add(mainBox, BorderLayout.CENTER);
        this.frame.pack();
        this.frame.setResizable(false);
        //this.frame.setLocationRelativeTo(sideFrame);
        this.frame.setLocation((int) maximumWindowBounds.getWidth() - sideFrame.getWidth() - frame.getWidth() - 10, (int) maximumWindowBounds.getHeight() / 2 - frame.getHeight() / 2);
        this.frame.setVisible(true);

        // set initial settings
        this.enableUpdates(false);
        this.setLaw(TransparencyLaws.Q_EQUALS_ZERO, false, true);
        this.setTransparency(DEFAULT_TRANSPARENCY / 100.0);
        this.setType(DEFAULT_TYPE / 100.0);
        this.setRemoval(DEFAULT_REMOVAL / 100.0);
        this.setBack(ImageSource.load(this.getClass().getResource(BACKGROUND_LOCATION), BACKGROUND_FILENAME));
        this.setFront(ImageSource.load(this.getClass().getResource(FOREGROUND_LOCATION), FOREGROUND_FILENAME));
        this.enableUpdates(true);
        this.updateResult();
        this.resultPanel.resetSelections(this.frontSource.getSourceSize()); // TODO: fix this hack
        this.updateResult();

        this.progressBar.setVisible(false);
        this.switchButton.setVisible(false);
        this.expectedButton.setVisible(false);
    }

    private Box boxForSecondFrame(int min, int max, TransparencyLaw associatedLaw, ButtonGroup bg) {
        JLabel lawLabel = new JLabel("<html>" + associatedLaw.getFunction() + "</html>", JLabel.CENTER);

        JTextField text = new JTextField();
        textList.add(text);

        //Slider
        JSlider slider = new JSlider(JSlider.VERTICAL, min, max, DEFAULT_TYPE);
        sliderList.add(slider);
        int addit = max / 2;
        int harmo = min / 2;
        int t = 3 * (max / 4);
        int n_t = -t;

        if (!(associatedLaw instanceof QEqualsZero)) {
            slider.setVisible(false);
        }

        ChangeListener cl = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = (double) slider.getValue();
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                }
                //between 1 and -1 :
                if (val <= addit && val >= harmo) {
                    val = val / (addit);
                    val = Math.round(val * 100) / 100.0;
                } //between 1 and 2 :
                else if (val > addit && val <= t) {
                    val = (val - addit) / (max / 4) + 1;
                    val = Math.round(val * 100) / 100.0;
                } //between -1 and -2 :
                else if (val < harmo && val >= n_t) {
                    val = (val - harmo) / (max / 4) - 1;
                    val = Math.round(val * 100) / 100.0;
                } //between 2 and +∞ :
                else if (val > t && val < max) {
                    val = 100 / ((max - t) - (val - t));
                    val = Math.round(val * 100) / 100.0;
                } //between -2 and -∞ :
                else if (val < n_t && val > min) {
                    val = 100 / ((min - n_t) - (val - n_t));
                    val = Math.round(val * 100) / 100.0;
                } //+∞ :
                else if (val == max) {
                    val = Double.POSITIVE_INFINITY;
                } //-∞ :
                else {
                    val = Double.NEGATIVE_INFINITY;
                }
                setType(val);
                bg.clearSelection();
                text.setText(String.valueOf(val));
            }
        };
        slider.addChangeListener(cl);

        slider.setPreferredSize(new Dimension(14, 250));
        slider.setOpaque(false);

        //RadioButton
        JRadioButton infinity = new JRadioButton("∞");
        JRadioButton two = new JRadioButton("2");
        JRadioButton one = new JRadioButton("1");
        JRadioButton half = new JRadioButton("0.5");
        JRadioButton zero = new JRadioButton("0");
        if (associatedLaw instanceof QEqualsZero) {
            zero.setSelected(true);
        }
        JRadioButton n_half = new JRadioButton("-0.5");
        JRadioButton n_one = new JRadioButton("-1");
        JRadioButton n_two = new JRadioButton("-2");
        JRadioButton n_infinity = new JRadioButton("-∞");

        infinity.setOpaque(false);
        two.setOpaque(false);
        one.setOpaque(false);
        half.setOpaque(false);
        zero.setOpaque(false);
        n_half.setOpaque(false);
        n_one.setOpaque(false);
        n_two.setOpaque(false);
        n_infinity.setOpaque(false);

        bg.add(infinity);
        bg.add(two);
        bg.add(one);
        bg.add(half);
        bg.add(zero);
        bg.add(n_half);
        bg.add(n_one);
        bg.add(n_two);
        bg.add(n_infinity);

        infinity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(max);
                slider.addChangeListener(cl);
                text.setText("Infinity");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(Double.POSITIVE_INFINITY);
            }
        });
        two.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(t);
                slider.addChangeListener(cl);
                text.setText("2");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(2.0);
            }
        });
        one.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(addit);
                slider.addChangeListener(cl);
                text.setText("1");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(1.0);
            }
        });
        half.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(max / 4);
                slider.addChangeListener(cl);
                text.setText("0.5");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(0.5);
            }
        });
        zero.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(0);
                slider.addChangeListener(cl);
                text.setText("0");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(0.0);
            }
        });
        n_half.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(-(max / 4));
                slider.addChangeListener(cl);
                text.setText("-0.5");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(-0.5);
            }
        });
        n_one.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(harmo);
                slider.addChangeListener(cl);
                text.setText("-1");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(-1.0);
            }
        });
        n_two.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(n_t);
                slider.addChangeListener(cl);
                text.setText("-2");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(-2.0);
            }
        });
        n_infinity.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                slider.removeChangeListener(cl);
                slider.setValue(min);
                slider.addChangeListener(cl);
                text.setText("-Infinity");
                if (associatedLaw != selectedLaw) {
                    setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                    for (JTextField t : textList) {
                        if (t != text) {
                            t.setText("");
                        }
                    }
                    for (JSlider s : sliderList) {
                        if (s != slider) {
                            s.setVisible(false);
                        } else {
                            s.setVisible(true);
                        }
                    }
                }
                setType(Double.NEGATIVE_INFINITY);
            }
        });

        //TextField
        text.setPreferredSize(new Dimension(70, 25));
        text.setMaximumSize(new Dimension(70, 25));
        text.setHorizontalAlignment(JTextField.CENTER);
        if (associatedLaw instanceof QEqualsZero) {
            text.setText(Integer.toString(DEFAULT_TYPE));
        }
        text.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double val = (double) Double.parseDouble(text.getText());
                    if (associatedLaw != selectedLaw) {
                        setLaw(associatedLaw, associatedLaw.isInverse(), associatedLaw.isUniform());
                        for (JTextField t : textList) {
                            if (t != text) {
                                t.setText("");
                            }
                        }
                        for (JSlider s : sliderList) {
                            if (s != slider) {
                                s.setVisible(false);
                            } else {
                                s.setVisible(true);
                            }
                        }
                    }
                    if (val <= 1.0 && val >= -1.0) {
                        slider.removeChangeListener(cl);
                        slider.setValue((int) (val * addit));
                        slider.addChangeListener(cl);
                    } else if (val > 1.0 && val <= 2.0) {
                        slider.removeChangeListener(cl);
                        slider.setValue((int) ((val - 1) * (max / 4) + addit));
                        slider.addChangeListener(cl);
                    } else if (val < -1.0 && val >= -2.0) {
                        slider.removeChangeListener(cl);
                        slider.setValue((int) ((val + 1) * (max / 4) + harmo));
                        slider.addChangeListener(cl);
                    } else if (val > 2.0 && val < Double.POSITIVE_INFINITY) {
                        slider.removeChangeListener(cl);
                        slider.setValue((int) Math.round(max - 100 / val));
                        slider.addChangeListener(cl);
                    } else if (val < -2.0 && val > Double.NEGATIVE_INFINITY) {
                        slider.removeChangeListener(cl);
                        slider.setValue((int) Math.round(min - 100 / val));
                        slider.addChangeListener(cl);
                    } else if (val == Double.POSITIVE_INFINITY) {
                        slider.removeChangeListener(cl);
                        slider.setValue(max);
                        slider.addChangeListener(cl);
                    } else {
                        slider.removeChangeListener(cl);
                        slider.setValue(min);
                        slider.addChangeListener(cl);
                    }
                    bg.clearSelection();
                    setType(val);
                } catch (Exception ex) {
                }
            }
        }
        );

        //Box
        Box slibel = Box.createHorizontalBox();
        Box labels = Box.createVerticalBox();
        labels.add(infinity);
        labels.add(Box.createVerticalGlue());
        labels.add(two);
        labels.add(Box.createVerticalGlue());
        labels.add(one);
        labels.add(Box.createVerticalGlue());
        labels.add(half);
        labels.add(Box.createVerticalGlue());
        labels.add(zero);
        labels.add(Box.createVerticalGlue());
        labels.add(n_half);
        labels.add(Box.createVerticalGlue());
        labels.add(n_one);
        labels.add(Box.createVerticalGlue());
        labels.add(n_two);
        labels.add(Box.createVerticalGlue());
        labels.add(n_infinity);

        Box sBox = Box.createVerticalBox();
        sBox.add(Box.createRigidArea(new Dimension(0, 5)));
        sBox.add(slider);
        sBox.add(Box.createRigidArea(new Dimension(0, 5)));
        slibel.add(sBox);
        slibel.add(labels);

        Box centringBox = Box.createHorizontalBox();

        Box labelBox = Box.createVerticalBox();
        Box b1 = Box.createHorizontalBox();
        b1.add(Box.createHorizontalGlue());
        b1.add(Box.createRigidArea(new Dimension(5, 0)));
        b1.add(lawLabel);
        b1.add(Box.createRigidArea(new Dimension(5, 0)));
        b1.add(Box.createHorizontalGlue());
        //b1.setBorder(BorderFactory.createLineBorder(Color.black));

        labelBox.add(b1);
        labelBox.add(Box.createRigidArea(new Dimension(0, 10)));

        centringBox.add(Box.createHorizontalGlue());
        centringBox.add(labelBox);
        centringBox.add(Box.createHorizontalGlue());

        Box textBox = Box.createHorizontalBox();
        textBox.add(Box.createHorizontalGlue());
        //spiBox.add(spinner);
        textBox.add(text);
        textBox.add(Box.createHorizontalGlue());

        Box law = Box.createVerticalBox();
        law.add(centringBox);
        law.add(slibel);
        law.add(Box.createRigidArea(new Dimension(0, 10)));
        law.add(textBox);
        law.add(Box.createRigidArea(new Dimension(0, 10)));

        return law;
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        this.updateResult();
    }

    public void setVisible(boolean b) {
        if (b) {
            frame.setVisible(true);
            sideFrame.setVisible(true);
        } else {
            frame.setVisible(false);
            sideFrame.setVisible(false);
        }
    }

    private void initSideFrame() {
        textList = new ArrayList<>();
        sliderList = new ArrayList<>();
    }

    public void update(int x, int y, int w, boolean bordersE, boolean infoFileE, boolean highlightE, String saveD, ImagePanel resultP) {
        frame.setLocation(x, y);
        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();
        if (maximumWindowBounds.getWidth() - (frame.getX() + frame.getWidth()) - sideFrame.getWidth() - 10 > 0) {
            sideFrame.setLocation(frame.getX() + frame.getWidth() + 10, frame.getY() + frame.getHeight() / 2 - sideFrame.getHeight() / 2);
        } else if (frame.getX() - sideFrame.getWidth() > 0) {
            sideFrame.setLocation(frame.getX() - sideFrame.getWidth() - 10, frame.getY() + frame.getHeight() / 2 - sideFrame.getHeight() / 2);
        } else {
            sideFrame.setLocation((int) maximumWindowBounds.getWidth() - sideFrame.getWidth(), frame.getY() + frame.getHeight() / 2 - sideFrame.getHeight() / 2);
        }
        this.bordersEnabled = bordersE;
        this.enableInfoFile = infoFileE;
        this.highlightInvalidPixels = highlightE;
        bordersCheckbox.setSelected(bordersEnabled);
        highlightCheckbox.setSelected(highlightInvalidPixels);
        infoFileCheckbox.setSelected(enableInfoFile);
        this.saveDirectory = saveD;
        this.resultPanel.clearSelections();
        this.setMaxDisplayWidth(w);
        switch (w) {
            case 360:
                button360.setSelected(true);
                break;
            case 480:
                button480.setSelected(true);
                break;
            case 640:
                button640.setSelected(true);
                break;
            default:
                button360.setSelected(true);
        }

        resultP.copy(this.resultPanel);
    }
    
    public void updateSettings(JDialog settingsDialog){
        this.settingsDialog.setLocation(settingsDialog.getLocation());
        this.settingsDialog.setVisible(settingsDialog.isVisible());
    }
    
    public void update(int w, boolean bordersE, boolean infoFileE, boolean highlightE, String saveD, JDialog settingsDialog) {
        this.bordersEnabled = bordersE;
        this.enableInfoFile = infoFileE;
        this.highlightInvalidPixels = highlightE;
        bordersCheckbox.setSelected(bordersEnabled);
        highlightCheckbox.setSelected(highlightInvalidPixels);
        infoFileCheckbox.setSelected(enableInfoFile);
        this.saveDirectory = saveD;
        this.setMaxDisplayWidth(w);
        switch (w) {
            case 360:
                button360.setSelected(true);
                break;
            case 480:
                button480.setSelected(true);
                break;
            case 640:
                button640.setSelected(true);
                break;
            default:
                button360.setSelected(true);
        }
        this.updateSettings(settingsDialog);
    }
}
