
import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.beans.*;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;

public class ThirdApplication implements ActionListener {

    private static final Color DEFAULT_BACK_COLOR = new Color(246, 246, 246);
    private static final Color DEFAULT_FRONT_COLOR = new Color(246, 0, 0);
    private static final int DEFAULT_TRANSPARENCY = 100;
    private static final int DEFAULT_REMOVAL = 50;
    private static final int DEFAULT_TYPE = 50;
    public static final double DEFAULT_ALPHA = 0.25;
    public static final double DEFAULT_BETA = 0;
    private static final Color DEFAULT_INVALID_COLOR = new Color(255, 0, 0);
    private static final String MANUAL_FILENAME = "resources/manual.html";
    private static final String BACKGROUND_FILENAME = "church.jpg";
    private static final String FOREGROUND_FILENAME = "logo.jpg";
    private static final String BACKGROUND_LOCATION = "resources/church.jpg";
    private static final String FOREGROUND_LOCATION = "resources/logo.jpg";
    private static final String WEBSITE_URL = "http://rgbtransparency.edel.univ-poitiers.fr";

    private Menu application;

    private JRadioButton button360;
    private JRadioButton button480;
    private JRadioButton button640;
    private JCheckBox bordersCheckbox;
    private JCheckBox highlightCheckbox;
    private JCheckBox infoFileCheckbox;
    private String saveDirectory;
    private ArrayList<TransparencyLaw> laws;
    private TransparencyLaw selectedLaw;
    private Source backSource;
    private Source frontSource;
    private double transparency;
    private double type;
    private double alpha = DEFAULT_ALPHA;
    private double beta = DEFAULT_BETA;
    private double removal;
    private Color edgeColor;
    private double removalTable[][];
    private Color opaqueSelectionColor;

    private boolean updatesEnabled;
    private String previousInfoString;
    private Source tempBackSource;
    private Source oldBackSource;
    private Source oldFrontSource;

    private boolean bordersEnabled;
    private boolean enableInfoFile;
    private boolean highlightInvalidPixels;
    private Color invalidColor;
    private Color secondInvalidColor;
    private int defaultWidth;
    private int width;

    private DisabledPanel topDisabledPanel;
    private DisabledPanel botDisabledPanel;
    public DisabledPanel littleDisabledPanel;

    private boolean scattering = true;

    private JFrame frame;
    private LittleFrame littleFrame;
    private JMenu menuSteps;
    private JMenu menuHelp;
    private JMenu menuApp;
    private JDialog settingsDialog;
    private JDialog manualDialog;
    private Box backBox;
    private Box frontBox;
    private ColorDialog backColorDialog;
    private ColorDialog frontColorDialog;
    private ImagePanel resultPanel;
    private JPanel resultContainer;
    private DualBoard dualBoard;
    private JButton switchButton;
    private JButton expectedButton;
    private JButton selectedLawButton;
    private JPopupMenu transparencyLawMenu;
    private JTextField thicknessText;
    private JLabel thicknessLabel;
    private Box labelBox;
    private Box buttonBox;
    private Box sliderBox;
    private JSlider thicknessSlider;
    private JSlider removalSlider;
    private JLabel maxRemovalLabel;
    private JLabel noRemovalLabel;
    private JLabel impossibleRemoval;
    private JProgressBar progressBar;

    // creates the result image of the given dimension
    private BufferedImage computeResult(int width, int height, boolean showProgress) {
        BufferedImage resultImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        boolean isFrontImage = this.frontSource instanceof ImageSource;
        boolean nullify = this.highlightInvalidPixels;
        boolean directNonUniform = !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform();
        double c = this.selectedLaw.isUniform() ? this.transparency : this.removal;

        if (showProgress) {
            this.progressBar.setVisible(true);
        }

        LinkedList<Polygon> selections = this.resultPanel.getSelections();
        LinkedList<Polygon> expSelections = this.resultPanel.getExpSelections();

        Polygon currentSel = this.resultPanel.getCurrentSelection();
        resultPanel.resetInvalidMap();
        for (int y = 0; y < height; y++) {
            if (showProgress && y % (height / 50) == 0) {
                this.progressBar.setValue(100 * y / (height - 1));
                Utility.repaintNow(this.progressBar);
            }
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                Color color = backColor;
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                for (Polygon s : selections) {
                    if (s.contains(x1, y1)) {
                        if (opaqueSelectionColor != null && s == currentSel) {
                            color = opaqueSelectionColor;
                        } else {
                            if (directNonUniform) {
                                int x2 = Math.round(rx * (this.removalTable.length - 1));
                                int y2 = Math.round(ry * (this.removalTable[0].length - 1));
                                double cmin = this.removalTable[x2][y2];
                                c = this.removal * cmin;
                            }
                            if (isFrontImage) {
                                Rectangle bounds = s.getBounds();
                                rx = 1.0f * (x1 - bounds.x) / bounds.width;
                                ry = 1.0f * (y1 - bounds.y) / bounds.height;
                            }
                            Color frontColor = this.frontSource.getPixel(rx, ry);
                            color = this.selectedLaw.apply(backColor, frontColor, c, this.alpha, this.beta, nullify);
                            if (color == null) {
                                color = this.invalidColor;
                                resultPanel.addInvalidPixel(x, y);
                            } else if (color.getRGB() == this.secondInvalidColor.getRGB()) {
                                resultPanel.addInvalidPixel(x, y);
                            }
                        }
                        break;
                    }
                }
                for (Polygon s : expSelections) {
                    if (s.contains(x1, y1)) {
                        if (opaqueSelectionColor != null) {
                            color = opaqueSelectionColor;
                        }
                    }
                }
                resultImage.setRGB(x, y, color.getRGB());
            }
        }

        Graphics2D g = resultImage.createGraphics();
        double scale = 1.0 * width / this.resultPanel.getWidth();
        g.scale(scale, scale);
        g.setStroke(new BasicStroke(Math.round(1.0 / scale)));

        for (Polygon s : expSelections) {
            g.drawPolygon(s.xpoints, s.ypoints, s.npoints);
        }
        if (this.bordersEnabled) {
            g.setColor(this.edgeColor);
            for (Polygon s : selections) {
                g.drawPolygon(s.xpoints, s.ypoints, s.npoints);
            }
        }

        if (showProgress) {
            this.progressBar.setValue(100);
            Utility.repaintNow(this.progressBar);
            this.progressBar.setVisible(false);
        }

        return resultImage;
    }

    // computes the removal for each pixel
    public void computeRemoval() {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }
        int width = resultSize.width;
        int height = resultSize.height;

        boolean isFrontImage = this.frontSource instanceof ImageSource;
        TransparencyLaw law = this.selectedLaw;

        this.removalTable = new double[width][height];
        LinkedList<Polygon> selections = this.resultPanel.getSelections();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                double removalValue = 1.0;
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                for (Polygon s : selections) {
                    if (s.contains(x1, y1)) {
                        if (isFrontImage) {
                            Rectangle bounds = s.getBounds();
                            rx = 1.0f * (x1 - bounds.x) / bounds.width;
                            ry = 1.0f * (y1 - bounds.y) / bounds.height;
                        }
                        Color frontColor = this.frontSource.getPixel(rx, ry);
                        removalValue = law.getRemoval(backColor, frontColor, this.removal, this.alpha, this.beta);
                        break;
                    }
                }
                this.removalTable[x][y] = removalValue;
            }
        }
    }

    // computes the suggested foreground color
    public Color computeSuggestedForeground(Color expectedBackColor) {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null || this.backSource instanceof ColorSource) {
            resultSize = new Dimension(1, 1);
        }
        int width = resultSize.width;
        int height = resultSize.height;

        long sumRed = 0;
        long sumGreen = 0;
        long sumBlue = 0;
        long numPixels = 0;
        Polygon s = this.resultPanel.getCurrentSelection();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float rx = x / (width - 1.0f);
                float ry = y / (height - 1.0f);
                Color backColor = this.backSource.getPixel(rx, ry);
                float x1 = rx * (this.resultPanel.getWidth() - 1);
                float y1 = ry * (this.resultPanel.getHeight() - 1);
                if (s.contains(x1, y1)) {
                    sumRed += backColor.getRed();
                    sumGreen += backColor.getGreen();
                    sumBlue += backColor.getBlue();
                    numPixels++;
                    break;
                }
            }
        }

        Color backColor = new Color((int) (sumRed / numPixels), (int) (sumGreen / numPixels), (int) (sumBlue / numPixels));

        selectedLaw.setExpected(true);
        Color newFront = selectedLaw.apply(backColor, expectedBackColor, 1.0, this.alpha, this.beta);
        selectedLaw.setExpected(false);
        return newFront;
    }

    // updates the dual board using the current settings
    private void updateDualBoard() {
        TransparencyLaw dualBoardLaw = this.selectedLaw;
        if (this.selectedLaw.isInverse()) {
            dualBoardLaw = this.selectedLaw.associatedLaw();
        }

        boolean nullify = this.highlightInvalidPixels;
        if (this.frontSource instanceof ImageSource) {
            Dimension d = this.frontSource.getSourceSize();
            Dimension max = new Dimension(this.dualBoard.getWidth() / 2, this.dualBoard.getHeight() / 2);
            Utility.fitDimension(d, max);
            BufferedImage resultImage = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_RGB);
            for (int y = 0; y < d.height; y++) {
                for (int x = 0; x < d.width; x++) {
                    float rx = x / (d.width - 1.0f);
                    float ry = y / (d.height - 1.0f);
                    Color backColor = (rx > 0.50f ? Color.WHITE : Color.BLACK);
                    Color frontColor = this.frontSource.getPixel(rx, ry);
                    Color color = dualBoardLaw.apply(backColor, frontColor, this.transparency, this.alpha, this.beta, nullify);
                    if (color == null) {
                        color = this.invalidColor;
                    }
                    resultImage.setRGB(x, y, color.getRGB());
                }
            }

            this.dualBoard.setImage(resultImage, this.edgeColor);
        } else {
            Color frontColor = this.frontSource.getPixel(0, 0);
            Color blackColor = dualBoardLaw.apply(new Color(0, 0, 0), frontColor, this.transparency, this.alpha, this.beta, nullify);
            Color whiteColor = dualBoardLaw.apply(new Color(255, 255, 255), frontColor, this.transparency, this.alpha, this.beta, nullify);
            if (blackColor == null) {
                blackColor = this.invalidColor;
            }
            if (whiteColor == null) {
                whiteColor = this.invalidColor;
            }
            this.dualBoard.setColors(blackColor, whiteColor, this.edgeColor);
        }
    }

    // enable/disable result panel updates (used when we want to set the initial settings)
    private void enableUpdates(boolean enabled) {
        this.updatesEnabled = enabled;
    }

    // updates the result panel using the current settings
    private void updateResult() {
        if (!this.updatesEnabled) {
            return;
        }

        if (this.backSource == null || this.frontSource == null) {
            this.resultPanel.setImage(null);
            this.frame.pack();
            return;
        }

        // compute size
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        Dimension maxSize = this.resultPanel.getContainerSize();
        Utility.fitDimension(resultSize, maxSize);

        this.resultPanel.setPanelSize(resultSize, this.resultContainer.getSize());

        // compute result image
        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, false);

        // update dual board
        if (selectedLaw.isUniform()) {
            this.updateDualBoard();
        }

        // update result panel
        this.resultPanel.setImage(resultImage);
    }

    // saves the result image to a file
    private void saveResult(String filename) {
        if (this.backSource == null || this.frontSource == null) {
            return;
        }

        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, true);

        boolean success = false;
        try {
            success = ImageIO.write(resultImage, "JPEG", new File(filename));
        } catch (IOException e) {
            success = false;
        }

        if (!success) {
            System.out.println("Couldn't save image");
        }

        if (this.enableInfoFile) {
            saveInfoFile(filename.substring(0, filename.length() - 4) + ".txt");
        }
    }

    // gets the result image as a source
    private Source getResultAsSource() {
        Dimension backSize = this.backSource.getSourceSize();
        Dimension resultSize = backSize;
        if (backSize == null) {
            resultSize = this.resultPanel.getContainerSize();
        }

        BufferedImage resultImage = this.computeResult(resultSize.width, resultSize.height, true);

        return new ImageSource("", "", resultImage);
    }

    // sets the result image in the background source
    private void loadResultAsBack() {
        this.setBack(this.getResultAsSource());
    }

    // saves the info file
    private void saveInfoFile(String filename) {
        PrintWriter writer;
        try {
            writer = new PrintWriter(filename, "UTF-8");
        } catch (IOException e) {
            System.out.println("Couldn't save info file");
            return;
        }

        if (this.previousInfoString != null && !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform()) {
            writer.print(this.previousInfoString);
            writer.println();
        }
        writer.print(this.getInfoString());
        writer.close();
    }

    // gets info data
    private String getInfoString() {
        StringWriter stringWriter = new StringWriter();
        PrintWriter writer = new PrintWriter(stringWriter);

        writer.printf("Translucency by a scattering layer\r\n");
        writer.printf("Non Scattering Layer: %s\r\n\r\n", this.scattering ? "Off" : "On");
        
        if (this.scattering) {
            writer.printf("Unit thickness layer reflection\r\n");
            writer.printf("Proportion of opaque foreground: %d%%\r\n", (int) (this.alpha * 100));
            writer.printf("Part of achromatic reflection: %d%%\r\n\r\n", (int) (this.beta * 100));
        }
        
        writer.printf("Background: %s\r\n", this.backSource.toString());
        writer.printf("Foreground: %s %s\r\n\r\n", this.frontSource.toString(),
                this.scattering? "":"(reflection of the unit thickness non-scattering layer on a perfect white background)");
        
        writer.printf("%s\r\n", this.selectedLawButton.getText());
        if (this.selectedLaw.isUniform()) {
            writer.printf("Thickness: %.2f (Infinity: opaque, 0: transparent)\r\n\r\n", this.transparency);
        } else if (this.selectedLaw.isInverse()) {
            writer.printf("Transparency removal: %d%% (0%%: no removal, 100%%: max. removal)\r\n", (int) (this.removal * 100));
        } else {
            writer.printf("Transparency density: %d%% (0%%: no density, 100%%: max. density)\r\n", (int) (this.removal * 100));
        }
        

        String data = stringWriter.toString();
        writer.close();
        return data;
    }

    // changes the maximum dimension of the result panel
    private void setMaxDisplayWidth(int w) {
        this.width = w;
        this.resultPanel.setMaxSize(new Dimension(w, 360));
        this.resultContainer.setPreferredSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setMinimumSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setMaximumSize(new Dimension(w + 20, 360 + 20));
        this.resultContainer.setSize(new Dimension(w + 20, 360 + 20));
        this.updateResult();
        this.frame.pack();
    }

    // checks that we load a background of the same size
    private boolean checkBackSize(Source source) {
        if (this.backSource == null || source.getSourceSize() == null || this.backSource.getSourceSize() == null) {
            return true;
        }
        if (!source.getSourceSize().equals(this.backSource.getSourceSize())) {
            JOptionPane.showMessageDialog(frame, "The dimensions of the image should be equal to the dimensions of the current background.",
                    "Invalid image dimensions", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    // changes one of the source
    private void setSource(SourcePos pos, Source source) {
        if (source == null) {
            return;
        }

        // in direct non-uniform mode, check that we load a background of the same size
        if (pos == SourcePos.BACK && !this.selectedLaw.isInverse() && !this.selectedLaw.isUniform()) {
            if (!checkBackSize(source)) {
                return;
            }
        }

        // hide color dialog if needed
        ColorDialog dialog = (pos == SourcePos.BACK ? this.backColorDialog : this.frontColorDialog);
        if (source instanceof ColorSource) {
            dialog.setColor(source.getPixel(0, 0));
        } else {
            dialog.hide();
            dialog.setColor(pos == SourcePos.BACK ? DEFAULT_BACK_COLOR : DEFAULT_FRONT_COLOR);
        }

        // reset result panel selections and update edge color if front source
        if (pos == SourcePos.FRONT) {
            if ((frontSource == null || !(frontSource instanceof ColorSource && source instanceof ColorSource)) && this.resultPanel.getSelections().size() == 0) {
                this.resultPanel.resetSelections(source.getSourceSize());
            }

            this.edgeColor = new Color(153, 153, 153);
            if (source instanceof ColorSource) {
                this.edgeColor = source.getPixel(0, 0);
            }
        }

        // update source
        if (pos == SourcePos.BACK) {
            this.backSource = source;
        } else {
            this.frontSource = source;
            if (littleFrame != null) {
                if (!scattering) {
                    this.littleFrame.nonScatteringUpdate(this.frontSource);
                } else {
                    this.littleFrame.update(alpha, beta, frontSource);
                }
            }
        }

        // update source container
        Box box = (pos == SourcePos.BACK ? this.backBox : this.frontBox);
        box.removeAll();
        box.add(source);
        box.repaint();

        // update result image
        this.updateResult();
        this.frame.pack();
    }

    // changes the background source
    public void setBack(Source source) {
        this.setSource(SourcePos.BACK, source);
    }

    // changes the foreground source
    public void setFront(Source source) {
        this.setSource(SourcePos.FRONT, source);
        if (littleFrame != null) {
            littleFrame.updateSliders(alpha, beta);
            if (!scattering) {
                littleFrame.nonScatteringUpdate(this.frontSource);
            }
        }
    }

    // changes the transparency law
    private void setLaw(TransparencyLaw law, boolean isInverse, boolean isUniform) {
        if (this.selectedLaw != null) {
            this.previousInfoString = getInfoString();
        }

        if (isUniform || isInverse) {
            if (littleDisabledPanel != null && this.scattering) {
                littleDisabledPanel.setEnabled(true);
            }
            switchButton.setText("<html><center>Visualize Removal Part</center></html>");
        } else {
            if (littleDisabledPanel != null) {
                littleDisabledPanel.setEnabled(false);
            }
            switchButton.setText("<html><center>Back To Inverse Transparency</center></html>");
        }

        String text = String.format("%s %s Transparency", isInverse ? "Inverse" : "Direct",
                isUniform ? "Uniform" : "Non-Uniform");
        this.selectedLawButton.setText(text);

        if (!isUniform) {
            this.maxRemovalLabel.setText(isInverse ? "Max. Removal" : "Max. Density");
            this.noRemovalLabel.setText(isInverse ? "No Removal" : "No Density");
            this.removalSlider.repaint();
        }

        this.labelBox.setVisible(isUniform);
        this.sliderBox.setVisible(isUniform);
        this.buttonBox.setVisible(isUniform);
        this.removalSlider.setVisible(!isUniform && (!this.scattering || alpha != 0 || beta != 0));
        this.dualBoard.setVisible(isUniform);
        if (this.impossibleRemoval != null) {
            this.impossibleRemoval.setVisible(this.scattering && !isUniform && alpha == 0 && beta == 0);
        }
        if (selectedLaw != null) {
            if (!selectedLaw.isUniform() && isUniform) {
                frame.pack();
            }
        }
        this.switchButton.setVisible(!isUniform && (!this.scattering || alpha != 0 || beta != 0));
        this.expectedButton.setVisible(!isUniform && isInverse && (!this.scattering || alpha != 0 || beta != 0));

        boolean directNonUniform = !isInverse && !isUniform;
        this.resultPanel.setSelectionsLocked(directNonUniform);

        this.resultPanel.setExpectedEnabled(isInverse);

        this.selectedLaw = law;
        this.selectedLaw.setInverse(isInverse);
        this.selectedLaw.setUniform(isUniform);

        this.updateResult();
    }

    public void setUniform(boolean b) {
        this.selectedLaw.setUniform(b);
    }

    public void setInverse(boolean b) {
        this.selectedLaw.setInverse(b);
    }

    // changes the transparency rate
    private void setTransparency(double value) {
        this.transparency = value;
        this.updateResult();
    }

    // changes the transparency type
    private void setType(double value) {
        this.type = value;
        this.updateResult();
    }

    public void setAlpha(double value) {
        this.alpha = value;
        this.updateResult();
        if (this.littleFrame != null && this.scattering) {
            this.littleFrame.update(alpha, beta, frontSource);
        }
        if (this.impossibleRemoval != null && selectedLaw != null) {
            this.impossibleRemoval.setVisible(this.scattering && !selectedLaw.isUniform() && alpha == 0 && beta == 0);
            this.removalSlider.setVisible(!selectedLaw.isUniform() && (!this.scattering || alpha != 0 || beta != 0));
            this.switchButton.setVisible(!selectedLaw.isUniform() && (!this.scattering || alpha != 0 || beta != 0));
            this.expectedButton.setVisible(!selectedLaw.isUniform() && selectedLaw.isInverse() && (!this.scattering || alpha != 0 || beta != 0));
        }
    }

    public double getAlpha() {
        return alpha;
    }

    public void setBeta(double value) {
        this.beta = value;
        this.updateResult();
        if (this.littleFrame != null && this.scattering) {
            this.littleFrame.update(alpha, beta, frontSource);
        }
        if (this.impossibleRemoval != null && selectedLaw != null) {
            this.impossibleRemoval.setVisible(!selectedLaw.isUniform() && alpha == 0 && beta == 0);
            this.removalSlider.setVisible(!selectedLaw.isUniform() && (alpha != 0 || beta != 0));
            this.switchButton.setVisible(!selectedLaw.isUniform() && (alpha != 0 || beta != 0));
            this.expectedButton.setVisible(!selectedLaw.isUniform() && selectedLaw.isInverse() && (alpha != 0 || beta != 0));
        }
    }

    public double getBeta() {
        return beta;
    }

    // changes the removal
    private void setRemoval(double value) {
        this.removal = value;
        this.updateResult();
    }

    // shows the color dialog of one of the sources
    private void showColorSourceDialog(SourcePos pos) {
        ColorDialog dialog;
        Source source;
        if (pos == SourcePos.BACK) {
            dialog = this.backColorDialog;
            source = this.backSource;
        } else {
            dialog = this.frontColorDialog;
            source = this.frontSource;
        }

        if (pos == SourcePos.BACK) {
            this.oldBackSource = source;
        } else {
            this.oldFrontSource = source;
        }

        Point p = this.frame.getLocation();
        p.x += 205 - dialog.getWidth();
        p.y += 455;
        if (pos == SourcePos.BACK) {
            p.y -= dialog.getHeight();
        }
        dialog.setOldAlpha(alpha);
        dialog.setOldBeta(beta);
        dialog.show(p);
    }

    // opens the dialog to load an image as a source
    private String openLoadDialog() {
        JFileChooser chooser = new JFileChooser(".");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images JPEG", "jpg");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showOpenDialog(this.frame);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile().getAbsolutePath();
        } else {
            return null;
        }
    }

    // opens the dialog to save an image
    private void openSaveDialog() {
        JFileChooser chooser = new JFileChooser(".") {
            public void approveSelection() {
                String filename = getSelectedFile().getAbsolutePath();
                if (filename.lastIndexOf(".jpg") == -1) {
                    filename += ".jpg";
                }
                File file = new File(filename);
                if (file.exists()) {
                    int result = JOptionPane.showConfirmDialog(this, "This file already exists. Overwrite?",
                            "Overwrite file", JOptionPane.YES_NO_OPTION);
                    if (result == JOptionPane.YES_OPTION) {
                        super.approveSelection();
                    }
                } else {
                    super.approveSelection();
                }
            }
        };

        chooser.setCurrentDirectory(new File(saveDirectory));

        FileNameExtensionFilter filter = new FileNameExtensionFilter("Images JPEG", "jpg");
        chooser.setFileFilter(filter);
        int returnVal = chooser.showSaveDialog(this.frame);
        if (returnVal == JFileChooser.APPROVE_OPTION) {
            String filename = chooser.getSelectedFile().getAbsolutePath();
            if (filename.lastIndexOf(".jpg") == -1) {
                filename += ".jpg";
            }
            saveResult(filename);
        }
    }

    // loads the Settings dialog
    private void loadSettings() {
        // window color dialog
        Color windowColor = frame.getContentPane().getBackground();
        final ColorDialog windowColorDialog = new ColorDialog(this.frame, "Select Window Color", windowColor);
        windowColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                frame.getContentPane().setBackground(color);
            }
        }
        );

        // "Select Window Color" label + button
        JLabel backgroundLabel = new JLabel("Select Window Color");
        JButton backgroundButton = new JButton("Select Color...");
        backgroundButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.show();
            }
        }
        );
        Box backgroundBox = Box.createHorizontalBox();
        backgroundBox.add(backgroundLabel);
        backgroundBox.add(Box.createHorizontalGlue());
        backgroundBox.add(backgroundButton);
        backgroundBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Maximum Display Size" stuff
        JLabel maximumDisplayLabel = new JLabel("Maximum Display Size: ");
        button360 = new JRadioButton("1:1 (360/360)", defaultWidth == 360);
        button480 = new JRadioButton("4:3 (480/360)", defaultWidth == 480);
        button640 = new JRadioButton("16:9 (640/360)", defaultWidth == 640);
        button360.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(360);
            }
        });
        button480.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(480);
            }
        });
        button640.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setMaxDisplayWidth(640);
            }
        });
        ButtonGroup grp = new ButtonGroup();
        grp.add(button360);
        grp.add(button480);
        grp.add(button640);
        Box maximumDisplayBox = Box.createVerticalBox();
        maximumDisplayBox.add(maximumDisplayLabel);
        maximumDisplayBox.add(button360);
        maximumDisplayBox.add(button480);
        maximumDisplayBox.add(button640);

        // "Show Selections Borders" checkbox
        bordersCheckbox = new JCheckBox("Show Selections Borders", bordersEnabled);
        bordersCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                boolean enabled = bordersCheckbox.isSelected();
                bordersEnabled = enabled;
                dualBoard.enableBorder(enabled);
                updateResult();
            }
        }
        );

        // "Highlight Invalid Pixels" checkbox
        highlightCheckbox = new JCheckBox("Highlight Invalid Pixels", this.highlightInvalidPixels);
        highlightCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                highlightInvalidPixels = highlightCheckbox.isSelected();
                updateResult();
            }
        }
        );

        // invalid pixels color dialog
        final ColorDialog invalidColorDialog = new ColorDialog(this.frame, "Select Invalid Pixels Color", this.invalidColor);
        invalidColorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                invalidColor = color;
                float[] hsb = new float[3];
                Color.RGBtoHSB(invalidColor.getRed(), invalidColor.getGreen(), invalidColor.getBlue(), hsb);
                float inc = 0.2F;
                if (hsb[2] <= inc) {
                    secondInvalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] + inc);
                } else {
                    secondInvalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] - inc);
                }
                if (littleFrame != null) {
                    littleFrame.updateColor(secondInvalidColor);
                }
                updateResult();
            }
        }
        );

        // "Select color..." button
        JButton invalidColorButton = new JButton("Select Color...");
        invalidColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                invalidColorDialog.show();
            }
        }
        );
        Box highlightBox = Box.createHorizontalBox();
        highlightBox.add(highlightCheckbox);
        highlightBox.add(Box.createHorizontalGlue());
        highlightBox.add(invalidColorButton);
        highlightBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Highlight Invalid Pixels" extension label
        JLabel highlightLabel = new JLabel("(Uniform Inverse Transparency Only)");
        Box highlightLabelBox = Box.createHorizontalBox();
        highlightLabelBox.add(Box.createRigidArea(new Dimension(22, 0)));
        highlightLabelBox.add(highlightLabel);

        //Default Save Directory
        JLabel defaultSaveLabel = new JLabel("Default save directory ");
        JButton defaultSaveButton = new JButton("Select Directory...");
        defaultSaveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setCurrentDirectory(new File(saveDirectory));
                chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
                int returnVal = chooser.showSaveDialog(SwingUtilities.getWindowAncestor((JButton) e.getSource()));
                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    saveDirectory = chooser.getSelectedFile().getAbsolutePath();
                }
            }
        }
        );
        Box defaultSaveBox = Box.createHorizontalBox();
        defaultSaveBox.add(defaultSaveLabel);
        defaultSaveBox.add(Box.createHorizontalGlue());
        defaultSaveBox.add(defaultSaveButton);
        defaultSaveBox.add(Box.createRigidArea(new Dimension(5, 0)));

        // "Save Information File (.txt)" checkbox
        infoFileCheckbox = new JCheckBox("Save Information File (.txt)", this.enableInfoFile);
        infoFileCheckbox.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent event) {
                enableInfoFile = infoFileCheckbox.isSelected();
            }
        }
        );

        // boxes
        Box windowBox = Box.createVerticalBox();
        windowBox.setBorder(BorderFactory.createTitledBorder("Window Settings"));
        windowBox.add(backgroundBox);
        windowBox.add(Box.createRigidArea(new Dimension(0, 10)));
        windowBox.add(Utility.padComponentLeft(maximumDisplayBox));

        Box imageBox = Box.createVerticalBox();
        imageBox.setBorder(BorderFactory.createTitledBorder("Image Settings"));
        imageBox.add(Utility.padComponentLeft(bordersCheckbox));
        imageBox.add(highlightBox);
        imageBox.add(Utility.padComponentLeft(highlightLabelBox));

        Box saveBox = Box.createVerticalBox();
        saveBox.setBorder(BorderFactory.createTitledBorder("Save Settings"));
        saveBox.add(Utility.padComponentLeft(defaultSaveBox));
        saveBox.add(Utility.padComponentLeft(infoFileCheckbox));

        Box mainBox = Box.createVerticalBox();
        mainBox.add(windowBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(imageBox);
        mainBox.add(Box.createRigidArea(new Dimension(0, 15)));
        mainBox.add(saveBox);

        // ok button
        JButton okButton = new JButton("OK");
        okButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
                settingsDialog.setVisible(false);
                //save settings here
                BufferedWriter bw;
                try {
                    bw = new BufferedWriter(new FileWriter("transparency_settings.properties"));
                    bw.write("borders enabled :\n");
                    bw.write(Boolean.toString(bordersEnabled));
                    bw.write("\n");
                    bw.write("Save info file enabled :\n");
                    bw.write(Boolean.toString(enableInfoFile));
                    bw.write("\n");
                    bw.write("Highlighting invalid pixels enabled :\n");
                    bw.write(Boolean.toString(highlightInvalidPixels));
                    bw.write("\n");
                    bw.write("Default save directory :\n");
                    bw.write(saveDirectory);
                    bw.write("\n");
                    bw.write("Window size :\n");
                    if (button360.isSelected()) {
                        bw.write(Integer.toString(360));
                    } else if (button480.isSelected()) {
                        bw.write(Integer.toString(480));
                    } else if (button640.isSelected()) {
                        bw.write(Integer.toString(640));
                    }
                    bw.close();
                } catch (Exception ex) {
                }
            }
        }
        );

        ComponentListener dialogListener = new ComponentAdapter() {
            public void componentHidden(ComponentEvent e) {
                windowColorDialog.hide();
                invalidColorDialog.hide();
            }
        };

        Box okBox = Box.createVerticalBox();
        okBox.add(Box.createRigidArea(new Dimension(0, 5)));
        okBox.add(okButton);
        okBox.add(Box.createRigidArea(new Dimension(0, 10)));

        // create dialog
        this.settingsDialog = new JDialog(this.frame, "Settings", false);
        this.settingsDialog.addComponentListener(dialogListener);
        this.settingsDialog.add(mainBox, BorderLayout.CENTER);
        this.settingsDialog.add(Utility.padComponentH(okBox), BorderLayout.SOUTH);
        this.settingsDialog.setPreferredSize(new Dimension(300, 415));
        this.settingsDialog.pack();
        this.settingsDialog.setResizable(false);
        this.settingsDialog.setLocationRelativeTo(null);
    }

    // loads the User Manual dialog
    private void loadManual() {
        JEditorPane editorPane = null;
        try {
            editorPane = new JEditorPane(this.getClass().getResource(MANUAL_FILENAME));
        } catch (IOException e) {
            System.out.println("Couldn't open manual file");
            return;
        }

        editorPane.addHyperlinkListener(new HyperlinkListener() {
            public void hyperlinkUpdate(HyperlinkEvent e) {
                if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                    Utility.launchUrl(e.getURL());
                }
            }
        }
        );

        editorPane.setEditable(false);

        JScrollPane scrollPane = new JScrollPane(editorPane);

        this.manualDialog = new JDialog(this.frame, "User Manual", false);
        this.manualDialog.add(scrollPane);
        this.manualDialog.setPreferredSize(new Dimension(800, 600));
        this.manualDialog.pack();
        this.manualDialog.setLocationRelativeTo(null);
    }

    // loads the menus
    private JMenuBar makeMenu() {
        // create transparency law popup menu
        this.transparencyLawMenu = new JPopupMenu();
        JMenuItem popupDirectTransparency = new JMenuItem("Direct Transparency");
        popupDirectTransparency.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(false);
                selectedLaw.setUniform(true);*/
                setLaw(selectedLaw, false, true);
            }
        });
        this.transparencyLawMenu.add(popupDirectTransparency);
        JMenu popupMenuInverseTransparency = new JMenu("Inverse Transparency");
        this.transparencyLawMenu.add(popupMenuInverseTransparency);

        // menu "Program selection"
        menuApp = new JMenu("Translucency by a scattering layer");
        JMenuItem firstApp = menuApp.add("From subtractive to additive transparency");
        firstApp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (application.firstApp == null) {
                    application.firstApp = new FirstApplication(application);
                } else {
                    application.firstApp.setVisible(true);
                }
                application.firstApp.update(frame.getX(), frame.getY(), width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, resultPanel);
                application.firstApp.updateSettings(settingsDialog);
                setVisible(false);
                application.firstApp.setBack(backSource);
                application.firstApp.setFront(frontSource);
            }
        }
        );
        JMenuItem secondApp = menuApp.add("Transparency as generalized f-mean");
        secondApp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (application.secondApp == null) {
                    try {
                        application.secondApp = new SecondApplication(application);
                    } catch (IOException ex) {
                        Logger.getLogger(ThirdApplication.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    application.secondApp.setVisible(true);
                }
                application.secondApp.update(frame.getX(), frame.getY(), width, bordersEnabled, enableInfoFile, highlightInvalidPixels, saveDirectory, resultPanel);
                application.secondApp.updateSettings(settingsDialog);
                setVisible(false);
                application.secondApp.setBack(backSource);
                application.secondApp.setFront(frontSource);
            }
        }
        );

        JMenuItem thirdApp = menuApp.add("Translucency by a scattering layer");
        thirdApp.setEnabled(false);

        // menu "Operation Steps"
        menuSteps = new JMenu("Operation Steps");

        // menu "Select Background"
        JMenu menuBack = new JMenu("Select Background");
        menuSteps.add(menuBack);

        // menu "Select Foreground"
        JMenu menuFront = new JMenu("Select Foreground");
        menuSteps.add(menuFront);

        // item "Select Color"
        JMenuItem itemBackColor = menuBack.add("Select Color");
        itemBackColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                showColorSourceDialog(SourcePos.BACK);
            }
        }
        );

        // item "Select Image"
        JMenuItem itemBackImage = menuBack.add("Select Image");
        itemBackImage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String filename = openLoadDialog();
                if (filename != null) {
                    setSource(SourcePos.BACK, ImageSource.load(filename));
                }
            }
        }
        );

        // item "Select Color"
        JMenuItem itemFrontColor = menuFront.add("Select Color");
        itemFrontColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                showColorSourceDialog(SourcePos.FRONT);
            }
        }
        );

        // item "Select Image"
        JMenuItem itemFrontImage = menuFront.add("Select Image");
        itemFrontImage.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String filename = openLoadDialog();
                if (filename != null) {
                    setFront(ImageSource.load(filename));
                }
            }
        }
        );

        // menu "Transparency Mode"
        JMenu menuTransparencyLaw = new JMenu("Transparency Mode");
        menuSteps.add(menuTransparencyLaw);

        // menu "Direct Transparency"
        JMenuItem menuDirectTransparency = new JMenuItem("Direct Transparency");
        menuTransparencyLaw.add(menuDirectTransparency);
        menuDirectTransparency.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(false);
                selectedLaw.setUniform(true);*/
                setLaw(selectedLaw, false, true);
            }
        });

        menuTransparencyLaw.add(menuDirectTransparency);
        // menu "Inverse Transparency"
        JMenu menuInverseTransparency = new JMenu("Inverse Transparency");
        menuTransparencyLaw.add(menuInverseTransparency);

        JMenuItem menuInverseUniform = menuInverseTransparency.add("Uniform");
        menuInverseUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(true);
                selectedLaw.setUniform(true);*/
                setLaw(selectedLaw, true, true);
            }
        });

        JMenuItem menuInverseNonUniform = menuInverseTransparency.add("Non Uniform");
        menuInverseNonUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(true);
                selectedLaw.setUniform(false);*/
                setLaw(selectedLaw, true, false);
            }
        });

        JMenuItem popupInverseUniform = popupMenuInverseTransparency.add("Uniform");
        popupInverseUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(true);
                selectedLaw.setUniform(true);*/
                setLaw(selectedLaw, true, true);
            }
        });

        JMenuItem popupInverseNonUniform = popupMenuInverseTransparency.add("Non Uniform");
        popupInverseNonUniform.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                /*selectedLaw.setInverse(true);
                selectedLaw.setUniform(false);*/
                setLaw(selectedLaw, true, false);
            }
        });

        // items inverse transparency laws
        for (int l = 0; l < this.laws.size(); l++) {
            final TransparencyLaw law = this.laws.get(l);
            if (!law.isInverse()) {
                continue;
            }

            ActionListener listener = new ActionListener() {
                public void actionPerformed(ActionEvent event) {
                    setLaw(law, law.isInverse(), law.isUniform());
                }
            };

            String text = String.format("%s %s", law.getName(), law.isUniform() ? "Uniform" : "Non-Uniform");
            JMenuItem itemLaw = menuInverseTransparency.add(text);
            itemLaw.addActionListener(listener);

            JMenuItem popupItemLaw = popupMenuInverseTransparency.add(text);
            popupItemLaw.addActionListener(listener);
        }

        // item "Save Modified Image"
        JMenuItem itemSave = menuSteps.add("Save Modified Image");
        itemSave.setAccelerator(KeyStroke.getKeyStroke("control S"));
        itemSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openSaveDialog();
            }
        }
        );

        // item "Quit"
        JMenuItem itemQuit = menuSteps.add("Quit");
        itemQuit.setAccelerator(KeyStroke.getKeyStroke("control Q"));
        itemQuit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        }
        );

        // menu "Help"
        menuHelp = new JMenu("Help");

        // item "Settings"
        JMenuItem itemSettings = menuHelp.add("Settings");
        itemSettings.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                settingsDialog.setVisible(true);
            }
        }
        );

        // item "User Manual"
        JMenuItem itemUserManual = menuHelp.add("User Manual");
        itemUserManual.setAccelerator(KeyStroke.getKeyStroke("F1"));
        itemUserManual.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                if (manualDialog != null) {
                    manualDialog.setVisible(true);
                }
            }
        }
        );

        // item "About"
        JMenuItem itemAbout = menuHelp.add("About");
        itemAbout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                String line1 = "Interactive RGB Transparency is a Java software developed by Lionel Simonot, Mathieu Hébert, Andy Poudret and Florian Nadaud (2016)";
                String line2 = "<a href='" + WEBSITE_URL + "'>" + WEBSITE_URL + "</a>";
                String line3 = "Photograph of Notre-Dame-La-Grande in Poitiers by Florent Carmelet-Rescan";
                String text = line1 + "<br/>" + line2 + "<br/>" + line3;
                JEditorPane pane = new JEditorPane("text/html", text);
                pane.setEditable(false);
                pane.setBackground(new JLabel().getBackground());
                pane.addHyperlinkListener(new HyperlinkListener() {
                    public void hyperlinkUpdate(HyperlinkEvent e) {
                        if (e.getEventType().equals(HyperlinkEvent.EventType.ACTIVATED)) {
                            Utility.launchUrl(e.getURL());
                        }
                    }
                }
                );
                JOptionPane.showMessageDialog(frame, pane, "About", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        );

        // create menu
        JMenuBar menuBar = new JMenuBar();
        menuBar.add(menuApp);
        menuBar.add(menuSteps);
        menuBar.add(menuHelp);
        return menuBar;
    }

    // creates the top left / bottom left box
    private Box makeSourceBox(final SourcePos pos) {
        JLabel label = new JLabel(pos.getName());
        label.setFont(new Font(label.getFont().getName(), label.getFont().getStyle(), 14));

        ActionListener colorCancelListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (pos == SourcePos.BACK) {
                    setSource(pos, oldBackSource);
                } else {
                    setSource(pos, oldFrontSource);
                }
            }
        };

        String dialogTitle = String.format("Select %s Color", pos.getName());
        Color initialColor = (pos == SourcePos.BACK ? DEFAULT_BACK_COLOR : DEFAULT_FRONT_COLOR);
        ColorDialog colorDialog = new ColorDialog(this.frame, dialogTitle, initialColor, colorCancelListener, pos, this);
        colorDialog.addColorListener(new ColorListener() {
            public void colorChanged(Color color) {
                Dimension sourceSize = null;
                if (pos == SourcePos.BACK && !selectedLaw.isInverse() && !selectedLaw.isUniform() && backSource != null) {
                    sourceSize = backSource.getSourceSize();
                }
                colorDialog.setColor(color);
                setSource(pos, new ColorSource(color, sourceSize));
                if (pos == SourcePos.FRONT) {
                    if (littleFrame != null) {
                        littleFrame.updateSliders(colorDialog.getOldAlpha(), colorDialog.getOldBeta());
                    }
                }
            }
        }
        );

        JButton selectColorButton = new JButton("Select Color");
        selectColorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showColorSourceDialog(pos);
            }
        }
        );

        JButton selectImageButton = new JButton("Select Image");
        selectImageButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String filename = openLoadDialog();
                if (filename != null) {
                    if (pos == SourcePos.FRONT) {
                        setFront(ImageSource.load(filename));
                    } else {
                        setSource(pos, ImageSource.load(filename));
                    }
                }
            }
        }
        );

        Box sourceBox = Box.createVerticalBox();

        Box mainBox = Box.createVerticalBox();
        mainBox.setPreferredSize(new Dimension(200, 250));
        mainBox.setMinimumSize(new Dimension(200, 250));
        mainBox.setMaximumSize(new Dimension(200, 1000));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(label));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(selectColorButton));
        mainBox.add(Box.createRigidArea(new Dimension(0, 5)));
        mainBox.add(Utility.padComponentH(selectImageButton));
        mainBox.add(Box.createVerticalGlue());
        mainBox.add(Utility.padComponentH(sourceBox));
        mainBox.add(Box.createVerticalGlue());

        TransferHandler handler = new TransferHandler() {
            public boolean canImport(TransferSupport support) {
                return support.isDataFlavorSupported(DataFlavor.javaFileListFlavor);
            }

            public boolean importData(TransferSupport support) {
                if (!canImport(support)) {
                    return false;
                }

                Transferable t = support.getTransferable();

                File f = null;
                try {
                    java.util.List<File> l = (java.util.List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
                    f = l.get(l.size() - 1);
                } catch (UnsupportedFlavorException e) {
                    return false;
                } catch (IOException e) {
                    return false;
                }

                if (f != null) {
                    setSource(pos, ImageSource.load(f.getAbsolutePath()));
                }

                return true;
            }
        };
        MultipleTransferHandler multipleHandler = new MultipleTransferHandler();
        multipleHandler.addTransferHandler(handler);
        mainBox.setTransferHandler(multipleHandler);

        if (pos == SourcePos.BACK) {
            this.backBox = sourceBox;
            this.backColorDialog = colorDialog;
        } else {
            this.frontBox = sourceBox;
            this.frontColorDialog = colorDialog;
        }

        return mainBox;
    }

    public ThirdApplication(Menu app) {
        application = app;

        // initialization
        this.updatesEnabled = false;
        BufferedReader br;
        try {
            br = new BufferedReader(new FileReader("transparency_settings.properties"));
            br.readLine();
            this.bordersEnabled = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.enableInfoFile = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.highlightInvalidPixels = Boolean.valueOf(br.readLine()).booleanValue();
            br.readLine();
            this.saveDirectory = br.readLine();
            br.readLine();
            this.defaultWidth = Integer.parseInt(br.readLine());
            br.close();
        } catch (FileNotFoundException e) {
            this.bordersEnabled = true;
            this.enableInfoFile = true;
            this.highlightInvalidPixels = true;
            this.saveDirectory = ".";
            this.defaultWidth = 480;
        } catch (Exception e) {
        }
        this.invalidColor = DEFAULT_INVALID_COLOR;
        float[] hsb = new float[3];
        Color.RGBtoHSB(invalidColor.getRed(), invalidColor.getGreen(), invalidColor.getBlue(), hsb);
        float inc = 0.2F;
        if (hsb[2] <= inc) {
            secondInvalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] + inc);
        } else {
            secondInvalidColor = Color.getHSBColor(hsb[0], hsb[1], hsb[2] - inc);
        }

        this.laws = new ArrayList<TransparencyLaw>();
        this.laws.add(TransparencyLaws.KUBELKA);
        this.laws.add(TransparencyLaws.NON_SCATTERING);

        // frame
        this.frame = new JFrame("Interactive RGB Transparency");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setBackground(new Color(0, 0, 0));
        this.frame.setJMenuBar(this.makeMenu());

        // dialogs
        this.loadSettings();
        this.loadManual();

        // back panel (top left)
        Box topLeftBox = this.makeSourceBox(SourcePos.BACK);

        this.progressBar = new JProgressBar(SwingConstants.HORIZONTAL, 0, 100);
        this.progressBar.setValue(100);

        JPanel progressBarPanel = new JPanel();
        progressBarPanel.setPreferredSize(new Dimension(200, 20));
        progressBarPanel.setMaximumSize(new Dimension(200, 20));
        progressBarPanel.add(this.progressBar);

        topLeftBox.add(Utility.padComponentH(progressBarPanel));
        topLeftBox.add(Box.createRigidArea(new Dimension(0, 10)));

        // front panel (bottom left)
        Box botLeftBox = this.makeSourceBox(SourcePos.FRONT);

        // result panel and selected law label (top right)
        JLabel pixelInfoLabel = new JLabel(" ");
        ActionListener expectedBackListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = "Select Expected Background Color";
                String infoText = "Apply Inverse Transparency With The Suggested Background Color";
                ColorListener colorListener = new ColorListener() {
                    public void colorChanged(Color color) {
                        opaqueSelectionColor = color;
                        updateResult();
                    }
                };
                Point p = frame.getLocation();
                p.x += 205;
                p.y += 455;
                Color color = ColorDialog.createModalDialog(frame, title, infoText, DEFAULT_BACK_COLOR, p, colorListener);
                opaqueSelectionColor = null;
                if (color != null) {
                    Color frontColor = computeSuggestedForeground(color);
                    setFront(new ColorSource(frontColor));
                } else {
                    updateResult();
                }
            }
        };
        this.resultPanel = new ImagePanel(new Dimension(defaultWidth, 360), pixelInfoLabel, expectedBackListener);
        this.resultPanel.addActionListener(this);
        this.width = defaultWidth;
        this.resultContainer = new JPanel(new GridBagLayout());
        this.resultContainer.setPreferredSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.setMinimumSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.setMaximumSize(new Dimension(defaultWidth + 20, 360 + 20));
        this.resultContainer.add(this.resultPanel);

        Box resultBox = Box.createVerticalBox();
        resultBox.add(Box.createVerticalGlue());
        resultBox.add(this.resultContainer);
        resultBox.add(Utility.padComponentH(pixelInfoLabel));
        resultBox.add(Box.createRigidArea(new Dimension(0, 10)));
        resultBox.add(Box.createVerticalGlue());

        // drag & drop: result -> back
        TransferHandler srcHandler = new TransferHandler() {
            @Override
            protected Transferable createTransferable(JComponent c) {
                return new StringSelection("result");
            }

            @Override
            public int getSourceActions(JComponent c) {
                return COPY;
            }
        };
        TransferHandler destHandler = new TransferHandler() {
            @Override
            public boolean canImport(TransferSupport support) {
                if (!support.isDrop()) {
                    return false;
                }
                Object data = null;
                try {
                    data = support.getTransferable().getTransferData(DataFlavor.stringFlavor);
                } catch (Exception e) {
                    return false;
                }
                if (!(data instanceof String)) {
                    return false;
                }
                String str = (String) data;
                return "result".equals(str);
            }

            @Override
            public boolean importData(TransferSupport support) {
                if (this.canImport(support)) {
                    loadResultAsBack();
                    return true;
                } else {
                    return false;
                }
            }
        };
        resultBox.setTransferHandler(srcHandler);
        MultipleTransferHandler multipleHandler = (MultipleTransferHandler) topLeftBox.getTransferHandler();
        multipleHandler.addTransferHandler(destHandler);
        resultBox.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                JComponent lab = (JComponent) e.getSource();
                TransferHandler handle = lab.getTransferHandler();
                handle.exportAsDrag(lab, e, TransferHandler.COPY);
            }
        }
        );

        this.impossibleRemoval = new JLabel("Impossible Removal");
        this.impossibleRemoval.setFont(new Font(this.impossibleRemoval.getFont().getFontName(), Font.BOLD, 18));

        // dual board and sliders (bottom right)
        this.selectedLawButton = new JButton();
        this.selectedLawButton.setFont(new Font(this.selectedLawButton.getFont().getName(), this.selectedLawButton.getFont().getStyle(), 13));
        this.selectedLawButton.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent event) {
                transparencyLawMenu.show(event.getComponent(), event.getX(), event.getY());
            }
        }
        );

        this.dualBoard = new DualBoard(new Dimension(200, 100));

        this.switchButton = new JButton();
        this.switchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final JDialog choiceDialog;
                JLabel infoLabel;
                JLabel helpLabel;
                littleDisabledPanel.setEnabled(false);

                if (selectedLaw.isInverse()) {
                    choiceDialog = new JDialog(frame, "Visualize Removal Part", true);
                    infoLabel = new JLabel("Select the new background on which the removal part will be visualized:");
                    helpLabel = new JLabel("Selections and transparency laws cannot be changed in this mode.");
                } else {
                    choiceDialog = new JDialog(frame, "Back To Inverse Transparency", true);
                    infoLabel = new JLabel("Select the new background:");
                    helpLabel = new JLabel("");
                }
                choiceDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

                String resultRadioText = selectedLaw.isInverse() ? "Result Image" : "Initial Background";
                final JRadioButton resultRadio = new JRadioButton(resultRadioText, true);
                final JRadioButton colorRadio = new JRadioButton("New Color", false);
                final JRadioButton imageRadio = new JRadioButton("New Image", false);
                ButtonGroup grp = new ButtonGroup();
                grp.add(resultRadio);
                grp.add(colorRadio);
                grp.add(imageRadio);

                JButton okButton = new JButton("OK");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        selectedLaw.setInverse(!selectedLaw.isInverse());

                        if (!selectedLaw.isInverse()) {
                            computeRemoval();
                            tempBackSource = backSource;
                        }

                        selectedLaw.setInverse(!selectedLaw.isInverse());
                        Source newSource = null;
                        if (colorRadio.isSelected()) {
                            Color color = ColorDialog.createModalDialog(choiceDialog, "Select New Background Color", null, DEFAULT_BACK_COLOR);
                            if (color != null) {
                                Dimension sourceSize = null;
                                if (backSource != null) {
                                    sourceSize = backSource.getSourceSize();
                                }
                                newSource = new ColorSource(color, sourceSize);
                            }
                        } else if (imageRadio.isSelected()) {
                            String filename = openLoadDialog();
                            if (filename != null) {
                                newSource = ImageSource.load(filename);
                            }
                        } else if (selectedLaw.isInverse()) {
                            newSource = getResultAsSource();
                        } else {
                            newSource = tempBackSource;
                        }

                        selectedLaw.setInverse(!selectedLaw.isInverse());
                        if (newSource != null && checkBackSize(newSource)) {
                            choiceDialog.setVisible(false);
                            setLaw(selectedLaw, selectedLaw.isInverse(), selectedLaw.isUniform());
                            setSource(SourcePos.BACK, newSource);
                        }
                    }
                }
                );

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        choiceDialog.setVisible(false);
                        littleDisabledPanel.setEnabled(true);
                    }
                }
                );

                Box c1Box = Box.createHorizontalBox();
                c1Box.add(Box.createRigidArea(new Dimension(25, 0)));
                c1Box.add(Box.createHorizontalGlue());
                c1Box.add(infoLabel);
                c1Box.add(Box.createHorizontalGlue());
                c1Box.add(Box.createRigidArea(new Dimension(5, 0)));

                Box c3Box = Box.createHorizontalBox();
                c3Box.add(Box.createRigidArea(new Dimension(5, 0)));
                c3Box.add(Box.createHorizontalGlue());
                c3Box.add(helpLabel);
                c3Box.add(Box.createHorizontalGlue());
                c3Box.add(Box.createRigidArea(new Dimension(5, 0)));

                Box radioBox = Box.createVerticalBox();
                radioBox.add(resultRadio);
                radioBox.add(colorRadio);
                radioBox.add(imageRadio);

                Box c2Box = Box.createHorizontalBox();
                c2Box.add(Box.createHorizontalGlue());
                c2Box.add(radioBox);
                c2Box.add(Box.createHorizontalGlue());

                Box buttonsBox = Box.createHorizontalBox();
                buttonsBox.add(Box.createHorizontalGlue());
                buttonsBox.add(okButton);
                buttonsBox.add(Box.createRigidArea(new Dimension(10, 0)));
                buttonsBox.add(cancelButton);
                buttonsBox.add(Box.createHorizontalGlue());

                Box choiceBox = Box.createVerticalBox();
                choiceBox.add(c1Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));
                choiceBox.add(c2Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));
                choiceBox.add(c3Box);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 20)));
                choiceBox.add(buttonsBox);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 10)));

                choiceDialog.add(choiceBox);

                Dimension dimDialog = new Dimension(430, 206);
                choiceDialog.setMaximumSize(dimDialog);
                choiceDialog.setMinimumSize(dimDialog);
                choiceDialog.setPreferredSize(dimDialog);
                choiceDialog.pack();
                choiceDialog.setResizable(false);
                choiceDialog.setLocationRelativeTo(null);
                choiceDialog.setVisible(true);
            }
        }
        );

        this.expectedButton = new JButton("<html><center>Select Expected Background</center></html>");
        this.expectedButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                topDisabledPanel.setEnabled(false);
                botDisabledPanel.setEnabled(false);
                menuSteps.setEnabled(false);
                menuHelp.setEnabled(false);
                menuApp.setEnabled(false);
                resultPanel.resetCurrentSelection();
                resultPanel.setSelectionsLocked(true);
                resultPanel.setExpectedMode(true);
                resultPanel.repaint();
                double oldBeta = beta;
                if (scattering) {
                    littleFrame.expectedMode();
                }

                final JFrame choiceDialog = new JFrame("Expected Background");

                final JLabel infoLabel = new JLabel("<html><center>First create selection(s), then choose a target color.<br/>"
                        + "A new foreground color will be computed.</center></html>");

                JButton okButton = new JButton("OK");
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        if (resultPanel.getExpSelections().size() != 0) {
                            choiceDialog.setVisible(false);
                            topDisabledPanel.setEnabled(true);
                            botDisabledPanel.setEnabled(true);
                            menuSteps.setEnabled(true);
                            menuHelp.setEnabled(true);
                            menuApp.setEnabled(true);
                            String title = "Select Expected Background Color";
                            String infoText = "Apply Inverse Transparency With The Suggested Background Color";
                            ColorListener colorListener = new ColorListener() {
                                public void colorChanged(Color color) {
                                    opaqueSelectionColor = color;
                                    updateResult();
                                }
                            };
                            Point p = frame.getLocation();
                            p.x += 205;
                            p.y += 455;
                            Color color = ColorDialog.createModalDialog(frame, title, infoText, DEFAULT_BACK_COLOR, p, colorListener);
                            opaqueSelectionColor = null;
                            if (color != null) {
                                Color frontColor = computeSuggestedForeground(color);
                                resultPanel.mixSelections();
                                resultPanel.setSelectionsLocked(false);
                                resultPanel.setExpectedMode(false);
                                setFront(new ColorSource(frontColor));
                                if (scattering) {
                                    littleFrame.expectedMode(0);
                                }
                                littleFrame.updateSliders(alpha, beta);
                            } else {
                                resultPanel.clearExpSelections();
                                resultPanel.setSelectionsLocked(false);
                                resultPanel.setExpectedMode(false);
                                if (scattering) {
                                    littleFrame.expectedMode((int) (oldBeta * 100.0));
                                }
                                updateResult();
                            }
                        } else {
                            choiceDialog.setVisible(false);
                            try {
                                Thread.sleep(3);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(ThirdApplication.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            choiceDialog.setVisible(true);
                        }
                    }
                });

                JButton cancelButton = new JButton("Cancel");
                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        choiceDialog.setVisible(false);
                        topDisabledPanel.setEnabled(true);
                        botDisabledPanel.setEnabled(true);
                        menuSteps.setEnabled(true);
                        menuHelp.setEnabled(true);
                        menuApp.setEnabled(true);
                        resultPanel.setSelectionsLocked(false);
                        resultPanel.clearExpSelections();
                        resultPanel.setExpectedMode(false);
                        if (scattering) {
                            littleFrame.expectedMode((int) (oldBeta * 100.0));
                        }
                        updateResult();
                    }
                }
                );

                Box labelBox = Box.createHorizontalBox();
                labelBox.add(Box.createHorizontalGlue());
                labelBox.add(Box.createRigidArea(new Dimension(5, 0)));
                labelBox.add(infoLabel);
                labelBox.add(Box.createRigidArea(new Dimension(5, 0)));
                labelBox.add(Box.createHorizontalGlue());

                Box buttonBox = Box.createHorizontalBox();
                buttonBox.add(Box.createHorizontalGlue());
                buttonBox.add(okButton);
                buttonBox.add(Box.createRigidArea(new Dimension(10, 0)));
                buttonBox.add(cancelButton);
                buttonBox.add(Box.createHorizontalGlue());

                Box choiceBox = Box.createVerticalBox();
                choiceBox.add(Box.createRigidArea(new Dimension(0, 5)));
                choiceBox.add(labelBox);
                choiceBox.add(Box.createVerticalGlue());
                choiceBox.add(buttonBox);
                choiceBox.add(Box.createRigidArea(new Dimension(0, 5)));

                choiceDialog.add(choiceBox);
                choiceDialog.pack();
                choiceDialog.setResizable(false);
                //choiceDialog.setLocationRelativeTo(frame);
                choiceDialog.setLocation(frame.getX() + 210, frame.getY() + 470);
                choiceDialog.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
                choiceDialog.setAlwaysOnTop(true);
                choiceDialog.setVisible(true);
            }
        }
        );

        JPanel dualBoardContainer = new JPanel();
        dualBoardContainer.setLayout(new BoxLayout(dualBoardContainer, BoxLayout.PAGE_AXIS));
        dualBoardContainer.setPreferredSize(new Dimension(320, 100));
        dualBoardContainer.setMinimumSize(new Dimension(320, 100));
        dualBoardContainer.setMaximumSize(new Dimension(320, 100));
        dualBoardContainer.add(dualBoard);

        Dimension sliderDimension = new Dimension(140, 60);

        switchButton.setPreferredSize(sliderDimension);
        switchButton.setMinimumSize(sliderDimension);
        switchButton.setMaximumSize(sliderDimension);

        expectedButton.setPreferredSize(sliderDimension);
        expectedButton.setMinimumSize(sliderDimension);
        expectedButton.setMaximumSize(sliderDimension);
        Box mBox = Box.createHorizontalBox();
        Box c1Box = Box.createVerticalBox();
        Box c2Box = Box.createVerticalBox();

        c1Box.add(Box.createVerticalGlue());
        c1Box.add(this.switchButton);
        c1Box.add(Box.createVerticalGlue());
        mBox.add(c1Box);
        mBox.add(Box.createRigidArea(new Dimension(20, 0)));
        c2Box.add(Box.createVerticalGlue());
        c2Box.add(this.expectedButton);
        c2Box.add(Box.createVerticalGlue());
        mBox.add(c2Box);
        dualBoardContainer.add(mBox);

        thicknessText = new JTextField("1.00");

        this.thicknessLabel = new JLabel("Thickness : ");
        this.thicknessSlider = new JSlider(JSlider.HORIZONTAL, 0, 200, DEFAULT_TRANSPARENCY);
        //this.thicknessSlider.setInverted(true);
        /*Hashtable transparencyLabels = new Hashtable();
        transparencyLabels.put(0, new JLabel("Opaque"));
        transparencyLabels.put(50, new JLabel("2.0"));
        transparencyLabels.put(150, new JLabel("0.5"));
        transparencyLabels.put(100, new JLabel("1.0"));
        transparencyLabels.put(200, new JLabel("Transparent"));
        this.thicknessSlider.setLabelTable(transparencyLabels);
        this.thicknessSlider.setPaintLabels(true);*/
        this.thicknessSlider.setMinorTickSpacing(25);
        this.thicknessSlider.setMajorTickSpacing(50);
        this.thicknessSlider.setPaintTicks(true);
        ChangeListener cl = new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                double val = (double) thicknessSlider.getValue();
                val = 200 - val;
                if (val <= 100) {
                    val = val / 100;
                    String value = String.format("%.2f", val);
                    thicknessText.setText(value);
                } else if (val > 100 && val <= 150) {
                    val = (val - 100) / (200 / 4) + 1;
                    String value = String.format("%.2f", val);
                    thicknessText.setText(value);
                } else if (val > 150 && val < 200) {
                    val = 100 / ((200 - 150) - (val - 150));
                    String value = String.format("%.2f", val);
                    thicknessText.setText(value);
                } else if (val == 200) {
                    val = Double.POSITIVE_INFINITY;
                    thicknessText.setText("Infinity");
                }
                setTransparency(val);
            }
        };
        this.thicknessSlider.addChangeListener(cl);

        thicknessText.setPreferredSize(new Dimension(50, 20));
        thicknessText.setMaximumSize(new Dimension(50, 20));
        thicknessText.setHorizontalAlignment(JTextField.CENTER);
        thicknessText.setText("" + 1.00);
        thicknessText.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    double val = (double) Double.parseDouble(thicknessText.getText());
                    thicknessSlider.removeChangeListener(cl);
                    if (val <= 1.0 && val >= -1.0) {
                        thicknessSlider.setValue((int) (200 - (val * 100)));
                    } else if (val > 1.0 && val <= 2.0) {
                        thicknessSlider.setValue((int) (200 - ((val - 1) * (200 / 4) + 100)));
                    } else if (val > 2.0 && val <= 100) {
                        thicknessSlider.setValue((int) (200 - Math.round(200 - 100 / val)));
                    } else if (val > 100 && val <= 200) {
                        val = 100;
                        thicknessSlider.setValue((int) (200 - Math.round(200 - 100 / val)));
                        thicknessText.setText("" + val);
                    } else if (val > 200) {
                        val = Double.POSITIVE_INFINITY;
                        thicknessSlider.setValue(0);
                        thicknessText.setText("" + val);
                    }
                    setTransparency(val);
                    thicknessSlider.addChangeListener(cl);
                } catch (Exception ex) {
                }
            }
        }
        );

        this.maxRemovalLabel = new JLabel(" ");
        this.maxRemovalLabel.setPreferredSize(new Dimension(100, this.maxRemovalLabel.getPreferredSize().height));
        this.maxRemovalLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.noRemovalLabel = new JLabel(" ");
        this.noRemovalLabel.setPreferredSize(new Dimension(100, this.noRemovalLabel.getPreferredSize().height));
        this.noRemovalLabel.setHorizontalAlignment(SwingConstants.CENTER);

        final JLabel removalValueLabel = new JLabel(String.format("%d%%", DEFAULT_REMOVAL));
        removalValueLabel.setPreferredSize(new Dimension(50, removalValueLabel.getPreferredSize().height));
        removalValueLabel.setHorizontalAlignment(SwingConstants.CENTER);
        this.removalSlider = new JSlider(JSlider.HORIZONTAL, 0, 100, 100 - DEFAULT_REMOVAL);
        this.removalSlider.setVisible(false);
        Hashtable removalLabels = new Hashtable();
        removalLabels.put(0, this.maxRemovalLabel);
        removalLabels.put(50, removalValueLabel);
        removalLabels.put(100, this.noRemovalLabel);
        this.removalSlider.setLabelTable(removalLabels);
        this.removalSlider.setPaintLabels(true);
        this.removalSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                int val = 100 - removalSlider.getValue();
                removalValueLabel.setText(String.format("%d%%", val));
                removalSlider.repaint();
                setRemoval(val / 100.0);
            }
        }
        );

        labelBox = Box.createHorizontalBox();
        labelBox.add(new JLabel("Opaque"));
        labelBox.add(Box.createHorizontalGlue());
        labelBox.add(thicknessLabel);
        labelBox.add(thicknessText);
        labelBox.add(Box.createHorizontalGlue());
        labelBox.add(new JLabel("Transparent"));

        ButtonSlider b0 = new ButtonSlider(this, 0, "0");
        ButtonSlider b1 = new ButtonSlider(this, 0.5, "0.5");
        ButtonSlider b2 = new ButtonSlider(this, 1, "1");
        ButtonSlider b3 = new ButtonSlider(this, 2, "2");
        ButtonSlider b4 = new ButtonSlider(this, Double.POSITIVE_INFINITY, "∞");

        buttonBox = Box.createHorizontalBox();
        buttonBox.add(b4);
        buttonBox.add(Box.createHorizontalGlue());
        buttonBox.add(b3);
        buttonBox.add(Box.createHorizontalGlue());
        buttonBox.add(b2);
        buttonBox.add(Box.createHorizontalGlue());
        buttonBox.add(b1);
        buttonBox.add(Box.createHorizontalGlue());
        buttonBox.add(b0);

        sliderBox = Box.createHorizontalBox();
        sliderBox.add(Box.createRigidArea(new Dimension(8, 0)));
        sliderBox.add(this.thicknessSlider);
        sliderBox.add(Box.createRigidArea(new Dimension(8, 0)));

        Box midBox = Box.createVerticalBox();
        midBox.add(dualBoardContainer);
        Box cBox = Box.createHorizontalBox();
        cBox.add(Box.createHorizontalGlue());
        cBox.add(this.impossibleRemoval);
        cBox.add(Box.createHorizontalGlue());
        midBox.add(cBox);
        midBox.add(Box.createRigidArea(new Dimension(0, 5)));
        midBox.add(this.labelBox);
        midBox.add(Box.createRigidArea(new Dimension(0, 5)));
        midBox.add(this.sliderBox);
        midBox.add(this.removalSlider);
        midBox.add(Box.createRigidArea(new Dimension(0, 2)));
        midBox.add(this.buttonBox);

        Box sBox = Box.createHorizontalBox();
        sBox.add(Box.createHorizontalGlue());
        sBox.add(Box.createRigidArea(new Dimension(10, 0)));
        sBox.add(midBox);
        sBox.add(Box.createRigidArea(new Dimension(10, 0)));
        sBox.add(Box.createHorizontalGlue());

        Box botRightBox = Box.createVerticalBox();
        botRightBox.add(Box.createVerticalGlue());
        botRightBox.add(Box.createRigidArea(new Dimension(0, 10)));
        botRightBox.add(Utility.padComponentH(this.selectedLawButton));
        botRightBox.add(Box.createRigidArea(new Dimension(0, 10)));
        botRightBox.add(sBox);
        botRightBox.add(Box.createVerticalGlue());

        // put everything in a box
        Box topBox = Box.createHorizontalBox();
        topDisabledPanel = new DisabledPanel(topLeftBox);
        topBox.add(topDisabledPanel);
        topBox.add(resultBox);

        Box botBox = Box.createHorizontalBox();
        botBox.add(botLeftBox);
        botBox.add(botRightBox);

        Box mainBox = Box.createVerticalBox();
        mainBox.add(topBox);
        botDisabledPanel = new DisabledPanel(botBox);
        mainBox.add(botDisabledPanel);

        // draw the "grid"
        Color bordersColor = new Color(127, 127, 127);
        botBox.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, bordersColor));
        resultBox.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, bordersColor));
        botRightBox.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 0, bordersColor));

        // make components transparent
        this.backBox.setOpaque(false);
        this.frontBox.setOpaque(false);
        this.resultContainer.setOpaque(false);
        dualBoardContainer.setOpaque(false);
        this.thicknessSlider.setOpaque(false);
        this.thicknessLabel.setOpaque(false);
        this.removalSlider.setOpaque(false);
        progressBarPanel.setOpaque(false);

        // set initial background color
        frame.getContentPane().setBackground(new Color(238, 238, 238));

        setAlpha(DEFAULT_ALPHA);
        setBeta(DEFAULT_BETA);

        // frame pack
        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

        this.frame.add(mainBox, BorderLayout.CENTER);
        this.frame.pack();
        this.frame.setResizable(false);
        this.frame.setLocation((int) maximumWindowBounds.getWidth() / 2 - frame.getWidth() / 2, (int) maximumWindowBounds.getHeight() / 2 - frame.getHeight() / 2);
        this.frame.setVisible(true);

        // set initial settings
        this.enableUpdates(false);
        this.setLaw(laws.get(0), laws.get(0).isInverse(), laws.get(0).isUniform());
        this.setTransparency(DEFAULT_TRANSPARENCY / 100.0);
        this.setType(DEFAULT_TYPE / 100.0);
        this.setRemoval(DEFAULT_REMOVAL / 100.0);
        this.setBack(ImageSource.load(this.getClass().getResource(BACKGROUND_LOCATION), BACKGROUND_FILENAME));
        this.setFront(ImageSource.load(this.getClass().getResource(FOREGROUND_LOCATION), FOREGROUND_FILENAME));
        this.enableUpdates(true);
        this.updateResult();
        this.resultPanel.resetSelections(this.frontSource.getSourceSize()); // TODO: fix this hack
        this.updateResult();

        littleFrame = new LittleFrame(this);

        if (frame.getX() - littleFrame.getWidth() > 0) {
            this.littleFrame.setLocation((frame.getX() - littleFrame.getWidth()), frame.getY() + frame.getHeight() - littleFrame.getHeight());
        } else if (maximumWindowBounds.getWidth() - (frame.getX() + frame.getWidth()) - littleFrame.getWidth() > 0) {
            this.littleFrame.setLocation(frame.getX() + frame.getWidth(), frame.getY() + frame.getHeight() - littleFrame.getHeight());
        } else {
            this.littleFrame.setLocation(0, frame.getY() + frame.getHeight() - littleFrame.getHeight());
        }
        this.frame.setVisible(true);

        this.progressBar.setVisible(false);
        this.switchButton.setVisible(false);
        this.expectedButton.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        this.updateResult();
    }

    public Source getFrontSource() {
        return frontSource;
    }

    public void setVisible(boolean b) {
        frame.setVisible(b);
        littleFrame.setVisible(b);
    }

    public LittleFrame getLittleFrame() {
        return this.littleFrame;
    }

    public void update(int x, int y, int w, boolean bordersE, boolean infoFileE, boolean highlightE, String saveD, ImagePanel resultP) {
        //get local graphics environment
        GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
        //get maximum window bounds
        Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

        frame.setLocation(x, y);
        if (frame.getX() - littleFrame.getWidth() > 0) {
            this.littleFrame.setLocation((frame.getX() - littleFrame.getWidth()), frame.getY() + frame.getHeight() - littleFrame.getHeight());
        } else if (maximumWindowBounds.getWidth() - (frame.getX() + frame.getWidth()) - littleFrame.getWidth() > 0) {
            this.littleFrame.setLocation(frame.getX() + frame.getWidth(), frame.getY() + frame.getHeight() - littleFrame.getHeight());
        } else {
            this.littleFrame.setLocation(0, frame.getY() + frame.getHeight() - littleFrame.getHeight());
        }
        this.bordersEnabled = bordersE;
        this.enableInfoFile = infoFileE;
        this.highlightInvalidPixels = highlightE;
        bordersCheckbox.setSelected(bordersEnabled);
        highlightCheckbox.setSelected(highlightInvalidPixels);
        infoFileCheckbox.setSelected(enableInfoFile);
        this.saveDirectory = saveD;
        this.resultPanel.clearSelections();
        this.setMaxDisplayWidth(w);
        switch (w) {
            case 360:
                button360.setSelected(true);
                break;
            case 480:
                button480.setSelected(true);
                break;
            case 640:
                button640.setSelected(true);
                break;
            default:
                button360.setSelected(true);
        }

        resultP.copy(this.resultPanel);
        frame.pack();
    }

    public Color getSecondInvalidColor() {
        return secondInvalidColor;
    }

    public void updateThicknessSlider(int val) {
        this.thicknessSlider.setValue(val);
    }

    public void changeLaw() {
        if (selectedLaw instanceof Kubelka) {
            this.scattering = false;
            this.setLaw(laws.get(1), selectedLaw.isInverse(), selectedLaw.isUniform());
        } else {
            this.scattering = true;
            this.setLaw(laws.get(0), selectedLaw.isInverse(), selectedLaw.isUniform());
        }
    }

    public boolean isInverse() {
        return selectedLaw.isInverse();
    }

    public boolean isUniform() {
        return selectedLaw.isUniform();
    }

    public void updateSettings(JDialog settingsDialog) {
        this.settingsDialog.setLocation(settingsDialog.getLocation());
        this.settingsDialog.setVisible(settingsDialog.isVisible());
    }

    public void update(int w, boolean bordersE, boolean infoFileE, boolean highlightE, String saveD, JDialog settingsDialog) {
        this.bordersEnabled = bordersE;
        this.enableInfoFile = infoFileE;
        this.highlightInvalidPixels = highlightE;
        bordersCheckbox.setSelected(bordersEnabled);
        highlightCheckbox.setSelected(highlightInvalidPixels);
        infoFileCheckbox.setSelected(enableInfoFile);
        this.saveDirectory = saveD;
        this.setMaxDisplayWidth(w);
        switch (w) {
            case 360:
                button360.setSelected(true);
                break;
            case 480:
                button480.setSelected(true);
                break;
            case 640:
                button640.setSelected(true);
                break;
            default:
                button360.setSelected(true);
        }
        this.updateSettings(settingsDialog);
    }
}
