import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;


public class DualBoard extends JComponent
{
	private Image image;
	private Color blackColor;
	private Color whiteColor;
	private Color edgeColor;
	private boolean borderEnabled;

	public DualBoard(Dimension d)
	{
		this.image = null;
		this.blackColor = null;
		this.whiteColor = null;
		this.edgeColor = null;
		this.borderEnabled = true;

		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.setMinimumSize(d);
		this.setPreferredSize(d);
		this.setMaximumSize(d);
	}

	public void enableBorder(boolean enabled)
	{
		this.borderEnabled = enabled;
		this.repaint();
	}

	public void setImage(Image image, Color edgeColor)
	{
		this.image = image;
		this.blackColor = null;
		this.whiteColor = null;
		this.edgeColor = edgeColor;
		this.repaint();
	}

	public void setColors(Color blackColor, Color whiteColor, Color edgeColor)
	{
		this.image = null;
		this.blackColor = blackColor;
		this.whiteColor = whiteColor;
		this.edgeColor = edgeColor;
		this.repaint();
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		// black part
		g.setColor(new Color(0, 0, 0));
		g.fillRect(0, 0, getWidth()/2, getHeight());

		// white part
		g.setColor(new Color(255, 255, 255));
		g.fillRect(getWidth()/2, 0, getWidth()/2, getHeight());

		// content
		int w = getWidth()/2;
		int h = getHeight()/2;
		if(this.image != null)
		{
			w = this.image.getWidth(null);
			h = this.image.getHeight(null);
		}
		int x = (getWidth() - w) / 2;
		int y = (getHeight() - h) / 2;

		if(this.image == null)
		{
			if(this.blackColor != null)
			{
				g.setColor(this.blackColor);
				g.fillRect(x, y, w/2, h);
			}

			if(this.whiteColor != null)
			{
				g.setColor(this.whiteColor);
				g.fillRect(x+w/2, y, w/2, h);
			}
		}
		else
			g.drawImage(this.image, x, y, w, h, null);

		// edges
		if(this.edgeColor != null && this.borderEnabled)
		{
			g.setColor(this.edgeColor);
			g.drawRect(x, y, w, h);
		}
	}
}
